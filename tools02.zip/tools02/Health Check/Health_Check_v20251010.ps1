﻿# CHECK HEALTH RUNNING 
$interval = 60 # Interval in seconds for the check

# Use Add-Type to define the user32.dll method for check
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Keyboard {
    [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
    public static extern void keybd_event(byte bVk, byte bScan, int dwFlags, int extraInfo);
    public const int KEYEVENTF_EXTENDEDKEY = 0x1;
    public const int KEYEVENTF_KEYUP = 0x2;
    public const int VK_SHIFT = 0x10;
}
"@

Write-Output "Starting script. Press Ctrl+C to stop."

# Loop check
while ($true) {
    # press to check
    [Keyboard]::keybd_event([Keyboard]::VK_SHIFT, 0, [Keyboard]::KEYEVENTF_EXTENDEDKEY, 0)
    Start-Sleep -Milliseconds 100
    [Keyboard]::keybd_event([Keyboard]::VK_SHIFT, 0, [Keyboard]::KEYEVENTF_KEYUP, 0)
    
    # Wait for the specified interval before checking again
    Start-Sleep -Seconds $interval
}
