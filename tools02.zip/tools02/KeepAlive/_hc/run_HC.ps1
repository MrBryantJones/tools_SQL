﻿cd "C:\temo\tools\_hc"
.\hc_v20251010.ps1

#"C:\temo\tools\Health Check\Health_Check_v20251010.ps1"