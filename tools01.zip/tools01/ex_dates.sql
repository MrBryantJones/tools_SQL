SELECT 
GETDATE() AS [TodayDatetime], 
GETDATE()-1 AS [YesterdayDateTime], 
CONVERT(DATE,GETDATE()) AS [TodayDate],
CONVERT(DATE,GETDATE()-1) AS [YesterdayDate], 
FORMAT(GETDATE(),'MM-dd-yyyy hh:mm:ss tt') as [TodayFormattedDateTime],
CONVERT(VARCHAR(8), GETDATE(), 112) as [YYYYMMDD],
FORMAT(GETDATE(), 'yyyy-MM-dd') as [YYYY-MM-DD],
CAST(GETDATE() AS DATE) as [YYYY-MM-DD],
CONVERT(VARCHAR(10), GETDATE(), 23) as [YYYY-MM-DD],
YEAR(GETDATE()) as [Year],
YEAR(CONVERT(DATE, GETDATE())) as [Year],
YEAR(cast(GETDATE() as date)) AS YEAR, 
DATEPART(YEAR, cast(GETDATE() as date)) AS YEAR,
DATEPART(yyyy, GETDATE()) AS YEAR,
DATEPART(yyyy, CONVERT(DATE, GETDATE())) as [Year],
MONTH(GETDATE()) as [Month],
DATEPART(month, GETDATE()) as [Month],
MONTH(CONVERT(DATE, GETDATE())) as [Month],
MONTH(cast(GETDATE() as date)) AS ExtractedMonth,
DATEPART(month, CONVERT(DATE, GETDATE())) as [Month],
DATEPART(month, cast(GETDATE() as date)) AS ExtractedMonth,
FORMAT(MAX(CONVERT(DATE,GETDATE())), 'MMM yyyy') as [MonthYear],
FORMAT(MAX(CONVERT(DATE,GETDATE())), 'yyyyMM') as [YearMonth],
CAST(FORMAT(YEAR(GETDATE()), '0000') + FORMAT(MONTH(GETDATE()), '00') as int) as [YearMonth],
CAST(CAST(MONTH(GETDATE()) as varchar(2)) + '/01/' + CAST(YEAR(GETDATE()) as varchar(4)) as date) as [FirstDayOfThisMonth],
REPLACE(CONVERT(VARCHAR, GETDATE(),101),'/','')	as [mmddyyyy],
REPLACE(CONVERT(VARCHAR, GETDATE(),101),'/','') + REPLACE(CONVERT(VARCHAR,GETDATE(),108),':','')	as [mmddyyyyhhmmss]


SELECT
'CurrentDateFormattedAsText' as [CurrentDateFormattedAsText],
CONVERT(VARCHAR(10), GETDATE(), 101) as [mm/dd/yyyy_CurrentDateFormattedAsText],
CONVERT(VARCHAR(8), GETDATE(),   1) as [mm/dd/yy with 2 DIGIT YEAR], 
CONVERT(VARCHAR(10), GETDATE(), 103) as [dd/mm/yyyy with 4 DIGIT YEAR], 
CONVERT(VARCHAR(8), GETDATE(),   3) as [dd/mm/yy with 2 DIGIT YEAR], 
REPLACE(CONVERT(VARCHAR(10), GETDATE(), 102), '.', ' ') as [yyyy mm dd with 4 DIGIT YEAR], 
REPLACE(CONVERT(VARCHAR(8), GETDATE(),   2), '.', ' ') as [yy mm dd  with 2 DIGIT YEAR], 
REPLACE(CONVERT(VARCHAR(10), GETDATE(), 112), '.', ' ') as [yyyymmdd with 4 DIGIT YEAR],
REPLACE(CONVERT(VARCHAR(8), GETDATE(),  12), '.', ' ') as [yymmdd  with 2 DIGIT YEAR],
REPLACE(CONVERT(VARCHAR(10), GETDATE(), 104), '.', '') as [ddmmyyyy with 4 DIGIT YEAR] 
SELECT
'CurrentDateFormattedAsText' as [CurrentDateFormattedAsText],
REPLACE(CONVERT(VARCHAR(8), GETDATE(),   4), '.', '') as [ddmmyy  with 2 DIGIT YEAR],
REPLACE(CONVERT(VARCHAR(10), GETDATE(), 111), '/', '-') as [yyyy-mm-dd with 4 DIGIT YEAR],
REPLACE(CONVERT(VARCHAR(8), GETDATE(),   11), '/', '-') as [yy-mm-dd  with 2 DIGIT YEAR],
REPLACE(CONVERT(VARCHAR(10), GETDATE(), 110), '/', '-') as [mm/dd/yyyy with 4 DIGIT YEAR],
REPLACE(CONVERT(VARCHAR(8), GETDATE(),   10), '/', '-') as [mm/dd/yy  with 2 DIGIT YEAR]


		--,FORMAT(PA.AdmissionDateTime,'MM-dd-yyyy hh:mm:ss tt') as AdmissionDate
		--,FORMAT(PA.DischargeDateTime,'MM-dd-yyyy hh:mm:ss tt') as DischargeDate
		--format(max(d.Date), 'MMM yyyy') as MonthYear,
		--format(max(d.Date), 'yyyyMM') as YearMonth,
		--cast(format(g.GoalYear, '0000') + format(g.GoalMonth, '00') as int) as YearMonth,
		--cast(cast(g.GoalMonth as varchar(2)) + '/01/' + cast(g.GoalYear as varchar(4)) as date) as ParameterDate,

/***********************************************************************************************************
#	30 Days back from Today

			SELECT 
			CAST(GETDATE() AS DATE) as [Today], 
			DATEADD(DAY, -30, CAST(GETDATE() AS DATE)) as [30 days ago], 
			DATEADD(DAY, -60, CAST(GETDATE() AS DATE)) as [60 days ago] 
			;
			
			-- Declare date parameters
			DECLARE @Today DATE;
			DECLARE @ThirtyDaysAgo DATE;
			DECLARE @SixtyDaysAgo DATE;
			
			-- Assign today's date and 30 days ago
			SET @Today = CAST(GETDATE() AS DATE);
			SET @ThirtyDaysAgo = DATEADD(DAY, -30, @Today)
			SET @SixtyDaysAgo = DATEADD(DAY, -60, @Today)
			;
			
			SELECT @Today as [Today], @ThirtyDaysAgo as [30 days ago], @SixtyDaysAgo as [60 days ago]
			
			-- Sample query using the date range
			--SELECT *
			--FROM YourTable
			--WHERE CreatedDate BETWEEN @ThirtyDaysAgo AND @Today;


#	30 days back from 09/28/2025
			--and ( CONVERT(DATE, ReviewDate) >= '2025-08-30' and CONVERT(DATE, ReviewDate) <= '2025-09-27' )
			
			-- Declare parameters
			DECLARE @InputDate DATE;
			DECLARE @ThirtyDaysBeforeInput DATE;
			
			-- Assign a specific date (you can change this value as needed)
			--SET @InputDate = '2025-10-29';  -- Example: today's date or any date you choose
			--SET @InputDate = '2025-09-28';  -- Example: today's date or any date you choose
			SET @InputDate = '2025-09-27';  -- Example: today's date or any date you choose
			
			-- Calculate 30 days before the input date
			SET @ThirtyDaysBeforeInput = DATEADD(DAY, -30, @InputDate);
			
			SELECT @InputDate as [Today], @ThirtyDaysBeforeInput as [30 days from that date]
			
			-- Sample query using the calculated date range
			--SELECT *
			--FROM YourTable
			--WHERE CreatedDate BETWEEN @ThirtyDaysBeforeInput AND @InputDate;

***********************************************************************************************************/

/***********************************************************************************************************
/***	Provide YYYY-MM		***/

declare @YYYYMM varchar(7) = '2025-08'; 

SELECT 
@YYYYMM as [passed_param], 
cast(@YYYYMM + '-01' as date) as FirstDayOfMonth,
eomonth(@YYYYMM + '-01') as LastDayOfMonth,
FORMAT(cast(@YYYYMM + '-01' as date), 'M/d/yyyy') as [FirstDayOfMonth_M/d/yyyy],
REPLACE(REPLACE(CONVERT(VARCHAR(10), eomonth(@YYYYMM + '-01'), 101), '/0', '/'), ' 0', ' ') as [LastDayOfMonth_M/d/yyyy],
FORMAT(GETDATE(), 'M/d/yyyy') AS [FormattedDate_Control_M/d/yyyy],
REPLACE(REPLACE(CONVERT(VARCHAR(10), GETDATE(), 101), '/0', '/'), ' 0', ' ') AS [FormattedDate_mm/dd/yyyy_Control]


declare @start_date date = '8/1/2025' , 		@end_date	date	= '8/31/2025'
						--'2025-08-01'								'2025-08-31'

/***	Set date range	***/

		/***	Specific time frame	
										declare @start_date date = '9/1/2021' , 		@end_date	date	= '9/30/2021'
		***/	

		/***	Handle like proc	***/

				declare @start_date date, @end_date date
				Set @start_date = null		Set @end_date = null

			/* Default values for optional parameters */

				if @start_date is null
					set @start_date = '1/1/2019'								--'2019-01-01'
				if @end_date is null
					set @end_date = cast(dateadd(day, -1, getdate()) as date)	--yesterday like	'2025-09-04'
***********************************************************************************************************/
/***********************************************************************************************************/
/***	get the first day of the month from yyyy-mm		SELECT CAST('2025-08' + '-01' AS DATE);		***/
/***	get the last day of the month from yyyy-mm		DECLARE @YYYYMM VARCHAR(7) = '2025-08'; SELECT EOMONTH(@YYYYMM + '-01') AS LastDayOfMonth;		***/
/***	SELECT CAST('2025-08' + '-01' AS DATE) as FirstDayOfMonth, EOMONTH('2025-08' + '-01') AS LastDayOfMonth;	***/
/***
		CAST('2025-08' + '-01' AS DATE) as FirstDayOfMonth, 
		EOMONTH('2025-08' + '-01') AS LastDayOfMonth;
		IIF( CONVERT(DATE, a.discharge_datetime) IS NOT NULL, CAST(FORMAT(a.discharge_datetime, 'yyyy-MM') + '-01' AS DATE), CONVERT(DATE, a.discharge_datetime) ) as discharge_fdom,
		IIF( CONVERT(DATE, a.discharge_datetime) IS NOT NULL, EOMONTH(FORMAT(a.discharge_datetime, 'yyyy-MM') + '-01'), CONVERT(DATE, a.discharge_datetime) ) AS discharge_ldom,
		IIF( boolean_expression, true_value, false_value )
		FORMAT(GETDATE(), 'yyyy-MM') AS YYYYMM
***/
/*****************************************************************************************************************************/
/*****************************************************************************************************************************/
/*****************************************************************************************************************************/
-- SQL Date Format mm-dd-yyyy with SQL CONVERT
go
-- The date used for this example was November 12, 2023.
DECLARE @Datetime DATETIME;
SET @Datetime = GETDATE();
 
--mm/dd/yyyy with 4 DIGIT YEAR
SELECT REPLACE(CONVERT(VARCHAR(10), @Datetime, 110), '/', '-') CurrentDateFormattedAsText;
 
--mm/dd/yy  with 2 DIGIT YEAR
SELECT REPLACE(CONVERT(VARCHAR(8), @Datetime,   10), '/', '-') CurrentDateFormattedAsText;

---- pull data from a database table
---- The date used for this example was January 15, 2013. 
----SELECT a datetime column as a string formatted mm/dd/yyyy (4 digit year)
--SELECT TOP 3 REPLACE(CONVERT(CHAR(10), ExpectedDeliveryDate, 110), '/', '-') ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;
 
----SELECT a datetime column as a string formatted mm/dd/yy (2 digit year)
--SELECT TOP 3 REPLACE(CONVERT(CHAR(8), ExpectedDeliveryDate, 10), '/', '-') ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;

/*****************************************************************************************************************************/
--  SQL Date Format yyyy-mm-dd with SQL CONVERT
go
-- The date used for this example was November 12, 2023.
DECLARE @Datetime DATETIME;
SET @Datetime = GETDATE();
 
--yyyy-mm-dd with 4 DIGIT YEAR
SELECT REPLACE(CONVERT(VARCHAR(10), @Datetime, 111), '/', '-') CurrentDateFormattedAsText;
 
--yy-mm-dd  with 2 DIGIT YEAR
SELECT REPLACE(CONVERT(VARCHAR(8), @Datetime,   11), '/', '-') CurrentDateFormattedAsText;

---- pull data from a database table
---- The date used for this example was January 15, 2013.
----SELECT a datetime column as a string formatted yyyy-mm-dd (4 digit year)
--SELECT TOP 3 REPLACE(CONVERT(CHAR(10), ExpectedDeliveryDate, 111), '/', '-') ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;
 
----SELECT a datetime column as a string formatted yy-mm-dd (2 digit year)
--SELECT TOP 3 REPLACE(CONVERT(CHAR(8), ExpectedDeliveryDate, 11), '/', '-') ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;
/*****************************************************************************************************************************/
-- SQL Date format ddmmyyyy with SQL CONVERT
go
-- The date used for this example was November 12, 2023.
DECLARE @Datetime DATETIME;
SET @Datetime = GETDATE();
 
--ddmmyyyy with 4 DIGIT YEAR
SELECT REPLACE(CONVERT(VARCHAR(10), @Datetime, 104), '.', '') CurrentDateFormattedAsText;
 
--ddmmyy  with 2 DIGIT YEAR
SELECT REPLACE(CONVERT(VARCHAR(8), @Datetime,   4), '.', '') CurrentDateFormattedAsText;

---- pull data from a database table
---- The date used for this example was January 15, 2013.
----SELECT a datetime column as a string formatted ddmmyyyy (4 digit year)
--SELECT TOP 3 REPLACE(CONVERT(CHAR(10), ExpectedDeliveryDate, 104), '.', '') ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;
 
----SELECT a datetime column as a string formatted ddmmyy (2 digit year)
--SELECT TOP 3 REPLACE(CONVERT(CHAR(8), ExpectedDeliveryDate,  4), '.', '') ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;

/*****************************************************************************************************************************/
-- SQL Date Format yyyymmdd with SQL CONVERT
go
-- The date used for this example was November 12, 2023.
DECLARE @Datetime DATETIME;
SET @Datetime = GETDATE();
 
--yyyymmdd with 4 DIGIT YEAR
SELECT REPLACE(CONVERT(VARCHAR(10), @Datetime, 112), '.', ' ') CurrentDateFormattedAsText;
 
--yymmdd  with 2 DIGIT YEAR
SELECT REPLACE(CONVERT(VARCHAR(8), @Datetime,  12), '.', ' ') CurrentDateFormattedAsText;

---- pull data from a database table
---- The date used for this example was January 15, 2013.
----SELECT a datetime column as a string formatted yyyymmdd (4 digit year)
--SELECT TOP 3 REPLACE(CONVERT(CHAR(10), ExpectedDeliveryDate, 112), '.', ' ') ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;
 
----SELECT a datetime column as a string formatted yymmdd (2 digit year)
--SELECT TOP 3 REPLACE(CONVERT(CHAR(8), ExpectedDeliveryDate, 12), '.', ' ') ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;

/*****************************************************************************************************************************/
-- SQL Date Format yyyy mm dd with SQL CONVERT
go
-- The date used for this example was November 12, 2023.
DECLARE @Datetime DATETIME;
SET @Datetime = GETDATE();
 
--yyyy mm dd with 4 DIGIT YEAR
SELECT REPLACE(CONVERT(VARCHAR(10), @Datetime, 102), '.', ' ') CurrentDateFormattedAsText;
 
--yy mm dd  with 2 DIGIT YEAR
SELECT REPLACE(CONVERT(VARCHAR(8), @Datetime,   2), '.', ' ') CurrentDateFormattedAsText;

---- pull data from a database table
---- The date used for this example was January 15, 2013.
----SELECT a datetime column as a string formatted yyyy mm dd (4 digit year)
--SELECT TOP 3 REPLACE(CONVERT(CHAR(10), ExpectedDeliveryDate, 102), '.', ' ') ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;
 
----SELECT a datetime column as a string formatted yy mm dd (2 digit year)
--SELECT TOP 3 REPLACE(CONVERT(CHAR(8), ExpectedDeliveryDate, 2), '.', ' ') ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;
/*****************************************************************************************************************************/
-- SQL Date Format mm/dd/yyyy with SQL CONVERT
go
-- The date used for this example was November 12, 2023.
DECLARE @Datetime DATETIME;
SET @Datetime = GETDATE();
 
--mm/dd/yyyy with 4 DIGIT YEAR
SELECT CONVERT(VARCHAR(10), @Datetime, 101) CurrentDateFormattedAsText;
 
--mm/dd/yy with 2 DIGIT YEAR
SELECT CONVERT(VARCHAR(8), @Datetime,   1) CurrentDateFormattedAsText;

-- pull data from a database table
-- The date used for this example was January 15, 2013.
--SELECT a datetime column as a string formatted mm/dd/yyyy (4 digit year)
--SELECT TOP 3 CONVERT(CHAR(10), ExpectedDeliveryDate, 101) ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;
 
--SELECT a datetime column as a string formatted mm/dd/yy (2 digit year)
--SELECT TOP 3 CONVERT(CHAR(8), ExpectedDeliveryDate, 1) ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;

/*****************************************************************************************************************************/
--  SQL Date Format dd/mm/yyyy with SQL CONVERT
go
-- The date used for this example was November 12, 2023.
DECLARE @Datetime DATETIME;
SET @Datetime = GETDATE();
 
--dd/mm/yyyy with 4 DIGIT YEAR
SELECT CONVERT(VARCHAR(10), @Datetime, 103) CurrentDateFormattedAsText;
 
--dd/mm/yy with 2 DIGIT YEAR
SELECT CONVERT(VARCHAR(8), @Datetime,   3) CurrentDateFormattedAsText;

-- pull data from a database table
-- The date used for this example was January 25, 2013. 
--SELECT a datetime column as a string formatted dd/mm/yyyy (4 digit year)
--SELECT TOP 3 CONVERT(CHAR(10), ExpectedDeliveryDate, 103) ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;
 
--SELECT a datetime column as a string formatted dd/mm/yy (2 digit year)
--SELECT TOP 3 CONVERT(CHAR(8), ExpectedDeliveryDate, 3) ExpectedDeliveryDateFormattedAsText
--FROM Purchasing.PurchaseOrders
--WHERE OrderDate < @Datetime;

/*****************************************************************************************************************************/
--		Get List of all Valid Date and Time Formats

drop table if exists #dateFormats
DECLARE @counter INT = 0
--DECLARE @date DATETIME = '2006-12-30 00:38:54.840'
DECLARE @date DATETIME = (SELECT GETDATE()) --2025-08-27 11:56:24.230
CREATE TABLE #dateFormats (dateFormatOption int, dateOutput nvarchar(40))
WHILE (@counter <= 150 )
BEGIN
   BEGIN TRY
      INSERT INTO #dateFormats
      SELECT CONVERT(nvarchar, @counter), CONVERT(nvarchar,@date, @counter) 
      SET @counter = @counter + 1
   END TRY
   BEGIN CATCH;
      SET @counter = @counter + 1
      IF @counter >= 150
      BEGIN
         BREAK
      END
   END CATCH
END
--SELECT * FROM #dateFormats
SELECT dateFormatOption, dateOutput, CONCAT('select convert(varchar, getdate(), ', dateFormatOption, ')') AS [Query] FROM #dateFormats

/*****************************************************************************************************************************/
--		Format #	Query	Format	Sample
--		1	select convert(varchar, getdate(), 1)	mm/dd/yy	12/30/22
--		2	select convert(varchar, getdate(), 2)	yy.mm.dd	22.12.30
--		3	select convert(varchar, getdate(), 3)	dd/mm/yy	30/12/22
--		4	select convert(varchar, getdate(), 4)	dd.mm.yy	30.12.22
--		5	select convert(varchar, getdate(), 5)	dd-mm-yy	30-12-22
--		6	select convert(varchar, getdate(), 6)	dd-Mon-yy	30 Dec 22
--		7	select convert(varchar, getdate(), 7)	Mon dd, yy	Dec 30, 22
--		10	select convert(varchar, getdate(), 10)	mm-dd-yy	12-30-22
--		11	select convert(varchar, getdate(), 11)	yy/mm/dd	22/12/30
--		12	select convert(varchar, getdate(), 12)	yymmdd	221230
--		23	select convert(varchar, getdate(), 23)	yyyy-mm-dd	2022-12-30
--		31	select convert(varchar, getdate(), 31)	yyyy-dd-mm	2022-30-12
--		32	select convert(varchar, getdate(), 32)	mm-dd-yyyy	12-30-2022
--		33	select convert(varchar, getdate(), 33)	mm-yyyy-dd	12-2022-30
--		34	select convert(varchar, getdate(), 34)	dd-mm-yyyy	30-12-2022
--		35	select convert(varchar, getdate(), 35)	dd-yyyy-mm	30-2022-12
--		101	select convert(varchar, getdate(), 101)	mm/dd/yyyy	12/30/2022
--		102	select convert(varchar, getdate(), 102)	yyyy.mm.dd	2022.12.30
--		103	select convert(varchar, getdate(), 103)	dd/mm/yyyy	30/12/2022
--		104	select convert(varchar, getdate(), 104)	dd.mm.yyyy	30.12.2022
--		105	select convert(varchar, getdate(), 105)	dd-mm-yyyy	30-12-2022
--		106	select convert(varchar, getdate(), 106)	dd Mon yyyy	30 Dec 2022
--		107	select convert(varchar, getdate(), 107)	Mon dd, yyyy	Dec 30, 2022
--		110	select convert(varchar, getdate(), 110)	mm-dd-yyyy	12-30-2022
--		111	select convert(varchar, getdate(), 111)	yyyy/mm/dd	2022/12/30
--		112	select convert(varchar, getdate(), 112)	yyyymmdd	20221230
--		 	 	 	 
--		TIME ONLY FORMATS
--		8	select convert(varchar, getdate(), 8)	hh:mm:ss	00:38:54
--		14	select convert(varchar, getdate(), 14)	hh:mm:ss:nnn	00:38:54:840
--		24	select convert(varchar, getdate(), 24)	hh:mm:ss	00:38:54
--		108	select convert(varchar, getdate(), 108)	hh:mm:ss	00:38:54
--		114	select convert(varchar, getdate(), 114)	hh:mm:ss:nnn	00:38:54:840
--		 	 	 	 
--		DATE & TIME FORMATS
--		0	select convert(varchar, getdate(), 0)	Mon dd yyyy hh:mm AM/PM	Dec 30 2022 12:38AM
--		9	select convert(varchar, getdate(), 9)	Mon dd yyyy hh:mm:ss:nnn AM/PM	Dec 30 2022 12:38:54:840AM
--		13	select convert(varchar, getdate(), 13)	dd Mon yyyy hh:mm:ss:nnn AM/PM	30 Dec 2022 00:38:54:840AM
--		20	select convert(varchar, getdate(), 20)	yyyy-mm-dd hh:mm:ss	2022-12-30 00:38:54
--		21	select convert(varchar, getdate(), 21)	yyyy-mm-dd hh:mm:ss:nnn	2022-12-30 00:38:54.840
--		22	select convert(varchar, getdate(), 22)	mm/dd/yy hh:mm:ss AM/PM	12/30/22 12:38:54 AM
--		25	select convert(varchar, getdate(), 25)	yyyy-mm-dd hh:mm:ss:nnn	2022-12-30 00:38:54.840
--		26	select convert(varchar, getdate(), 26)	yyyy-dd-mm hh:mm:ss:nnn	2022-30-12 00:38:54.840
--		27	select convert(varchar, getdate(), 27)	mm-dd-yyyy hh:mm:ss:nnn	12-30-2022 00:38:54.840
--		28	select convert(varchar, getdate(), 28)	mm-yyyy-dd hh:mm:ss:nnn	12-2022-30 00:38:54.840
--		29	select convert(varchar, getdate(), 29)	dd-mm-yyyy hh:mm:ss:nnn	30-12-2022 00:38:54.840
--		30	select convert(varchar, getdate(), 30)	dd-yyyy-mm hh:mm:ss:nnn	30-2022-12 00:38:54.840
--		100	select convert(varchar, getdate(), 100)	Mon dd yyyy hh:mm AM/PM	Dec 30 2022 12:38AM
--		109	select convert(varchar, getdate(), 109)	Mon dd yyyy hh:mm:ss:nnn AM/PM	Dec 30 2022 12:38:54:840AM
--		113	select convert(varchar, getdate(), 113)	dd Mon yyyy hh:mm:ss:nnn	30 Dec 2022 00:38:54:840
--		120	select convert(varchar, getdate(), 120)	yyyy-mm-dd hh:mm:ss	2022-12-30 00:38:54
--		121	select convert(varchar, getdate(), 121)	yyyy-mm-dd hh:mm:ss:nnn	2022-12-30 00:38:54.840
--		126	select convert(varchar, getdate(), 126)	yyyy-mm-dd T hh:mm:ss:nnn	2022-12-30T00:38:54.840
--		127	select convert(varchar, getdate(), 127)	yyyy-mm-dd T hh:mm:ss:nnn	2022-12-30T00:38:54.840
--		 	 	 	 
--		ISLAMIC CALENDAR DATES
--		130	select convert(nvarchar, getdate(), 130)	dd mmm yyyy hh:mi:ss:nnn AM/PM	date output
--		131	select convert(nvarchar, getdate(), 131)	dd mmm yyyy hh:mi:ss:nnn AM/PM	10/12/1444 12:38:54:840AM
--		Format Date or Time without Dividing Characters
--		Format the date or time without dividing characters and concatenate the date and time string:
--		
--		Sample statement	Format	Output
--		select replace(convert(varchar, getdate(),101),�/�,�)	mmddyyyy	12302022
--		select replace(convert(varchar, getdate(),101),�/�,�) + replace(convert(varchar,
--		getdate(),108),�:�,�)	mmddyyyyhhmmss	12302022004426
/*****************************************************************************************************************************/

/*	UPDATE TABLE - SET DATE TO YESTERDAY		*/

--UPDATE [LeadSquared].[PatientDataForExtract_History]
--SET [LoadDate] = DATEADD(day, DATEDIFF(day, 0, GETDATE()) - 1, CAST(CAST([LoadDate] AS TIME) AS DATETIME) )
--WHERE Sent = 1 AND CONVERT(DATE,[LoadDate]) = CONVERT(DATE,GETDATE())

----		2025-08-22 15:24:42.637 to 2025-08-21 15:24:42.637
--SELECT 
--DATEADD(day, DATEDIFF(day, 0, GETDATE()) - 1, CAST(CAST([LoadDate] AS TIME) AS DATETIME) ) as [New], 
--[LoadDate] as [Current]
--,* FROM [LeadSquared].[PatientDataForExtract_History] WHERE [Sent] = 1 AND CONVERT(DATE,[LoadDate]) = CONVERT(DATE,GETDATE())

--SELECT 
--DATEADD(day, DATEDIFF(day, 0, GETDATE()) - 1, CAST(CAST([LoadDate] AS TIME) AS DATETIME) ) as [New], 
--[LoadDate] as [Current]
--FROM [LeadSquared].[PatientDataForExtract_History] WHERE [Sent] = 1 AND CONVERT(DATE,[LoadDate]) = CONVERT(DATE,GETDATE())

/*****************************************************************************************************************************/