
-- Declare variables for search
DECLARE @SearchTableName NVARCHAR(MAX) = 'Discharge';
DECLARE @SearchColumnName NVARCHAR(MAX) = 'Discharge';

-- Temp table to store results
IF OBJECT_ID('tempdb..#SearchResults') IS NOT NULL DROP TABLE #SearchResults;

CREATE TABLE #SearchResults (
    DatabaseName NVARCHAR(MAX),
    SchemaName NVARCHAR(MAX),
    TableName NVARCHAR(MAX),
    ColumnName NVARCHAR(MAX) NULL
);

-- Cursor to loop through databases
DECLARE db_cursor CURSOR FOR
SELECT name 
FROM sys.databases 
WHERE state_desc = 'ONLINE'
  AND name NOT IN ('master','tempdb','model','msdb');  -- Skip system DBs

DECLARE @DBName NVARCHAR(MAX); --SYSNAME;
DECLARE @SQL NVARCHAR(MAX);

OPEN db_cursor;
FETCH NEXT FROM db_cursor INTO @DBName;

WHILE @@FETCH_STATUS = 0
BEGIN
    -- Build dynamic SQL to query tables/columns
            --was using     USE [' + QUOTENAME(@DBName) + '];
    SET @SQL = '
    USE ' + QUOTENAME(@DBName) + ';
    BEGIN TRY
        -- Search for matching table names
        INSERT INTO #SearchResults (DatabaseName, SchemaName, TableName, ColumnName)
        SELECT 
            DB_NAME(),
            s.name AS SchemaName,
            t.name AS TableName,
            NULL AS ColumnName
        FROM sys.tables t
        INNER JOIN sys.schemas s ON t.schema_id = s.schema_id
        WHERE t.name = @SearchTableName;

        -- Search for matching column names
        INSERT INTO #SearchResults (DatabaseName, SchemaName, TableName, ColumnName)
        SELECT 
            DB_NAME(),
            s.name AS SchemaName,
            t.name AS TableName,
            c.name AS ColumnName
        FROM sys.columns c
        INNER JOIN sys.tables t ON c.object_id = t.object_id
        INNER JOIN sys.schemas s ON t.schema_id = s.schema_id
        WHERE c.name = @SearchColumnName;
    END TRY
    BEGIN CATCH
        PRINT ''Error in database: ' + @DBName + ' - '' + ERROR_MESSAGE();
    END CATCH;
    ';

    -- Execute with parameters
    EXEC sp_executesql 
        @SQL, 
        N'@SearchTableName NVARCHAR(MAX), @SearchColumnName NVARCHAR(MAX)', 
        @SearchTableName = @SearchTableName, 
        @SearchColumnName = @SearchColumnName;

    --CHECK
        --PRINT @SQL 
        --PRINT N'@SearchTableName NVARCHAR(MAX), @SearchColumnName NVARCHAR(MAX)' 
        --PRINT @SearchTableName 
        --PRINT @SearchColumnName 

    FETCH NEXT FROM db_cursor INTO @DBName;
END

CLOSE db_cursor;
DEALLOCATE db_cursor;

-- Output all results
SELECT * 
    , CONCAT('SELECT TOP 5 [', ColumnName, '], ''##########'', * FROM ', DatabaseName, '.', SchemaName, '.', TableName, ' WHERE 1=1 --AND xxx') AS [research_queries]
FROM #SearchResults ORDER BY DatabaseName, SchemaName, TableName;

/*
-- Output results
SELECT * FROM #SearchResults ORDER BY DatabaseName, SchemaName, TableName;

--Generate research queries
SELECT CONCAT('SELECT TOP 5 ',ColumnName,', ''##########'', * FROM ',DatabaseName,'.',SchemaName,'.',TableName,' WHERE 1=1 --AND xxx') FROM #SearchResults ORDER BY DatabaseName, SchemaName, TableName;

--DatabaseName	SchemaName	TableName	    ColumnName
--dbBrooks_dw	    dbo	        AdmissionBudget	Discharge
--SELECT TOP 5 Discharge, '##########', * FROM dbBrooks_dw.dbo.AdmissionBudget WHERE 1=1 --AND xxx
--SELECT TOP 5 ColumnName, '##########', * FROM DatabaseName.SchemaName.TableName WHERE 1=1 --AND xxx
--'SELECT TOP 5 ',ColumnName,', ''##########'', * FROM ',DatabaseName,'.',SchemaName,'.',TableName,' WHERE 1=1 --AND xxx'
*/