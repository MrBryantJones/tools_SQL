﻿cd "C:\Users\BJones3\Desktop"

Unblock-File "C:\Users\BJones3\Desktop\EG-Inventory_v1_20251104_1630.ps1"
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
#.\EG-Inventory_v1_20251104_1630.ps1

# Usage
# Basic inventory (logs only)
# Run in an elevated PowerShell (Administrator)
.\EG-Inventory_v1_20251104_1630.ps1 `
  -LogDir "C:\Users\BJones3\Desktop" `
  -SasHome "C:\Program Files\SASHome"

# Include simple port checks to SAS servers
# Add egress tests (optional)
.\EG-Inventory_v1_20251104_1630.ps1 `
  -LogDir "C:\Users\BJones3\Desktop" `
  -SasHome "C:\Program Files\SASHome" `
  -CheckPorts `
  -MetadataHost "sas-meta.example.com" -MetadataPort 8561 `
  -SpawnerHost  "sas-app.example.com"  -SpawnerPort 8591

# Ooooooor this:

#powershell -ExecutionPolicy Bypass -Command "Unblock-File 'C:\Users\BJones3\Desktop\EG-Inventory_v1_20251104_1630.ps1'; & 'C:\Users\BJones3\Desktop\EG-Inventory_v1_20251104_1630.ps1'"



# This is a single, self-contained PowerShell inventory script that collects all the pertinent info you need for SAS Enterprise Guide readiness and logs it cleanly.
# 
# What it captures (and why)
# 
# OS & hardware: name, version, build, uptime, architecture, CPU, cores, RAM, system drive free space — confirms basic capacity/compatibility.
# PowerShell & .NET: PS version; .NET 4.x Release with a friendly version mapping and a flag for EG 8.1 minimum (≥ 4.7.1).
# Office bitness: x86/x64/Unknown — key for EG & SAS Office Add-In compatibility.
# ODBC drivers: both 64-bit and 32-bit lists — critical for client-side data connectors.
# Existing EG installs: finds common SEGuide.exe paths (32/64-bit) under SASHome and Program Files (x86).
# SAS presence in registry: quick signal if any SAS components were installed previously.
# VC++ Redistributables: awareness only (often bundled/needed for client apps).
# 
# Optional egress checks: simple TCP probes to Metadata (default 8561) and Spawner (default 8591) if you pass hosts.
# 
# Outputs
# 
# Transcript log: C:\Install\logs\EG-Inventory_Transcript_<timestamp>.log
# JSON summary: C:\Install\logs\EG-Inventory_Summary.json
# 
# CSV files:
# 
# EG-Inventory_ODBC64.csv
# EG-Inventory_ODBC32.csv
# EG-Inventory_VC_Redistributables.csv

# Usage
# Basic inventory (logs only)
# Run in an elevated PowerShell (Administrator)
.\EG-Inventory_v1_20251104_1630.ps1 `
  -LogDir "C:\Users\BJones3\Desktop" `
  -SasHome "C:\Program Files\SASHome"

# Include simple port checks to SAS servers
# Add egress tests (optional)
.\EG-Inventory_v1_20251104_1630.ps1 `
  -LogDir "C:\Users\BJones3\Desktop" `
  -SasHome "C:\Program Files\SASHome" `
  -CheckPorts `
  -MetadataHost "sas-meta.example.com" -MetadataPort 8561 `
  -SpawnerHost  "sas-app.example.com"  -SpawnerPort 8591

<#

This is a single, self-contained PowerShell inventory script that collects all the pertinent info you need for SAS Enterprise Guide readiness and logs it cleanly.

What it captures (and why)

OS & hardware: name, version, build, uptime, architecture, CPU, cores, RAM, system drive free space — confirms basic capacity/compatibility.
PowerShell & .NET: PS version; .NET 4.x Release with a friendly version mapping and a flag for EG 8.1 minimum (≥ 4.7.1).
Office bitness: x86/x64/Unknown — key for EG & SAS Office Add-In compatibility.
ODBC drivers: both 64-bit and 32-bit lists — critical for client-side data connectors.
Existing EG installs: finds common SEGuide.exe paths (32/64-bit) under SASHome and Program Files (x86).
SAS presence in registry: quick signal if any SAS components were installed previously.
VC++ Redistributables: awareness only (often bundled/needed for client apps).

Optional egress checks: simple TCP probes to Metadata (default 8561) and Spawner (default 8591) if you pass hosts.

Outputs

Transcript log: C:\Install\logs\EG-Inventory_Transcript_<timestamp>.log
JSON summary: C:\Install\logs\EG-Inventory_Summary.json

CSV files:

EG-Inventory_ODBC64.csv
EG-Inventory_ODBC32.csv
EG-Inventory_VC_Redistributables.csv

Usage
Basic inventory (logs only)
# Run in an elevated PowerShell (Administrator)
.\EG-Inventory.ps1 `
  -LogDir "C:\Install\logs" `
  -SasHome "C:\Program Files\SASHome"

Include simple port checks to SAS servers
# Add egress tests (optional)
.\EG-Inventory.ps1 `
  -LogDir "C:\Install\logs" `
  -SasHome "C:\Program Files\SASHome" `
  -CheckPorts `
  -MetadataHost "sas-meta.example.com" -MetadataPort 8561 `
  -SpawnerHost  "sas-app.example.com"  -SpawnerPort 8591



#>

