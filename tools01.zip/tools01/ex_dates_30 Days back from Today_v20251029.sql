--	#	30 Days back from Today

			SELECT 
			CAST(GETDATE() AS DATE) as [Today], 
			DATEADD(DAY, -30, CAST(GETDATE() AS DATE)) as [30 days ago], 
			DATEADD(DAY, -60, CAST(GETDATE() AS DATE)) as [60 days ago] 
			;
			
			-- Declare date parameters
			DECLARE @Today DATE;
			DECLARE @ThirtyDaysAgo DATE;
			DECLARE @SixtyDaysAgo DATE;
			
			-- Assign today's date and 30 days ago
			SET @Today = CAST(GETDATE() AS DATE);
			SET @ThirtyDaysAgo = DATEADD(DAY, -30, @Today)
			SET @SixtyDaysAgo = DATEADD(DAY, -60, @Today)
			;
			
			SELECT @Today as [Today], @ThirtyDaysAgo as [30 days ago], @SixtyDaysAgo as [60 days ago]
			
			-- Sample query using the date range
			--SELECT *
			--FROM YourTable
			--WHERE CreatedDate BETWEEN @ThirtyDaysAgo AND @Today;


-- #	30 days back from 09/28/2025

			-- Declare parameters
			DECLARE @InputDate DATE;
			DECLARE @ThirtyDaysBeforeInput DATE;
			
			-- Assign a specific date (you can change this value as needed)
			--SET @InputDate = '2025-10-29';  -- Example: today's date or any date you choose
			--SET @InputDate = '2025-09-28';  -- Example: today's date or any date you choose
			SET @InputDate = '2025-09-27';  -- Example: today's date or any date you choose
			
			-- Calculate 30 days before the input date
			SET @ThirtyDaysBeforeInput = DATEADD(DAY, -30, @InputDate);
			
			SELECT @InputDate as [Today], @ThirtyDaysBeforeInput as [30 days from that date]
			
			-- Sample query using the calculated date range
			--SELECT *
			--FROM YourTable
			--WHERE CreatedDate BETWEEN @ThirtyDaysBeforeInput AND @InputDate;

/***********************************************************************************************************
#	30 Days back from Today

			SELECT 
			CAST(GETDATE() AS DATE) as [Today], 
			DATEADD(DAY, -30, CAST(GETDATE() AS DATE)) as [30 days ago], 
			DATEADD(DAY, -60, CAST(GETDATE() AS DATE)) as [60 days ago] 
			;
			
			-- Declare date parameters
			DECLARE @Today DATE;
			DECLARE @ThirtyDaysAgo DATE;
			DECLARE @SixtyDaysAgo DATE;
			
			-- Assign today's date and 30 days ago
			SET @Today = CAST(GETDATE() AS DATE);
			SET @ThirtyDaysAgo = DATEADD(DAY, -30, @Today)
			SET @SixtyDaysAgo = DATEADD(DAY, -60, @Today)
			;
			
			SELECT @Today as [Today], @ThirtyDaysAgo as [30 days ago], @SixtyDaysAgo as [60 days ago]
			
			-- Sample query using the date range
			--SELECT *
			--FROM YourTable
			--WHERE CreatedDate BETWEEN @ThirtyDaysAgo AND @Today;


#	30 days back from 09/28/2025
			--and ( CONVERT(DATE, ReviewDate) >= '2025-08-30' and CONVERT(DATE, ReviewDate) <= '2025-09-27' )
			
			-- Declare parameters
			DECLARE @InputDate DATE;
			DECLARE @ThirtyDaysBeforeInput DATE;
			
			-- Assign a specific date (you can change this value as needed)
			--SET @InputDate = '2025-10-29';  -- Example: today's date or any date you choose
			--SET @InputDate = '2025-09-28';  -- Example: today's date or any date you choose
			SET @InputDate = '2025-09-27';  -- Example: today's date or any date you choose
			
			-- Calculate 30 days before the input date
			SET @ThirtyDaysBeforeInput = DATEADD(DAY, -30, @InputDate);
			
			SELECT @InputDate as [Today], @ThirtyDaysBeforeInput as [30 days from that date]
			
			-- Sample query using the calculated date range
			--SELECT *
			--FROM YourTable
			--WHERE CreatedDate BETWEEN @ThirtyDaysBeforeInput AND @InputDate;

***********************************************************************************************************/