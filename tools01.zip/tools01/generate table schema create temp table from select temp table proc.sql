/***	
Use a table or temp table to create a drop and create temptable schema statement to run

	note that if using a temp table, you have to run this in the same session
***/

DECLARE @sql NVARCHAR(MAX) = '';
DECLARE @query NVARCHAR(MAX) = N'
    -- your SELECT here | just swap out #anytemptable (select x,y,z from #anytemptable for any table (any select x,y,z from table)
	select a.mpi_id, a.client_id, a.fac_id, a.unit_id, a.is_tcp, a.adm_cen_id, a.adm_datetime, a.dis_cen_id, a.disc_datetime from AnyDatabase.dbo.AnyTable a with (nolock) where 1=1
';
SELECT @sql = STRING_AGG( QUOTENAME(name) + ' ' + system_type_name + CASE WHEN is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END, ',' + CHAR(13))
FROM sys.dm_exec_describe_first_result_set(@query, NULL, 0);
SET @sql = 'drop table if exists #temptable
CREATE TABLE #temptable (' + CHAR(13) + @sql + CHAR(13) + ');';
PRINT @sql;
-- Optional: EXEC(@sql);

/* RESULTS  
			drop table if exists #temptable
			CREATE TABLE #temptable (
			[mpi_id] int NULL,
			[client_id] int NULL,
			[fac_id] int NULL,
			[unit_id] int NULL,
			[is_tcp] bit NULL,
			[adm_cen_id] int NULL,
			[adm_datetime] datetime NULL,
			[dis_cen_id] int NULL,
			[dis_datetime] datetime NULL
			);
*/

/***
   Can also do this    
	just swap out #patient_detail for any temp table that is used or a select
***/
go

-- Step 1: Declare variables
	DECLARE @sql NVARCHAR(MAX) = '';
	DECLARE @print NVARCHAR(MAX) = '';
	DECLARE @columnDefs NVARCHAR(MAX) = '';
-- Step 2: Generate the column definitions from #patient_detail
	-- We use FOR XML PATH to concatenate rows into a single string
	SELECT @columnDefs = STRING_AGG(CONCAT('[' + c.name + '] ',t.name,
	CASE WHEN t.name IN ('int', 'datetime', 'float') THEN '' ELSE '(' + CAST(c.max_length AS VARCHAR) + ')'END,
	CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END ), ', ' + CHAR(13)  -- comma + newline
	)
	FROM tempdb.sys.columns AS c
	JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
	WHERE c.object_id = OBJECT_ID('tempdb..#anytemptable');
-- Step 3: Assemble the full CREATE TABLE script
SET @print = '
DROP TABLE IF EXISTS #temptable;

CREATE TABLE #temptable (
' + @columnDefs + '
);'
-- Step 4: Print the final result
	PRINT '--- Generated CREATE TABLE Script ---';
	PRINT @print;

/***-------------------------------------------------------------------------

    Generate / capture output schema of a table

-------------------------------------------------------------------------***/

DECLARE @sql NVARCHAR(MAX) = '';
DECLARE @query NVARCHAR(MAX) = N'
    -- your SELECT here | just swap out #patient_detail for any temp table that is used or a select
select a.mpi_id as [Master_Patient_Index], a.client_id, a.fac_id, a.unit_id, a.is_tcp, a.admission_census_id, a.admission_datetime, a.discharge_census_id, a.discharge_datetime
from PCCReporting.dbo.Admissions			a with (nolock)		where 1=1
';
SELECT @sql = STRING_AGG( QUOTENAME(name) + ' ' + system_type_name + CASE WHEN is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END, ',' + CHAR(13))
FROM sys.dm_exec_describe_first_result_set(@query, NULL, 0);
SET @sql = 'drop table if exists #temptable
CREATE TABLE #temptable (' + CHAR(13) + @sql + CHAR(13) + ');';
PRINT @sql;
-- Optional: EXEC(@sql);

/* RESULTS  
drop table if exists #temptable
CREATE TABLE #temptable (
[Master_Patient_Index] int NULL,
[client_id] int NULL,
[fac_id] int NULL,
[unit_id] int NULL,
[is_tcp] bit NULL,
[admission_census_id] int NULL,
[admission_datetime] datetime NULL,
[discharge_census_id] int NULL,
[discharge_datetime] datetime NULL
);
*/

/*************************************************************************************/
/*************************************************************************************/

-- --   Build the CREATE TABLE statement using sp_describe_first_result_set -- --

DECLARE @sql NVARCHAR(MAX) = '';
DECLARE @query NVARCHAR(MAX) = N'
    -- your SELECT here | just swap out #patient_detail for any temp table that is used or a select
                select
				CensusID,			FacilityType,			FacilityName,	FinancialClass,		PatientID,			
				RoomName,			BedDesc_RoomCensusBed,	RoomID,			Location_MisLocID,	FloorName,	
				AdmissionDateTime,	DischargeDateTime,		CensusDate,		LOS,				AdmissionDay,	
				DischargeDay,	/* get from datedim when no admission or discharge */
				PatientDay
                from #patient_detail
';
SELECT @sql = STRING_AGG(
    QUOTENAME(name) + ' ' + system_type_name +
    CASE WHEN is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END,
    ',' + CHAR(13)
)
FROM sys.dm_exec_describe_first_result_set(@query, NULL, 0);
SET @sql = '
drop table if exists #temptable

CREATE TABLE #temptable (' + CHAR(13) + @sql + CHAR(13) + ');';
PRINT @sql;
-- Optional: EXEC(@sql);


-- --   Can also do this    --  --
-- just swap out #patient_detail for any temp table that is used or a select

-- Step 1: Declare variables
	DECLARE @sql NVARCHAR(MAX) = '';
	DECLARE @print NVARCHAR(MAX) = '';
	DECLARE @columnDefs NVARCHAR(MAX) = '';
-- Step 2: Generate the column definitions from #patient_detail
	-- We use FOR XML PATH to concatenate rows into a single string
	SELECT @columnDefs = STRING_AGG(CONCAT('[' + c.name + '] ',t.name,
	CASE WHEN t.name IN ('int', 'datetime', 'float') THEN '' ELSE '(' + CAST(c.max_length AS VARCHAR) + ')'END,
	CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END ), ', ' + CHAR(13)  -- comma + newline
	)
	FROM tempdb.sys.columns AS c
	JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
	WHERE c.object_id = OBJECT_ID('tempdb..#patient_detail');
-- Step 3: Assemble the full CREATE TABLE script
SET @print = '
DROP TABLE IF EXISTS #temptable;

CREATE TABLE #temptable (
' + @columnDefs + '
);'
-- Step 4: Print the final result
	PRINT '--- Generated CREATE TABLE Script ---';
	PRINT @print;








--- --- JUST SOME BACKGROUND INFO   --- ---

-- build temp table --

EXEC tempdb.sys.sp_help '#patient_detail';

SELECT 
    c.name AS ColumnName,
    t.name AS DataType,
    c.max_length,
    c.is_nullable
FROM tempdb.sys.columns AS c
JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
WHERE c.object_id = OBJECT_ID('tempdb..#patient_detail');

-- or build a temp table from a select --

drop table if exists #ProcedureOutput
SELECT *
INTO #ProcedureOutput
FROM (
    -- your SELECT here
    select ID, Name from table --#patient_detail
) AS SourceQuery;

-- can also do this --

--v5
-- Step 1: Declare variables
	DECLARE @sql NVARCHAR(MAX) = '';
	DECLARE @print NVARCHAR(MAX) = '';
	DECLARE @columnDefs NVARCHAR(MAX) = '';
-- Step 2: Generate the column definitions from #ProcedureOutput
	-- We use FOR XML PATH to concatenate rows into a single string
	SELECT @columnDefs = STRING_AGG(CONCAT('[' + c.name + '] ',t.name,
	CASE WHEN t.name IN ('int', 'datetime', 'float') THEN '' ELSE '(' + CAST(c.max_length AS VARCHAR) + ')'END,
	CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END ), ', ' + CHAR(13)  -- comma + newline
	)
	FROM tempdb.sys.columns AS c
	JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
	WHERE c.object_id = OBJECT_ID('tempdb..#ProcedureOutput');
-- Step 3: Assemble the full CREATE TABLE script
SET @print = '
DROP TABLE IF EXISTS #temptable;

CREATE TABLE #temptable (
' + @columnDefs + '
);'
-- Step 4: Print the final result
	PRINT '--- Generated CREATE TABLE Script ---';
	PRINT @print;

--v4

        -- Step 1: Declare variables
        DECLARE @sql NVARCHAR(MAX) = '';
        DECLARE @print NVARCHAR(MAX) = '';
        DECLARE @columnDefs NVARCHAR(MAX) = '';
        
        -- Step 2: Generate the column definitions from #ProcedureOutput
        -- We use FOR XML PATH to concatenate rows into a single string
        
        SELECT @columnDefs = STRING_AGG(
            CONCAT(
                '[' + c.name + '] ',
                t.name,
                CASE 
                    WHEN t.name IN ('int', 'datetime', 'float') THEN ''
                    ELSE '(' + CAST(c.max_length AS VARCHAR) + ')'
                END,
                CASE 
                    WHEN c.is_nullable = 1 THEN ' NULL'
                    ELSE ' NOT NULL'
                END
            ), ', ' + CHAR(13)  -- comma + newline
        )
        FROM tempdb.sys.columns AS c
        JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
        WHERE c.object_id = OBJECT_ID('tempdb..#ProcedureOutput');
        
        -- Step 3: Assemble the full CREATE TABLE script
        SET @print = '
        DROP TABLE IF EXISTS #temptable;
        
        CREATE TABLE #temptable (
        ' + @columnDefs + '
        );'
        
        -- Step 4: Print the final result
        PRINT '--- Generated CREATE TABLE Script ---';
        PRINT @print;

--v3
        SELECT 'drop table if exists #temptable'
        SELECT 'CREATE TABLE #temptable ('
        SELECT CONCAT('[',c.name,']  	',t.name,'	('
        ,CASE WHEN t.name IN ('int', 'datetime', 'float') THEN NULL ELSE c.max_length END
        ,')	',CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END)as [schema]
        FROM tempdb.sys.columns AS c
        JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
        WHERE c.object_id = OBJECT_ID('tempdb..#ProcedureOutput')
        SELECT ');'
--v2
        SELECT 'drop table if exists #temptable'
        SELECT 'CREATE TABLE #temptable ('
        SELECT CONCAT('[',c.name,']  	',t.name,'	('
        ,CASE WHEN t.name IN ('int', 'datetime', 'float') THEN NULL ELSE c.max_length END
        ,')	',CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END)as [schema]
        FROM tempdb.sys.columns AS c
        JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
        WHERE c.object_id = OBJECT_ID('tempdb..#ProcedureOutput')
        SELECT ');'
--v1
        SELECT 'drop table if exists #temptable'
        SELECT 'CREATE TABLE #temptable ('
        SELECT 
        CONCAT(
        '['
        ,c.name
        ,']  	'
        ,t.name
        ,'	('
        ,CASE	WHEN t.name IN ('int', 'datetime', 'float')
        		THEN NULL 
        		ELSE c.max_length END
        ,')	'
        ,CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END
        )
        as [use]
        
        FROM tempdb.sys.columns AS c
        JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
        WHERE c.object_id = OBJECT_ID('tempdb..#ProcedureOutput')
        SELECT ');'
--dev
        SELECT 
            c.name AS ColumnName,    t.name AS DataType,    c.max_length,    c.is_nullable
        ,CONCAT(
        '['
        ,c.name
        ,']  	'
        ,t.name
        ,'	('
        ,CASE	WHEN t.name IN ('int', 'datetime', 'float')
        		THEN NULL 
        		ELSE c.max_length END
        ,')	'
        ,CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END
        )
        as [use]
        	,CASE WHEN t.name = 'int' THEN NULL ELSE c.max_length END as [handle int]
        	,CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END as [handle nulls]
        FROM tempdb.sys.columns AS c
        JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
        WHERE c.object_id = OBJECT_ID('tempdb..#ProcedureOutput')


/***-------------------------------------------------------------------------

    Generate / capture output schema of a stored procedure

-------------------------------------------------------------------------***/


/***    This built-in system stored procedure will tell you the metadata of the 
            first result set of a stored procedure or query.
            
        sp_describe_first_result_set does not execute the procedure 

        If procedure uses a temp table or creates it dynamically, this will not work.
            
***/

    EXEC sp_describe_first_result_set 
        @tsql = N'EXEC [DataScience].[powerBI].[usp_SNF_Financial_details_tst]';

/***    Use sp_describe_first_result_set to dynamically build a CREATE TABLE statement ***/

    DECLARE @sql NVARCHAR(MAX) = '';
    DECLARE @proc NVARCHAR(MAX) = N'EXEC [DataScience].[powerBI].[usp_SNF_Financial_details_tst]';
    
    SELECT @sql = STRING_AGG(
        QUOTENAME(name) + ' ' + system_type_name +
        CASE WHEN is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END,
        ', ' + CHAR(13)
    )
    FROM sys.dm_exec_describe_first_result_set(@proc, NULL, 0);
    
    SET @sql = 'CREATE TABLE #YourTempTable (' + CHAR(13) + @sql + CHAR(13) + ');';
    
    PRINT @sql;
    -- Optional to create the temp table : EXEC(@sql) 

/***    Can try this for linked servers ***/

SELECT *
INTO #TempAutoCreated
FROM OPENQUERY([YourLinkedServer], 'EXEC [DataScience].[powerBI].[usp_SNF_Financial_details_tst]');

/***    Can try this but know that SET FMTONLY ON is deprecated 
            Still will not work if proc uses a temp table
***/

SET FMTONLY ON;
EXEC [DataScience].[powerBI].[usp_SNF_Financial_details_tst];
SET FMTONLY OFF;






/***    Could be an option     ***/

-- Enable if not already enabled (requires admin access)
-- EXEC sp_configure 'show advanced options', 1;
-- RECONFIGURE;
-- EXEC sp_configure 'Ad Hoc Distributed Queries', 1;
-- RECONFIGURE;

	drop table if exists #ProcedureOutput

-- Main step:
SELECT *
INTO #ProcedureOutput
FROM OPENROWSET(
    'SQLNCLI',
    'Server=localhost;Trusted_Connection=yes;',
    'EXEC [DataScience].[powerBI].[usp_SNF_Financial_details_tst]'
);


/***

Option : Use a one-time data collector session (manual but clean)

Run the stored procedure normally in SSMS:

EXEC dbo.YourStoredProcedure;


In the Results pane, right-click > Save Results As > CSV.

Use a tool (like Excel, or a T-SQL script) to infer data types and 
generate a CREATE TABLE statement.

This is a one-time manual step, useful if you're trying 
to reverse-engineer the structure.

***/


/***    Create a Dummy Wrapper to Expose Final Temp Table       ***/

-- Mimic the final SELECT (based on reverse engineering)
SELECT TOP 0 * 
INTO #ProcedureOutput
FROM #FinalResult -- If you can access it in the same session

