SELECT DATALENGTH('TEST1                         ')
--vs
SELECT LEN('TEST1                         ')