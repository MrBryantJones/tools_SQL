USE [DataScience]
GO

/****** Object:  StoredProcedure [powerBI].[usp_SNF_Financial_details_tst]    Script Date: 9/12/2025 10:34:10 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



--CREATE proc [powerBI].[usp_SNF_Financial_details_tst]
--	@start_date date = null,
--	@end_date date = null
--as
/***************************************************************************************************
Create Date:		08/06/2024
Author:				James Bennett
Description:		Combines all of the various SAS scripts for the SNF Financial report tab into a single
	script. There are multiple steps, including assembling the date formats, categories, budgets,
	detail, and ultimately the final result output.
Used By:            Used by leadership, for PowerBI Dashboard reporting
Parameter(s):		
	@start_date, optional, defaults to 1/1/2019, beginning of the specified date range of results, based 
	on census date.
	@end_date, optional, defaults to yesterday, end of the the specified date range of results, based
	on census date.

****************************************************************************************************
SUMMARY OF CHANGES
01/27/2025		James Bennett
	Reworked LOS calculations to use existing SAS dataset, due to time limitations on migration
	project.
12/19/2024		James Bennett
	Added optional detail output bit flag as a parameter. Added logic for MTD_LOS and MTD_YearLOS.
10/03/2024		James Bennett
	Reworked report detail to allow null values
	Fixed a couple of formulas using the wrong target for projections
09/05/2024		James Bennett		
	Individual Facility/All FC added.
	Reworked YTD budget formulas based on Selvi's feedback
	Added ADC_Budget_YTD_EOM
08/21/2024		James Bennett	
	Applied several modifications based on Selvi's feedback.
	Second production candidate.
08/06/2024		James Bennett	
	First production candidate. Published for Sevli to review.
08/26/2025		Bryant Jones
	Based on usp_SNF_Financial for the Aging Services Dashboard Rebuild. Present patient details without any aggregates.
***************************************************************************************************/

--/*
--/* For testing manual testing */
--declare @start_date date, @end_date date
--*/

declare @start_date date, @end_date date

/* Default values for optional parameters */
if @start_date is null
	set @start_date = '1/1/2019'

if @end_date is null
	set @end_date = cast(dateadd(day, -1, getdate()) as date)

/* Dates dataset */
--drop table if exists #dates
--select
--d.Year,
--d.Month,
--cast(cast(d.Month as varchar(2)) + '/01/' + cast(d.Year as varchar(4)) as date) as ParameterDate,
--d.MonthDays,
--d.TotalDaysInMonth,
--d.MonthYear,
--d.YearMonth,
--d.YearDays,
--d.TotalDaysInYear,
--d.DaysLeftInMonth,
--d.DaysLeftInYear

--into #dates

--from (

--	select
--	d.Year, 
--	d.Month,
--	case
--		when max(d.Date) < @end_date then count(*)
--		when @end_date between min(d.Date) and max(d.Date) then datepart(day, @end_date)
--		else 0
--	end as MonthDays, 
--	max(d.DayOfMonth) as TotalDaysInMonth,
--	format(max(d.Date), 'MMM yyyy') as MonthYear,
--	format(max(d.Date), 'yyyyMM') as YearMonth,
--	case
--		when max(d.Date) < @end_date then max(d.DayOfYear)
--		else (min(d.DayOfyear) - 1) + datepart(day, @end_date)
--	end as YearDays,
--	max(d.DayOfYear) as TotalDaysInYear,
--	case
--		when max(d.Date) < @end_date then 0
--		when d.Month = datepart(month, @end_date) and d.Year = datepart(year, @end_date) 
--			then datepart(day, @end_date) - datepart(day, @end_date)
--		else max(d.DayOfMonth)
--	end as DaysLeftInMonth,
--	(select max(x.DayOfYear) from dbBrooks_dw.dbo.DimDate x where x.year = year(@end_date)) - 
--		(select case
--			when max(d.Date) < @end_date then max(d.DayOfYear)
--			else (min(d.DayOfyear) - 1) + datepart(day, @end_date)
--		end) as DaysLeftInYear,
--	case
--		when max(d.Date) < @end_date then 1
--		when @end_date between min(d.Date) and max(d.Date) then 1
--		else 0
--	end as InReportingPeriod

--	from dbBrooks_dw.dbo.DimDate d

--	where d.date >= @start_date

--	group by d.Year, d.Month

--) d

--where d.InReportingPeriod = 1

--order by d.Year, d.Month

/* Patient Detail dataset */
drop table if exists #patient_detail

/*	BASIC SET */
/*
--Here is the Actual Admission Logic

WHERE F.FacilityID IN (2,4) AND CI.BeginEffectiveDate IS NOT NULL --AND CI.bed_id > 0 --AND CRA.BedID IS NOT NULL
AND PA.PatientAdmissionKey IS NULL AND (OCC.ShortDescription IN ('A','AA','RA','RC','PC','TI','RL','LC','RAA') OR (OCC.ShortDescription IN ('TO','RR') AND OCC1.ShortDescription IN ('BH','BD','MBH','BHD')))	


-- CI = PCCReporting.dbo.CensusItem
-- OCC = PCCReporting.dbo.view_ods_census_codes

*/


/*	BASIC SET (NOW INCLUDES BARAM LAKES) id 2 , 3 , 4 */

		select
		ci.census_id as CensusID,
		f.health_type as FacilityType, 
		f.name as FacilityName, 
		fc.FinancialClass, 
		c.client_id_number as PatientID,
		r.room_id	as [RoomID],
		r.room_desc	as [RoomName],
		u.unit_iD as [Location_MisLocID],
		b.bed_desc as [BedDesc_RoomCensusBed],
		CONVERT(nvarchar(50),r.floor_id)	as [FloorName],
		ci.effective_date as AdmissionDateTime,
		ci.ineffective_date as DischargeDateTime,
		d.Date as CensusDate,
		cast(datediff(day, ci.effective_date, isnull(ci.ineffective_date, d.Date)) as float) as LOS,
		iif(aa.admit_date is not null, 1, 0) as AdmissionDay,
		iif(cast(dateadd(day, -1, ci.ineffective_date) as date) = cast(d.Date as date), 1, 0) as DischargeDay,
		1 as PatientDay
into #patient_detail
		from PCCReporting.dbo.clients c with (nolock)
			join PCCReporting.dbo.mpi m with (nolock) on m.mpi_id = c.mpi_id
			inner hash join PCCReporting.dbo.census_item ci with (nolock) on ci.client_id = c.client_id				and ci.deleted = 'N'
			join dbBrooks_dw.dbo.DimDate d with (nolock) on d.Date between dateadd(day, -1, ci.effective_date) and isnull(dateadd(day, -1, ci.ineffective_date), dateadd(day, -1, getdate()))
				and d.Date between @start_date and @end_date
			left join ( /* Admission Date */
				select distinct ci.client_id, cast(ci.effective_date as date) as admit_date
				from PCCReporting.dbo.census_item ci with (nolock)
					join PCCReporting.dbo.census_codes cc with (nolock) on cc.item_id = ci.action_code_id
						and cc.action_type = 'Admission' /* AA, RA, RAA */
				where ci.deleted = 'N'
			) aa on aa.client_id = ci.client_id
				and aa.admit_date = d.date
			join PCCReporting.dbo.facility f with (nolock) on f.fac_id = ci.fac_id
				and f.fac_id in (2, 3, 4)
			join PCCReporting.dbo.census_codes ac with (nolock) on ac.item_id = ci.action_code_id
				and (ac.fac_id = -1 or ac.fac_id = ci.fac_id)	
			join PCCReporting.dbo.census_codes sc with (nolock) on sc.item_id = ci.status_code_id
				and (sc.fac_id = -1 or sc.fac_id = ci.fac_id)
			left join PCCReporting.dbo.bed b with (nolock) on b.bed_id = ci.bed_id
			left join PCCReporting.dbo.room r with (nolock) on r.room_id = b.room_id
			left join PCCReporting.dbo.unit u with (nolock) on u.unit_id = r.unit_id
			left join DataScience.dbo.PCCFinancialClassMap fc with (nolock) on fc.PayerID = ci.primary_payer_id	
		where c.deleted = 'N' /* Not deleted */
--and u.unit_desc  LIKE '%GH%'

union all

/* Greenhouse */

		SELECT
		PC.CensusID,
		'SNF' as FacilityType,
		'Green House' as 'FacilityName',
		fc.FinancialClass as 'FinancialClass',
		MP.PatientIDNumber as [PatientID],
		RM.RoomID as RoomID,
		RM.RoomDescription as RoomName,
		U.UnitID as [Location_MisLocID],
		B.BedDesc as [BedDesc_RoomCensusBed],
		CONVERT(nvarchar(50),RM.Floor)	as [FloorName],
		MP.OriginalAdmissionDate as AdmissionDateTime,
		MP.DischargeDate as DischargeDateTime, 
		d.Date as CensusDate,
		cast(datediff(day, MP.OriginalAdmissionDate, isnull(MP.DischargeDate, d.Date)) as float) as LOS,
		iif(aa.admit_date is not null, 1, 0) as AdmissionDay,
		iif(cast(dateadd(day, -1, MP.DischargeDate) as date) = cast(d.Date as date), 1, 0) as DischargeDay,
		1 as PatientDay
		FROM (Select MAX(PatientID) PatientID,MasterPatientID FROM PCCReporting.dbo.view_ods_facility_patient WHERE FacilityID = 3 AND PatientDeleted = 'N' GROUP BY MasterPatientID) MP1
			INNER JOIN PCCReporting.dbo.view_ods_facility_patient MP ON MP.PatientID = MP1.PatientID
			INNER JOIN PCCReporting.dbo.view_ods_patient_census PC ON PC.PatientID = MP1.PatientID AND PC.FacilityID = 3
			INNER JOIN PCCReporting.dbo.view_ods_bed B ON B.BedID = PC.BedID
			INNER JOIN PCCReporting.dbo.view_ods_unit U ON U.UnitID = B.UnitID
			INNER JOIN [PCCReporting].[dbo].[view_ods_census_codes] OCC ON OCC.ItemID = PC.ActionCodeID 	
			INNER JOIN PCCReporting.dbo.view_ods_census_codes OCC1 ON OCC1.ItemID = PC.StatusCodeID	
			INNER JOIN [ClinicalDataRepository].[dbo].[Resident] R ON R.ExternalResidentKey = MP.PatientIDNumber
			JOIN dbBrooks_dw.dbo.DimDate d with (nolock) on d.Date between dateadd(day, -1, MP.OriginalAdmissionDate) and isnull(dateadd(day, -1, MP.DischargeDate), dateadd(day, -1, getdate()))
			AND d.Date between @start_date and @end_date
					left join ( /* Admission Date */
						select distinct PC.PatientID, cast(MP.OriginalAdmissionDate as date) as admit_date
						FROM PCCReporting.dbo.view_ods_facility_patient MP  with (nolock)
							JOIN PCCReporting.dbo.view_ods_patient_census PC with (nolock) ON PC.PatientID = MP.PatientID AND PC.FacilityID = 3
							JOIN [PCCReporting].[dbo].[view_ods_census_codes] OCC with (nolock) ON OCC.ItemID = PC.ActionCodeID
								and OCC.ActionType = 'Admission' /* AA, RA, RAA */
						where OCC.Deleted = 'N' /* Not deleted */
					) aa on aa.PatientID = PC.PatientID
						and aa.admit_date = d.date
			left join DataScience.dbo.PCCFinancialClassMap fc with (nolock) on fc.PayerID = PC.PayerID
			INNER JOIN PCCReporting.[dbo].[view_ods_room] RM ON RM.FloorID = B.FloorID AND RM.UnitID = U.UnitID AND RM.RoomID = B.RoomID
		WHERE MP.DateOfBirth IS NOT NULL
			and U.UnitDescription LIKE '%GH%'


--select * from #patient_detail

select
CensusID, FacilityType, FacilityName, FinancialClass, PatientID, 
RoomID, RoomName, Location_MisLocID, BedDesc_RoomCensusBed, 
FloorName, AdmissionDateTime, DischargeDateTime, CensusDate, LOS, AdmissionDay, DischargeDay, PatientDay
from #patient_detail

EXEC tempdb.sys.sp_help '#patient_detail';
SELECT 
    c.name AS ColumnName,
    t.name AS DataType,
    c.max_length,
    c.is_nullable
FROM tempdb.sys.columns AS c
JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
WHERE c.object_id = OBJECT_ID('tempdb..#patient_detail');


	drop table if exists #ProcedureOutput

SELECT *
INTO #ProcedureOutput
FROM (
    -- your SELECT here
select
				CensusID,			FacilityType,			FacilityName,	FinancialClass,		PatientID,			
				RoomName,			BedDesc_RoomCensusBed,	RoomID,			Location_MisLocID,	FloorName,	
				AdmissionDateTime,	DischargeDateTime,		CensusDate,		LOS,				AdmissionDay,	
				DischargeDay,	/* get from datedim when no admission or discharge */
				PatientDay
from #patient_detail
) AS SourceQuery;

--CensusID, FacilityType, FacilityName, FinancialClass, PatientID, 
--RoomID, RoomName, Location_MisLocID, BedDesc_RoomCensusBed, 
--FloorName, AdmissionDateTime, DischargeDateTime, CensusDate, LOS, AdmissionDay, DischargeDay, PatientDay


--GO


EXEC tempdb.sys.sp_help '#ProcedureOutput'; 

-----------------------------------------------------------------
-----------------------------------------------------------------

-- Build the CREATE TABLE statement using sp_describe_first_result_set

DECLARE @sql NVARCHAR(MAX) = '';
DECLARE @query NVARCHAR(MAX) = N'
    -- your SELECT here
select
				CensusID,			FacilityType,			FacilityName,	FinancialClass,		PatientID,			
				RoomName,			BedDesc_RoomCensusBed,	RoomID,			Location_MisLocID,	FloorName,	
				AdmissionDateTime,	DischargeDateTime,		CensusDate,		LOS,				AdmissionDay,	
				DischargeDay,	/* get from datedim when no admission or discharge */
				PatientDay
from #patient_detail
';

SELECT @sql = STRING_AGG(
    QUOTENAME(name) + ' ' + system_type_name +
    CASE WHEN is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END,
    ',' + CHAR(13)
)
FROM sys.dm_exec_describe_first_result_set(@query, NULL, 0);

SET @sql = '
drop table if exists #temptable

CREATE TABLE #temptable (' + CHAR(13) + @sql + CHAR(13) + ');';

PRINT @sql;
-- Optional: EXEC(@sql);



--------------------------------------------------------------
--------------------------------------------------------------
SELECT 'drop table if exists #temptable'
SELECT 'CREATE TABLE #temptable ('
    EmployeeID INT,
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50)

SELECT 
    c.name AS ColumnName,    t.name AS DataType,    c.max_length,    c.is_nullable
,CONCAT(
'['
,c.name
,']  	'
,t.name		--CASE WHEN t.name = 'int' THEN t.name+'--' ELSE t.name END
,'	('		--c.max_length
,CASE WHEN t.name = 'int' THEN NULL ELSE c.max_length END
,')	'
,CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END
)
as [use]
	--CONCAT('[', c.name, ']', '	', t.name, '	(', c.max_length, ')	', c.is_nullable) as [hold]
	,CASE WHEN t.name = 'int' THEN NULL ELSE c.max_length END as [handle int]
	,CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END as [handle nulls]
FROM tempdb.sys.columns AS c
JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
WHERE c.object_id = OBJECT_ID('tempdb..#ProcedureOutput')
and c.name IN ( 'CensusID' , 'FloorName' )

SELECT ');'

CONCAT(ColumnName, DataType, max_length, is_nullable)
CONCAT(c.name, t.name, c.max_length, c.is_nullable)

	FloorName nvarchar 100
    LastName NVARCHAR(50)

CensusID int 4 0
FloorName nvarchar 100 1

CensusID case when int then -- 4 0
FloorName nvarchar (100) case when 1 then null when 0 then not null


--------------------------------------------------------------
--------------------------------------------------------------










CREATE TABLE #temptable (
[CensusID] int NOT NULL,
[FacilityType] varchar(10) NULL,
[FacilityName] varchar(375) NULL,
[FinancialClass] varchar(100) NULL,
[PatientID] varchar(35) NULL,
[RoomName] varchar(60) NULL,
[BedDesc_RoomCensusBed] varchar(30) NULL,
[RoomID] int NULL,
[Location_MisLocID] int NULL,
[FloorName] nvarchar(50) NULL,
[AdmissionDateTime] datetime NULL,
[DischargeDateTime] datetime NULL,
[CensusDate] datetime NULL,
[LOS] float NULL,
[AdmissionDay] int NOT NULL,
[DischargeDay] int NOT NULL,
[PatientDay] int NOT NULL
);
go
SELECT CONCAT('[',c.name,']  	',t.name,'	('
,CASE WHEN t.name IN ('int', 'datetime', 'float') THEN NULL ELSE c.max_length END
,')	',CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END) as [schema]
FROM tempdb.sys.columns AS c
JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
WHERE c.object_id = OBJECT_ID('tempdb..#ProcedureOutput')

DECLARE @sql NVARCHAR(MAX) = '';
DECLARE @query NVARCHAR(MAX) = N''
DECLARE @print NVARCHAR(MAX) = '';
SET @print = @print + '
drop table if exists #temptable
CREATE TABLE #temptable ('
print @print
SET @query = @query + '
SELECT CONCAT(''['',c.name,'']  	'',t.name,''	(''
,CASE WHEN t.name IN (''int'', ''datetime'', ''float'') THEN NULL ELSE c.max_length END
,'')	'',CASE WHEN c.is_nullable = 1 THEN '' NULL'' ELSE '' NOT NULL'' END) as [schema]
FROM tempdb.sys.columns AS c
JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
WHERE c.object_id = OBJECT_ID(''tempdb..#ProcedureOutput'')
'
--print @query
--exec(@query)
--EXEC sp_executesql @query;
--EXEC sp_executesql @SQL, N'@Result INT OUTPUT', @Result = @Count OUTPUT;
--EXEC sp_executesql @query, N'@result NVARCHAR(MAX) OUTPUT', @result = @sql OUTPUT
print @sql
SET @print = '
);'
print @print
--------------------------------------------------------------
--------------------------------------------------------------
go

-- Step 1: Declare variables
	DECLARE @sql NVARCHAR(MAX) = '';
	DECLARE @print NVARCHAR(MAX) = '';
	DECLARE @columnDefs NVARCHAR(MAX) = '';
-- Step 2: Generate the column definitions from #patient_detail
	-- We use FOR XML PATH to concatenate rows into a single string
	SELECT @columnDefs = STRING_AGG(CONCAT('[' + c.name + '] ',t.name,
	CASE WHEN t.name IN ('int', 'datetime', 'float') THEN '' ELSE '(' + CAST(c.max_length AS VARCHAR) + ')'END,
	CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END ), ', ' + CHAR(13)  -- comma + newline
	)
	FROM tempdb.sys.columns AS c
	JOIN tempdb.sys.types AS t ON c.user_type_id = t.user_type_id
	WHERE c.object_id = OBJECT_ID('tempdb..#patient_detail');
-- Step 3: Assemble the full CREATE TABLE script
SET @print = '
DROP TABLE IF EXISTS #temptable;

CREATE TABLE #temptable (
' + @columnDefs + '
);'
-- Step 4: Print the final result
	PRINT '--- Generated CREATE TABLE Script ---';
	PRINT @print;


--------------------------------------------------------------
--------------------------------------------------------------