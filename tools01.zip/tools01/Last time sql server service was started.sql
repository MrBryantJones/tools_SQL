--The most reliable and direct T-SQL query to find the last time the SQL Server service (Database Engine) was restarted is by using the Dynamic Management View (DMV) sys.dm_os_sys_info:

--SQL

SELECT sqlserver_start_time
FROM sys.dm_os_sys_info;

--This query returns a single value, the date and time when the SQL Server instance last started.

--Alternative Methods
--There are a few other common T-SQL methods that can provide the same or a very similar time:

--1. Using tempdb Creation Time
--Since the tempdb system database is recreated every time the SQL Server service starts, its creation time is essentially the instance's start time.

--SQL

SELECT create_date AS TempDB_Creation_Time
FROM sys.databases
WHERE name = 'tempdb';

--2. Using Session ID 1 Login Time
--Session ID 1 is created when the SQL Server is started, and its login time reflects the service start time.

--SQL

SELECT login_time AS Session_1_Login_Time
FROM sys.dm_exec_sessions
WHERE session_id = 1;

--3. Using sys.dm_server_services (For SQL Server 2012 and later)
--This DMV provides information about all the SQL Server related services and has a specific column for the last startup time. This is useful if you want to check the SQL Server Agent service as well.

--SQL

SELECT 
    @@SERVERNAME as [SERVERNAME], --@@SERVICENAME as [SERVICENAME],
	servicename, 
    last_startup_time
FROM sys.dm_server_services
WHERE servicename LIKE 'SQL Server (%' 
   OR servicename LIKE 'SQL Server Agent (%';

--The parentheses are for named instances (e.g., SQL Server (INSTANCENAME)).