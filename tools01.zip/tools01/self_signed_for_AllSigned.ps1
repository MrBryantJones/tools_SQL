﻿cd "C:\Users\BJones3\Desktop"



<#  EXAMPLE OF NEEDING 

Unblock-File "C:\Users\BJones3\Desktop\EG-Inventory_v1_20251104_1630.ps1"
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
#.\EG-Inventory_v1_20251104_1630.ps1

# Usage
# Basic inventory (logs only)
# Run in an elevated PowerShell (Administrator)
.\EG-Inventory_v1_20251104_1630.ps1 `
  -LogDir "C:\Users\BJones3\Desktop" `
  -SasHome "C:\Program Files\SASHome"

# Include simple port checks to SAS servers
# Add egress tests (optional)
.\EG-Inventory_v1_20251104_1630.ps1 `
  -LogDir "C:\Users\BJones3\Desktop" `
  -SasHome "C:\Program Files\SASHome" `
  -CheckPorts `
  -MetadataHost "sas-meta.example.com" -MetadataPort 8561 `
  -SpawnerHost  "sas-app.example.com"  -SpawnerPort 8591

# Ooooooor this:

#powershell -ExecutionPolicy Bypass -Command "Unblock-File 'C:\Users\BJones3\Desktop\EG-Inventory_v1_20251104_1630.ps1'; & 'C:\Users\BJones3\Desktop\EG-Inventory_v1_20251104_1630.ps1'"


#>







<#

Great call. If your environment enforces AllSigned, the clean way is to sign the scripts so they run without policy tweaks. Below is a “good → better → best” path, with copy-paste PowerShell.

Quick path (self-signed for your box)

Good for testing or a small jumpbox. For many machines, use the Enterprise CA path below.

1) Create a code-signing cert (CurrentUser store)
# Run in an elevated PowerShell
$cert = New-SelfSignedCertificate `
  -Type CodeSigningCert `
  -Subject "CN=BJ Code Signing" `
  -KeyAlgorithm RSA -KeyLength 3072 `
  -CertStoreLocation Cert:\CurrentUser\My

2) Trust your cert (so Windows trusts signatures from it)
$cerPath = "$env:TEMP\bj-codesign.cer"
Export-Certificate -Cert $cert -FilePath $cerPath | Out-Null

# Trust the publisher and the root (needed for self-signed)
Import-Certificate -FilePath $cerPath -CertStoreLocation Cert:\CurrentUser\TrustedPublisher | Out-Null
Import-Certificate -FilePath $cerPath -CertStoreLocation Cert:\CurrentUser\Root | Out-Null

3) Sign your scripts (wrapper + the inventory script)
# Optional but recommended: timestamp so the signature stays valid after the cert expires
$ts = "http://timestamp.digicert.com"

Set-AuthenticodeSignature -FilePath "C:\Path\To\Signed-Run.ps1"    -Certificate $cert -TimestampServer $ts | Out-Null
Set-AuthenticodeSignature -FilePath "C:\Path\To\EG-Inventory.ps1"  -Certificate $cert -TimestampServer $ts | Out-Null


Why sign both? With AllSigned, every script that executes must be signed. A signed wrapper won’t magically exempt an unsigned child script.

Minimal “signed wrapper launcher”

This wrapper checks the child script’s signature (must be Valid) and then runs it. Sign this wrapper too (step 3 above).

# C:\Path\To\Signed-Run.ps1
param(
  [Parameter(Mandatory=$true)]
  [string]$ScriptPath,

  [string[]]$Args
)

if (-not (Test-Path $ScriptPath)) {
  throw "Target script not found: $ScriptPath"
}

# Enforce that the child is signed & valid
$sig = Get-AuthenticodeSignature -FilePath $ScriptPath
if ($sig.Status -ne 'Valid') {
  throw "Target script is not properly signed. Status: $($sig.Status)"
}

# Remove 'downloaded from internet' mark if present (safe)
try { Unblock-File -Path $ScriptPath } catch {}

# Execute
& $ScriptPath @Args


Run it like:

& "C:\Path\To\Signed-Run.ps1" -ScriptPath "C:\Path\To\EG-Inventory.ps1" -Args @("-LogDir","C:\Install\logs")

Enterprise path (best practice, domain-wide)

If you have Active Directory Certificate Services (AD CS) or another enterprise CA:

Request a Code Signing certificate from the enterprise CA (via MMC → Certificates → Current User → Personal → Certificates → All Tasks → Request New Certificate… and select a Code Signing template).

The CA’s root/intermediate are already trusted via domain Group Policy, so you don’t need to import to Trusted Root/Publisher manually.

Sign your scripts exactly as in step 3 above (use your CA-issued cert instead of the self-signed).

Optionally, deploy your signed scripts via ConfigMgr/Intune; they’ll run cleanly under AllSigned.

If your org disallows lowering policy and you can’t sign everything

A signed wrapper can still launch the child using a separate PowerShell process with a one-time bypass (works unless Group Policy blocks it). Less ideal, but sometimes useful:

# Inside your Signed-Run.ps1 (alternative branch)
Start-Process -FilePath powershell.exe `
  -ArgumentList @('-ExecutionPolicy','Bypass','-File',"`"$ScriptPath`"") `
  -Wait


Signing is still preferable.

Quick sanity check

After signing, verify:

Get-AuthenticodeSignature "C:\Path\To\EG-Inventory.ps1" | Select-Object Status, StatusMessage, SignerCertificate


Status should be Valid.

Using the exact path, here is a ready-to-run block that creates the cert, trusts it, and signs those files in one go.



here’s a ready-to-run, one-shot signing setup for your Desktop scripts.
You can copy and paste this entire block into an elevated PowerShell window (Run as Administrator).

# One-time Self-Signing & Trust Setup
# === Create a code signing certificate in your user store ===
$cert = New-SelfSignedCertificate `
  -Type CodeSigningCert `
  -Subject "CN=BJ Code Signing" `
  -KeyAlgorithm RSA -KeyLength 3072 `
  -CertStoreLocation Cert:\CurrentUser\My

# === Export and trust it ===
$cerPath = "$env:TEMP\bj-codesign.cer"
Export-Certificate -Cert $cert -FilePath $cerPath | Out-Null
Import-Certificate -FilePath $cerPath -CertStoreLocation Cert:\CurrentUser\TrustedPublisher | Out-Null
Import-Certificate -FilePath $cerPath -CertStoreLocation Cert:\CurrentUser\Root | Out-Null

# === Paths to your scripts ===
$desktop = "C:\Users\BJones3\Desktop"
$scripts = @(
    "$desktop\EG-Inventory_v1_20251104_1630.ps1",
    "$desktop\EG-Inventory.ps1",
    "$desktop\Signed-Run.ps1"
) | Where-Object { Test-Path $_ }

# === Sign each script with timestamp ===
$ts = "http://timestamp.digicert.com"
foreach ($f in $scripts) {
    Write-Host "Signing $f ..."
    Set-AuthenticodeSignature -FilePath $f -Certificate $cert -TimestampServer $ts | Out-Null
}

Write-Host "`n✅ Signing complete. The following scripts are now trusted:"
$scripts

# What this does

Creates a personal code-signing certificate called “BJ Code Signing.”

Installs it into:

TrustedPublisher (so your system trusts your own signed scripts)

Root (so Windows trusts the cert chain)

Signs all scripts on your Desktop (inventory + wrapper) with a timestamp, so they stay valid even after cert expiration.

# Next steps

You can now safely run:

.\EG-Inventory_v1_20251104_1630.ps1


…and Windows will see it as trusted publisher: BJ Code Signing.

Next generate the matching Signed-Run.ps1 wrapper now (so it can securely launch any signed script you create later)..


This is a clean, security-focused wrapper you can sign once and use to launch any signed script.

# see Download Signed-Run.ps1

What it does

Verifies Authenticode signature of the target script (must be Valid).

Unblocks the file (removes Zone.Identifier) just in case it was downloaded.

Passes through arguments to the target script and returns its exit code.

Typical flow on your Desktop

Save Signed-Run.ps1 to your Desktop and sign it (using the cert you created):

$ts = "http://timestamp.digicert.com"
$desktop = "C:\Users\BJones3\Desktop"
$cert = Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert | Select-Object -First 1

Set-AuthenticodeSignature -FilePath "$desktop\Signed-Run.ps1" -Certificate $cert -TimestampServer $ts | Out-Null
Set-AuthenticodeSignature -FilePath "$desktop\EG-Inventory.ps1" -Certificate $cert -TimestampServer $ts | Out-Null


Run any signed script through the wrapper:

& "C:\Users\BJones3\Desktop\Signed-Run.ps1" `
  -ScriptPath "C:\Users\BJones3\Desktop\EG-Inventory.ps1" `
  -Args @("-LogDir","C:\Install\logs")


..can add an optional -RequirePublisher switch to enforce that the publisher CN of the signed script matches your cert (e.g., CN=BJ Code Signing) for extra assurance.




#>