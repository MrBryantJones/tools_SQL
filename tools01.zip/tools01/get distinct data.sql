/***

	GET DISTINCT DATA

***/

/***	BASE		***/
/***	BASE		***/
/***	BASE		***/

/*		LOAD EXISTING DATA WITH ADDED COLUMNS TO THE HISTORY TABLE			*/

				DROP TABLE IF EXISTS #OPVisit,#OPReferringProvider,#Final, #Compare ; -----------Make sure to clean this up before release !!!!!!!!!!!

				Select PAV.PatientAdmissionKey,EvalCount,CASE TreatmentType WHEN 'PTA' THEN 'PT' WHEN 'COTA' THEN 'OT' ELSE TreatmentType END as TreatmentType INTO #OPVisit FROM ClinicalDataRepository.dbo.PatientAdmissionVisit PAV WITH (NOLOCK) WHERE TreatmentType IS NOT NULL AND PAV.UpdateDate > DATEADD(day,-30,GetDate());
				Select CASE_ID,NPI,EMAILADDRESS INTO #OPReferringProvider FROM OPENQUERY(OP_EMR,'Select CAST(PC.CASE_ID as varchar(20)) as CASE_ID,P.NPI,P.EMAILADDRESS FROM TheraOffice.dbo.PTCASE PC INNER JOIN TheraOffice.dbo.PHYSICIANS P ON P.PHYS_ID = PC.REF_PHYSICIAN WHERE PC.CREATED_ON > DATEADD(day,-30,GetDate())');		
				WITH cteService as (
					Select PatientAdmissionKey,[PT],[OT],[SLP],[PSY] FROM (Select PatientAdmissionKey,EvalCount,TreatmentType FROM #OPVisit) Main PIVOT (MAX(EvalCount) FOR TreatmentType IN ([PT],[OT],[SLP],[PSY])) as PVT	
				)

--Select TOP 10 * FROM BrooksX.EMPI.dbo.EMPITranTable
		Select DISTINCT E.FName as PatientFirstName,
		E.LName as PatientLastName,
		E.DOB as PatientDateOfBirth
		,ETT.Add1 as PatientAddressStreet,
		ETT.City as PatientAddressCity,
		ETT.St as PatientAddressState,
		ETT.Zip as PatientAddressZip
		,ETT.PatientEmail as PatientEmail
		,ETT.HmPhone as PatientPhone
		,SL.Division
		,RF.FacilityName as ReferringFacility
		,AF.FacilityName as AdmissionFacility
		,FORMAT(PA.AdmissionDateTime,'MM-dd-yyyy hh:mm:ss tt') as AdmissionDate
		,FORMAT(PA.DischargeDateTime,'MM-dd-yyyy hh:mm:ss tt') as DischargeDate
		,DF.FacilityName as DischargeFacility
		,POC.FirstName as ContactFirstName
		,POC.LastName as ContactlastName
		,'' as ContactRelationship
		,POC.EmailAddress as ContactEmail
		,POC.PhoneNumber1Type	-- Added 20250930	--goes with POC.PhoneNumber1 as  ContactPhone
		,POC.PhoneNumber1 as  ContactPhone
		,CT.ContactDescription as  ContactDescription
		--,POC.RankSequence as ContactOrder			--- Remove 20250929
		--try these added
		,POC.Gender	-- Added 20250930		
		,POC.PhoneNumber2Type	-- Added 20250930
		,POC.PhoneNumber2	-- Added 20250930	
		--
		,IPD.RIC
		,RIC.RICDesc as RIC_Description
		,COALESCE(IPD.PROG,REPLACE(IIF(SVC.[PT] IS NULL,'','PT ') + IIF(SVC.[OT] IS NULL,'','OT ') + IIF(SVC.[SLP] IS NULL,'','SLP ') + IIF(SVC.[PSY] IS NULL,'', 'PSY'),' ',',')) as ServiceProgram
		,PA.ImpairmentCode
		,P.EMPIKey as PatientEMPI
		,CP.ProviderName as DoctorAttending
		,CP.NPI as PhysicianNPI
		,RP.NPI as ReferringPhysicianNPI
		--,RP.EMAILADDRESS as ReferringPhysicianEmail
		,FC.FinancialClassName as FinancialClass
		INTO #Final
		FROM BrooksX.EMPI.dbo.EMPI E WITH (NOLOCK)
		INNER JOIN BrooksX.EMPI.dbo.EMPITranTable ETT WITH (NOLOCK) ON ETT.EMPID = E.ID
		INNER JOIN ClinicalDataRepository.dbo.Patient P WITH (NOLOCK) ON P.EMPIKey = E.ID
		INNER JOIN ClinicalDataRepository.dbo.PatientAdmission PA WITH (NOLOCK) ON PA.ExternalAdmissionKey = ETT.SEpisodeNum AND PA.MedicalRecordSystemKey = ETT.SHIS
		INNER JOIN BrooksX.EMPI.dbo.SHISList SL WITH (NOLOCK) ON SL.ID = ETT.SHIS
		LEFT OUTER JOIN ClinicalDataRepository.dbo.Facility RF ON RF.FacilityKey = PA.ReferralFacilityKey
		LEFT OUTER JOIN ClinicalDataRepository.dbo.Facility AF ON AF.FacilityKey = PA.AdmissionFacilityKey
		LEFT OUTER JOIN ClinicalDataRepository.dbo.Facility DF ON DF.FacilityKey = PA.DischargeFacilityKey
		LEFT OUTER JOIN ClinicalDataRepository.dbo.PatientOtherContact POC WITH (NOLOCK) ON POC.PatientKey = P.PatientKey AND POC.RankSequence = 1 AND POC.ContactTypeKey = 1 --Emergency
		LEFT OUTER JOIN PlanningData.dbo.BRH_IP_Data IPD WITH (NOLOCK) ON IPD.AcctNumber = PA.ExternalAdmissionKey
		LEFT OUTER JOIN cteService SVC ON SVC.PatientAdmissionKey = PA.PatientAdmissionKey
		LEFT OUTER JOIN ClinicalDataRepository.dbo.ClinicalProvider CP WITH (NOLOCK) ON CP.ClinicalProviderKey = PA.attendingProviderKey
		LEFT OUTER JOIN #OPReferringProvider RP ON RP.CASE_ID = PA.ExternalAdmissionKey AND PA.MedicalRecordSystemKey = 7 --Outpatient
		LEFT OUTER JOIN ClinicalDataRepository.dbo.PatientAdmissionInsurance PAI WITH (NOLOCK) ON PAI.PatientAdmissionKey = PA.PatientAdmissionKey AND PAI.InsuranceOrder =1 AND PAI.isActive = 1
		LEFT OUTER JOIN ClinicalDataRepository.dbo.InsuranceProvider INS WITH (NOLOCK) ON INS.InsuranceProviderKey = PAI.InsuranceProviderKey
		LEFT OUTER JOIN ClinicalDataRepository.dbo.FinancialClass FC WITH (NOLOCK) ON FC.FinancialClassKey = INS.FinancialClassKey
		LEFT OUTER JOIN [DataScience].[dxorder].[RIC] RIC WITH (NOLOCK) ON RIC.RIC = IPD.RIC
		LEFT OUTER JOIN [ClinicalDataRepository].[dbo].[ContactType] CT WITH (NOLOCK) ON CT.ContactTypeKey = POC.ContactTypeKey
		WHERE PA.AdmissionDateTime >= DATEADD(day,-3,GetDate()) OR PA.DischargeDateTime >= DATEADD(day,-3,GetDate())

/*-- --	dupes in #Final	-- --
			select 
						ContactPhone,
						COUNT(*) as count 
						from #Final where 1=1
						and ContactPhone is not null
			GROUP BY	ContactPhone
			Having COUNT(*) > 1
			order by	count desc
--*/

--		
select * from #Final where 1=1 and ContactPhone = '360-350-9926' --'309-648-6293'	--'904-600-8590'	--'309-648-6293'

--	--	example max patient and contact	--	--
			select 
			--	--	max patient and contact	--	--
			--	select distinct
			max(PatientFirstName),	max(PatientLastName),	max(PatientDateOfBirth),	max(PatientAddressStreet),	max(PatientAddressCity), max(PatientAddressState),	max(PatientAddressZip),	max(PatientEmail),	max(PatientPhone)
			,max(ContactFirstName),	
			max(ContactlastName),	max(ContactRelationship),	max(ContactEmail),	max(ContactPhone),	max(ContactDescription),	max(ContactOrder),	max(Gender),	max(PhoneNumber1Type),	max(PhoneNumber2),	max(PhoneNumber2Type)
			from #Final where 1=1 and ContactPhone = '360-350-9926' --'309-648-6293'	--'904-600-8590'	--'309-648-6293'


;WITH RankedContacts AS (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY ContactPhone ORDER BY ContactFirstName) AS rn
		   --ROW_NUMBER() OVER (PARTITION BY ContactPhone ORDER BY PatientEMPI) AS rn
    FROM #Final
)
SELECT 
		PatientFirstName,	PatientLastName,	PatientDateOfBirth,	PatientAddressStreet,	PatientAddressCity,	
		PatientAddressState,	PatientAddressZip,	PatientEmail,	PatientPhone,	Division,	ReferringFacility,	
		AdmissionFacility,	AdmissionDate,	DischargeDate,	DischargeFacility,	ContactFirstName,	
		ContactlastName,	ContactRelationship,	ContactEmail,	ContactPhone,	ContactDescription,	
		ContactOrder,	Gender,	PhoneNumber1Type,	PhoneNumber2,	PhoneNumber2Type,	RIC,	RIC_Description,	
		ServiceProgram,	ImpairmentCode,	PatientEMPI,	DoctorAttending,	PhysicianNPI,	ReferringPhysicianNPI,	FinancialClass
FROM RankedContacts
WHERE rn = 1

		AND ContactFirstName is not null
		and ContactPhone = '360-350-9926' --'309-648-6293'	--'904-600-8590'	--'309-648-6293'
		and PatientPhone is not null
;

/*-- --	no dupes in cte	--	--
			select 
						ContactPhone,
						COUNT(*) as count 
						from RankedContacts where 1=1
						and ContactPhone is not null
					and rn = 1
			GROUP BY	ContactPhone
			Having COUNT(*) > 1
			order by	count desc
*/


/***	Anything much in the xxx ???		***/

--select * from #Final where 1=1	--1,014 records
--and Gender				is not null	-- 3 records
--and PhoneNumber1Type	is not null	-- 290 records (goes with ContactPhone)
--and PhoneNumber2Type	is not null	-- 3 records
--and PhoneNumber2		is not null	-- 3 records




















/***--	--	work with examples	--	--

--	--	example patient and contact	--	--
			select 
			--	--	distinct patient and contact	--	--
			--	select distinct
			PatientFirstName,	PatientLastName,	PatientDateOfBirth,	PatientAddressStreet,	PatientAddressCity, PatientAddressState,	PatientAddressZip,	PatientEmail,	PatientPhone
			,ContactFirstName,	
			ContactlastName,	ContactRelationship,	ContactEmail,	ContactPhone,	ContactDescription, ContactOrder,	Gender,	PhoneNumber1Type,	PhoneNumber2,	PhoneNumber2Type
			from #Final where 1=1 and ContactPhone = '309-648-6293'	--'904-600-8590'	--'309-648-6293'

			select distinct
			PatientFirstName,	PatientLastName,	PatientDateOfBirth,	PatientAddressStreet,	PatientAddressCity, PatientAddressState,	PatientAddressZip,	PatientEmail,	PatientPhone
			--,ContactFirstName,	
			ContactlastName,	ContactRelationship,	ContactEmail,	ContactPhone,	ContactDescription, ContactOrder,	Gender,	PhoneNumber1Type,	PhoneNumber2,	PhoneNumber2Type
			from #Final where 1=1 and ContactPhone = '309-648-6293'	--'904-600-8590'	--'309-648-6293'

--	--	example max patient and contact	--	--
			select 
			--	--	max patient and contact	--	--
			--	select distinct
			max(PatientFirstName),	max(PatientLastName),	max(PatientDateOfBirth),	max(PatientAddressStreet),	max(PatientAddressCity), max(PatientAddressState),	max(PatientAddressZip),	max(PatientEmail),	max(PatientPhone)
			,max(ContactFirstName),	
			max(ContactlastName),	max(ContactRelationship),	max(ContactEmail),	max(ContactPhone),	max(ContactDescription),	max(ContactOrder),	max(Gender),	max(PhoneNumber1Type),	max(PhoneNumber2),	max(PhoneNumber2Type)
			from #Final where 1=1 and ContactPhone = '309-648-6293'	--'904-600-8590'	--'309-648-6293'



		;with cte as (
						select distinct
						PatientFirstName,	PatientLastName,	PatientDateOfBirth,	PatientAddressStreet,	PatientAddressCity,	
						PatientAddressState,	PatientAddressZip,	PatientEmail,	PatientPhone,	Division,	ReferringFacility,	
						AdmissionFacility,	AdmissionDate,	DischargeDate,	DischargeFacility,	ContactFirstName,	
						ContactlastName,	ContactRelationship,	ContactEmail,	ContactPhone,	ContactDescription,	
						ContactOrder,	Gender,	PhoneNumber1Type,	PhoneNumber2,	PhoneNumber2Type,	RIC,	RIC_Description,	
						ServiceProgram,	ImpairmentCode,	PatientEMPI,	DoctorAttending,	PhysicianNPI,	ReferringPhysicianNPI,	FinancialClass
						from #Final where 1=1 and ContactPhone = '309-648-6293'
		)
		--select Top 1 --
		select distinct 
		PatientFirstName,	PatientLastName,	PatientDateOfBirth,	PatientAddressStreet,	PatientAddressCity,	
		PatientAddressState,	PatientAddressZip,	PatientEmail,	PatientPhone,	Division,	ReferringFacility,	
		AdmissionFacility,	AdmissionDate,	DischargeDate,	DischargeFacility,	ContactFirstName,	
		ContactlastName,	ContactRelationship,	ContactEmail,	ContactPhone,	ContactDescription,	
		ContactOrder,	Gender,	PhoneNumber1Type,	PhoneNumber2,	PhoneNumber2Type,	RIC,	RIC_Description,	
		ServiceProgram,	ImpairmentCode,	PatientEMPI,	DoctorAttending,	PhysicianNPI,	ReferringPhysicianNPI,	FinancialClass
		from cte where 1=1 and ContactPhone = '309-648-6293'
--
		;with cte2 as (
		    SELECT DISTINCT ContactFirstName, ContactPhone
		    FROM #Final WHERE 1=1
				and ContactPhone = '309-648-6293'
				AND ContactFirstName is not null
		)
		SELECT TOP 1 ContactFirstName, ContactPhone
		from cte2
--
		SELECT TOP 1 ContactFirstName, ContactPhone
		FROM (
		    SELECT DISTINCT ContactFirstName, ContactPhone
		    FROM #Final WHERE 1=1
				and ContactPhone = '309-648-6293'
				AND ContactFirstName is not null
		) AS DistinctNames
		WHERE 1=1
		AND ContactFirstName is not null
		ORDER BY ContactFirstName;
--
		SELECT TOP 1 ContactFirstName, ContactPhone
		FROM #Final WHERE 1=1
		and ContactPhone = '309-648-6293'
		AND ContactFirstName is not null
		GROUP BY ContactFirstName, ContactPhone
		ORDER BY COUNT(*) DESC;
--
		SELECT TOP 1 ContactFirstName, ContactPhone
		FROM (
		    SELECT DISTINCT ContactFirstName, ContactPhone
		    FROM #Final WHERE 1=1
				and ContactPhone is not null
				AND ContactFirstName is not null
		) AS DistinctNames
		WHERE 1=1
		AND ContactFirstName is not null
		and ContactPhone = '309-648-6293'
		ORDER BY ContactFirstName;
--
		SELECT TOP 1 ContactFirstName, ContactPhone
		FROM #Final WHERE 1=1
		AND ContactFirstName is not null
		GROUP BY ContactFirstName, ContactPhone
		ORDER BY COUNT(*) DESC;
--

;WITH RankedContacts AS (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY ContactPhone ORDER BY ContactFirstName) AS rn
		   --ROW_NUMBER() OVER (PARTITION BY ContactPhone ORDER BY PatientEMPI) AS rn
    FROM #Final
)
SELECT 
		PatientFirstName,	PatientLastName,	PatientDateOfBirth,	PatientAddressStreet,	PatientAddressCity,	
		PatientAddressState,	PatientAddressZip,	PatientEmail,	PatientPhone,	Division,	ReferringFacility,	
		AdmissionFacility,	AdmissionDate,	DischargeDate,	DischargeFacility,	ContactFirstName,	
		ContactlastName,	ContactRelationship,	ContactEmail,	ContactPhone,	ContactDescription,	
		ContactOrder,	Gender,	PhoneNumber1Type,	PhoneNumber2,	PhoneNumber2Type,	RIC,	RIC_Description,	
		ServiceProgram,	ImpairmentCode,	PatientEMPI,	DoctorAttending,	PhysicianNPI,	ReferringPhysicianNPI,	FinancialClass
FROM RankedContacts
WHERE rn = 1

		--AND ContactFirstName is not null
		--and ContactPhone = '309-648-6293'
;





--	--	example patient and contact	--	--
			select 
			PatientFirstName,	PatientLastName,	PatientDateOfBirth,	PatientAddressStreet,	PatientAddressCity, PatientAddressState,	PatientAddressZip,	PatientEmail,	PatientPhone
			,--ContactFirstName,	
			ContactlastName,	ContactRelationship,	ContactEmail,	ContactPhone,	ContactDescription, ContactOrder,	Gender,	PhoneNumber1Type,	PhoneNumber2,	PhoneNumber2Type
			from #Final where 1=1 and ContactPhone = '309-648-6293'	--'904-600-8590'	--'309-648-6293'
--	--	example max patient and contact	--	--
			select 
			max(PatientFirstName),	max(PatientLastName),	max(PatientDateOfBirth),	max(PatientAddressStreet),	max(PatientAddressCity), max(PatientAddressState),	max(PatientAddressZip),	max(PatientEmail),	max(PatientPhone)
			,--ContactFirstName,	
			max(ContactlastName),	max(ContactRelationship),	max(ContactEmail),	max(ContactPhone),	max(ContactDescription),	max(ContactOrder),	max(Gender),	max(PhoneNumber1Type),	max(PhoneNumber2),	max(PhoneNumber2Type)
			from #Final where 1=1 and ContactPhone = '309-648-6293'	--'904-600-8590'	--'309-648-6293'
--	--	distinct patient and contact	--	--
			select distinct
			PatientFirstName,	PatientLastName,	PatientDateOfBirth,	PatientAddressStreet,	PatientAddressCity, PatientAddressState,	PatientAddressZip,	PatientEmail,	PatientPhone
			,--ContactFirstName,	
			ContactlastName,	ContactRelationship,	ContactEmail,	ContactPhone,	ContactDescription, ContactOrder,	Gender,	PhoneNumber1Type,	PhoneNumber2,	PhoneNumber2Type
			from #Final where 1=1 and ContactPhone = '309-648-6293'	--'904-600-8590'	--'309-648-6293'
--	--	max patient and contact	--	--
			select distinct
			max(PatientFirstName),	max(PatientLastName),	max(PatientDateOfBirth),	max(PatientAddressStreet),	max(PatientAddressCity), max(PatientAddressState),	max(PatientAddressZip),	max(PatientEmail),	max(PatientPhone)
			,--ContactFirstName,	
			max(ContactlastName),	max(ContactRelationship),	max(ContactEmail),	max(ContactPhone),	max(ContactDescription),	max(ContactOrder),	max(Gender),	max(PhoneNumber1Type),	max(PhoneNumber2),	max(PhoneNumber2Type)
			from #Final where 1=1 and ContactPhone = '309-648-6293'	--'904-600-8590'	--'309-648-6293'


***/


--		select distinct ContactOrder, ContactFirstName,	ContactLastName,	ContactRelationship,	ContactEmail,	ContactPhone,	ContactDescription	from #Final where 1=1 and ContactPhone = '309-648-6293'


/*-- --	check for dupes	-- --
			select 
						ContactPhone,
						COUNT(*) as count 
						from #Final where 1=1
						and ContactPhone is not null
			GROUP BY	ContactPhone
			Having COUNT(*) > 1
			order by	count desc
--*/





/***	xxx		***/
/***	xxx		***/
/***	xxx		***/

/***	xxx		***/
/***	xxx		***/
/***	xxx		***/

/***	xxx		***/
/***	xxx		***/
/***	xxx		***/

/***	xxx		***/
/***	xxx		***/
/***	xxx		***/

/***	xxx		***/
/***	xxx		***/
/***	xxx		***/