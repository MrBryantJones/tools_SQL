﻿# test-netconnection CXPVWAPPRBR5K03 -port 1433

# connect to SSMS
#      CXPVWAPPRBR5K03,1433

# test-netconnection CXPVWAPPRBR5K03 -port 64814

#test-netconnection CXPVWAPPRBR5K01 -port 50689

# connect to SSMS
#      CXPVWAPPRBR5K03,64814 