<#
.SYNOPSIS
  Signed wrapper to launch a target PowerShell script securely.
  - Verifies the target script has a Valid Authenticode signature.
  - Unblocks the file if it has Zone.Identifier.
  - Passes through any arguments to the target script.
#>

[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)]
  [string]$ScriptPath,

  [Parameter(Mandatory=$false)]
  [string[]]$Args
)

if (-not (Test-Path $ScriptPath)) {
  throw "Target script not found: $ScriptPath"
}

$sig = Get-AuthenticodeSignature -FilePath $ScriptPath
if ($sig.Status -ne 'Valid') {
  throw "Target script is not properly signed. Status: $($sig.Status)."
}

try { Unblock-File -Path $ScriptPath -ErrorAction SilentlyContinue } catch {}

& $ScriptPath @Args
exit $LASTEXITCODE
