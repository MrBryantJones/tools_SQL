/*

	SELECT * FROM [DataScience].[LeadSquared].[PatientDataForExtract_History]

*/

USE [DataScience]
GO

/****** Object:  Table [LeadSquared].[PatientDataForExtract_History]    Script Date: 8/14/2025 2:30:35 PM ******/


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[LeadSquared].[PatientDataForExtract_History]') AND type in (N'U'))
DROP TABLE [LeadSquared].[PatientDataForExtract_History]
GO

/****** Object:  Table [LeadSquared].[PatientDataForExtract_History]    Script Date: 8/18/2025 3:32:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [LeadSquared].[PatientDataForExtract_History](
	[ID]							[BIGINT] IDENTITY(1,1) NOT NULL , --PRIMARY KEY,
	[BatchID]						[BIGINT] NOT NULL , --<NEW> [BIGINT] [INT]  <fk>? CONSTRAINT FK_ChildTable_ParentID FOREIGN KEY (ParentID) REFERENCES ParentTable (ParentID)
	[PatientFirstName]				[VARCHAR](200) NULL ,
	[PatientLastName]				[VARCHAR](200) NULL ,
	[PatientDateOfBirth]			[VARCHAR](100) NULL ,
	[PatientAddressStreet]			[NVARCHAR](100) NULL ,
	[PatientAddressCity]			[NVARCHAR](50) NULL , 
	[PatientAddressState]			[NVARCHAR](50) NULL , 
	[PatientAddressZip]				[NVARCHAR](50) NULL ,	  
	[PatientEmail]					[VARCHAR](255) NULL ,		  
	[PatientPhone]					[NVARCHAR](50) NULL ,	
	[Division]						[VARCHAR](25) NULL ,
	[ReferringFacility]				[VARCHAR](200) NULL , 
	[AdmissionFacility]				[VARCHAR](200) NULL , 
	[AdmissionDate]					[DATETIME] NULL ,
	[DischargeDate]					[DATETIME] NULL ,
	[DischargeFacility]				[VARCHAR](200) NULL , 
	[EmergencyContactFirstName]		[VARCHAR](150) NULL ,
	[EmergencyContactlastName]		[VARCHAR](150) NULL ,
	[EmergencyContactRelationship]	[VARCHAR](2) NULL ,
	[EmergencyContactEmail]			[VARCHAR](200) NULL ,
	[EmergencyContactPhone]			[VARCHAR](30) NULL ,
	[RankSequence]					[INT] NULL , --<new> need to add into load
	[EmergencyContactDescription]	[VARCHAR](100) NULL , --<new>
	[RIC]							[NVARCHAR](250) NULL , 
	[RIC_DESC]						[NVARCHAR](250) NULL ,  --<new>
	[ServiceProgram]				[NVARCHAR](250) NULL ,
	[ImpairmentCode]				[VARCHAR](10) NULL ,
	[PatientEMPI]					[INT] NOT NULL ,
	[DoctorAttending]				[VARCHAR](150) NULL ,
	[PhysicianNPI]					[VARCHAR](25) NULL ,
	[ReferringPhysicianNPI]			[NVARCHAR](10) NULL ,
	[FinancialClass]				[VARCHAR](50) NULL , 
	[NewRecord]						[BIT] NULL DEFAULT 0 , --<new>
	[Sent]							[BIT] NULL DEFAULT 0 , --<new>
	[LoadDate]						[DATETIME] DEFAULT GETDATE()
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

/*
--ID INT IDENTITY(1, 1) PRIMARY KEY,  
--IDENTITY (seed , increment) --[Seed]: This is the starting value for the identity column. The first row inserted into the table will receive this value. [Increment]: This is the value that is added to the previous identity value to generate the next value for subsequent rows.
--IDENTITY(1, 1) specifies that the ID column will start with the value 1 (seed) and increment by 1 (increment) for each new record. If no seed and increment values are provided, both default to 1. For example, IDENTITY is equivalent to IDENTITY(1, 1).
--ID BIGINT IDENTITY(seed, increment) NOT NULL PRIMARY KEY
--ID BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY
--CONSTRAINT FK_ChildTable_ParentID FOREIGN KEY (ParentID) REFERENCES ParentTable (ParentID)


--PatientOtherContactKey	PatientKey	ContactTypeKey	FirstName	LastName	Gender	EmailAddress	PhoneNumber1	PhoneNumber1Type	PhoneNumber2	PhoneNumber2Type	RankSequence	SystemUpdateDate
--68387						18			5				Frances		Green		F						904-608-1452	HOME				NULL			NULL				5				NULL
--Name	Policy Health State
--PatientOtherContactKey (PK, int, not null)	
--PatientKey (FK, int, not null)	
--ContactTypeKey (int, not null)	
--FirstName (varchar(150), null)	
--LastName (varchar(150), null)	
--Gender (varchar(15), null)	
--EmailAddress (varchar(200), null)	
--PhoneNumber1 (varchar(30), null)	
--PhoneNumber1Type (varchar(25), null)	
--PhoneNumber2 (varchar(30), null)	
--PhoneNumber2Type (varchar(25), null)	
--RankSequence (int, null)	
--SystemUpdateDate (datetime, null)	
*/

/*----------------------------------------------------------------------------------

--- COLUMNS WITH DEFAULT VALUES IN TABLE	------------

CREATE TABLE YourTableName (
    ID INT PRIMARY KEY IDENTITY(1,1),
    YourDataColumn VARCHAR(255),
	[Sent]							[BIT] NULL DEFAULT 0 ,
    DateCreated DATETIME DEFAULT GETDATE()
);

--- MAKE CHANGES TO COLUMNS IN TABLE	------------

ALTER TABLE [DataScience].[LeadSquared].[PatientDataForExtract_History]
ADD [NewRecordFlag] [BIT] NULL;

ALTER TABLE [DataScience].[LeadSquared].[PatientDataForExtract_History]
DROP COLUMN IF EXISTS NewRecordFlag;

ALTER TABLE [DataScience].[LeadSquared].[PatientDataForExtract_History]
ADD [NewRecordFlag] [BIT] NULL DEFAULT 0;

ALTER TABLE YourTableName
ADD DateCreated DATETIME DEFAULT GETDATE();

ALTER TABLE YourTableName
ADD DateCreated DATETIME NOT NULL DEFAULT GETDATE();

ALTER TABLE table_name
DROP COLUMN column_name;

ALTER TABLE table_name
DROP COLUMN column_name1, column_name2, column_name3;

    ALTER TABLE table_name
    DROP COLUMN IF EXISTS column_name;

--- FOREIGN KEY IN TABLE	------------

Foreign Key :

CREATE TABLE ParentTable (
    ParentID INT PRIMARY KEY,
    ParentName VARCHAR(50)
);

CREATE TABLE ChildTable (
    ChildID INT PRIMARY KEY,
    ChildName VARCHAR(50),
    ParentID INT,
    CONSTRAINT FK_ChildTable_ParentID FOREIGN KEY (ParentID) REFERENCES ParentTable (ParentID)
);

- ParentTable is created with ParentID as its primary key.
- ChildTable is created with a ParentID column.
- CONSTRAINT FK_ChildTable_ParentID FOREIGN KEY (ParentID) REFERENCES ParentTable (ParentID) defines the foreign key:
    - FK_ChildTable_ParentID is the name of the foreign key constraint.
    - FOREIGN KEY (ParentID) specifies that ParentID in ChildTable is the foreign key.
    - REFERENCES ParentTable (ParentID) indicates that this foreign key references the ParentID column in ParentTable.

Add Foreign Key : 

ALTER TABLE ChildTable
ADD CONSTRAINT FK_ChildTable_ParentID FOREIGN KEY (ParentID) REFERENCES ParentTable (ParentID);

Add foreign key constraint to the ChildTable on the ParentID column, referencing the ParentID in ParentTable.

Key Considerations:

Referenced Table and Column:
The table and column referenced by the foreign key must already exist and the referenced column must be a primary key or a unique key in the referenced table.

Data Types:
The data types of the foreign key column(s) in the referencing table and the referenced column(s) in the referenced table must match.

ON DELETE/ON UPDATE Actions:
You can specify actions to take when a referenced row in the parent table is deleted or updated 
(e.g., ON DELETE CASCADE, ON UPDATE CASCADE, ON DELETE SET NULL, ON UPDATE SET DEFAULT, ON DELETE NO ACTION, ON UPDATE NO ACTION).

--- UPDATE TABLE	------------

SELECT * FROM [LeadSquared].[PatientDataForExtract_History] WHERE NewRecordFlag IS NULL

UPDATE [DataScience].[LeadSquared].[PatientDataForExtract_History]
SET NewRecordFlag = 1
WHERE NewRecordFlag IS NULL;

SELECT * FROM [LeadSquared].[PatientDataForExtract_History] WHERE NewRecordFlag IS NULL

--- TRUNCATE TABLE	------------

		SELECT * FROM [DataScience].[LeadSquared].[PatientDataForExtract_History]
		
		TRUNCATE TABLE [DataScience].[LeadSquared].[PatientDataForExtract_History]

		SELECT * FROM [DataScience].[LeadSquared].[PatientDataForExtract_History]

--- BACK UP TABLE	------------

SELECT * INTO [DataScience].[LeadSquared].[PatientDataForExtract_Work] FROM [DataScience].[LeadSquared].[PatientDataForExtract_History]

SELECT * FROM [DataScience].[LeadSquared].[PatientDataForExtract_Work]

---

*/----------------------------------------------------------------------------------