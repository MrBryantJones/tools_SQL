/******BEGIN TABLE/DATA SET UP********/

SET NOCOUNT ON

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TargetAddress_LookupStateProvince_StateProvinceID]') AND parent_object_id = OBJECT_ID(N'[dbo].[TargetAddress]'))
ALTER TABLE [dbo].[TargetAddress] DROP CONSTRAINT [FK_TargetAddress_LookupStateProvince_StateProvinceID]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TargetAddress]') AND type in (N'U'))
DROP TABLE [dbo].[TargetAddress]
GO
CREATE TABLE dbo.[TargetAddress]
(
 AddressID int IDENTITY(1,1) NOT NULL,
 AddressLine1 nvarchar(60) NOT NULL,
 AddressLine2 nvarchar(60) NULL,
 City nvarchar(30) NOT NULL,
 StateProvinceID int NOT NULL,
 PostalCode nvarchar(15) NOT NULL,
 CONSTRAINT [PK_TargetAddress_AddressID] PRIMARY KEY CLUSTERED 
(	[AddressID] ASC ) 
) ON [PRIMARY]

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupStateProvince]') AND type in (N'U'))
DROP TABLE [dbo].[LookupStateProvince]
GO
CREATE TABLE dbo.[LookupStateProvince]
(
StateProvinceID int IDENTITY(1,1) NOT NULL,
StateProvinceCode nchar(3) NOT NULL,
 CONSTRAINT [PK_LookupStateProvince_StateProvinceID] PRIMARY KEY CLUSTERED 
(	[StateProvinceID] ASC )
) ON [PRIMARY]

ALTER TABLE dbo.[TargetAddress]  WITH CHECK ADD  CONSTRAINT [FK_TargetAddress_LookupStateProvince_StateProvinceID] FOREIGN KEY([StateProvinceID])
REFERENCES dbo.[LookupStateProvince] ([StateProvinceID])
GO


INSERT INTO dbo.LookupStateProvince
SELECT 'NY'
UNION SELECT 'NJ'
UNION SELECT 'NV'
UNION SELECT 'NB'

/**After inserting this data, 
	any record inserted into the TargetAddress table
	must have a value of 1,2,3, or 4
	in the StateProvinceID column
	because of the foreign key reference
**/


/**Create a source table that represents
	the data that we need to load.
	In actual practice, this might be
	a temporary table, a permanent staging table,
	an OPENROWSET query to another data source,
	or any other table-valued data source.

	We can assume that the source might contain data
	that is not loadable because it is missing required values
	or contains data that does not conform to referential integrity.
**/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SourceAddress]') AND type in (N'U'))
DROP TABLE [dbo].[SourceAddress]
GO
CREATE TABLE dbo.[SourceAddress]
(SourceRowIdentifier int IDENTITY(1579,1) NOT NULL,
 SourceAddressLine1 nvarchar(60) NULL,
 SourceAddressLine2 nvarchar(60) NULL,
 SourceCity nvarchar(30) NULL,
 SourceStateProvinceID int NULL,
 SourcePostalCode nvarchar(15) NULL,
 LoadTime datetime NULL,
 BatchID int NULL
)

INSERT INTO dbo.[SourceAddress]
( SourceAddressLine1, SourceAddressLine2,
 SourceCity, SourceStateProvinceID,
 SourcePostalCode)
SELECT 'PO BOX 1','RTE 1', 'MILLVILLE', 4, '11011'
UNION SELECT 'PO BOX 2','RTE 2', 'PLEASANTVILLE',NULL,'10101'
UNION SELECT NULL,'RTE 3', 'HUDSON',2,'10202'
UNION SELECT 'PO BOX 4', 'RTE 4',NULL,3,'87654-1011'
UNION SELECT 'PO BOX 5',NULL,'LAS VEGAS',9,'90056'

/**THESE DATA RECORDS HAVE NO ERRORS, SO WILL BE PROCESSED COMPLETELY BY SET-BASED STATEMENTS
You can test with these records and see the difference

TRUNCATE TABLE dbo.[SourceAddress]
TRUNCATE TABLE dbo.[ETLErrorLog]

INSERT INTO dbo.[SourceAddress]
( SourceAddressLine1, SourceAddressLine2,
 SourceCity, SourceStateProvinceID,
 SourcePostalCode)
SELECT 'PO BOX 1','RTE 1', 'MILLVILLE', 4, '11011'
UNION SELECT 'PO BOX 2','RTE 2', 'PLEASANTVILLE',3,'10101'
UNION SELECT 'PO BOX 3','RTE 3', 'HUDSON',2,'10202'
UNION SELECT 'PO BOX 4', 'RTE 4','STANTON',3,'87654-1011'
UNION SELECT 'PO BOX 5',NULL,'LAS VEGAS',1,'90056'
**/

--Create an errors table to hold ETL errors
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ETLErrorLog]') AND type in (N'U'))
DROP TABLE [dbo].[ETLErrorLog]
GO
CREATE TABLE dbo.[ETLErrorLog](
	[ErrorLogID] [int] IDENTITY(1,1) NOT NULL,
	[ErrorCode] [int] NULL,
	[ErrorText] [nvarchar](4000) NULL,
	[ErrorProcedure] [nvarchar](126) NULL,
	[ErrorSourceID] int NULL,
	[ErrorSourceData] xml NULL,
	[ErrorTime] [datetime] NOT NULL CONSTRAINT [DF_ETLErrorLog_ErrorTime]  DEFAULT (getdate()),
 CONSTRAINT [PK_ETLErrorLog] PRIMARY KEY CLUSTERED 
(	[ErrorLogID] ASC )
) ON [PRIMARY]



/***********END SET UP***************/

/****BEGIN ETL CODE EXAMPLE*********/
--The following code would be compiled within a stored procedure

--Create an ID to update the source data (if required)
DECLARE @BatchID int
SELECT @BatchID = 100

DECLARE @CurrentTime datetime
DECLARE @TotalInserts int
DECLARE @Counter int

--Variables needed if conditional set-based processing reverts to row-by-row processing
DECLARE @RowID int,
		@AddressLine1 nvarchar(60),
		@AddressLine2 nvarchar(60),
		@City nvarchar(30),
		@StateProvinceId int,
		@PostalCode	nvarchar(15)
DECLARE @XMLDoc xml

--Declare temporary table to hold source data
DECLARE @TempSource TABLE
(RowID int PRIMARY KEY,
 AddressLine1 nvarchar(60),
 AddressLine2 nvarchar(60),
 City nvarchar(30),
 StateProvinceID int,
 PostalCode nvarchar(15)
)

INSERT INTO @TempSource
(RowID,AddressLine1,AddressLine2,
 City, StateProvinceID, PostalCode)
SELECT 
SourceRowIdentifier,
SourceAddressLine1, SourceAddressLine2,
 SourceCity, SourceStateProvinceID,
 SourcePostalCode
FROM dbo.SourceAddress
WHERE BatchID IS NULL

--BEGIN CODE SECTION FOR SET-BASED PROCESSING 
SET @TotalInserts = (SELECT COUNT(*) FROM @TempSource)
IF @TotalInserts > 0
BEGIN
			
BEGIN TRY
BEGIN TRAN

INSERT INTO dbo.TargetAddress
	(AddressLine1,
	 AddressLine2,
	 City, 
	 StateProvinceID, 
	 PostalCode)
SELECT 
	AddressLine1,
	AddressLine2,
	City, 
	StateProvinceID, 
	PostalCode
FROM @TempSource

SET @CurrentTime = getdate()

UPDATE dbo.SourceAddress
	SET		LoadTime = @CurrentTime,
			BatchID = @BatchID
	FROM dbo.SourceAddress S JOIN @TempSource T 
	ON	T.RowID = S.SourceRowIdentifier

	IF @@TRANCOUNT > 0			
	COMMIT TRAN

	--Don't delete from temp table until transaction is committed
	DELETE @TempSource 

	PRINT 'Source Records processed in set-based statements'

END TRY
BEGIN CATCH --Outer catch block

		--Rollback all data. This does not delete or remove the table variable and its data.
		IF @@TRANCOUNT > 0
		ROLLBACK

	    --Record a single error in the errors table. 
		--We may not know which record caused the batch to fail, but we record the failure.

			  INSERT INTO	dbo.ETLErrorLog
						(	ErrorCode,
							ErrorText,
							ErrorProcedure,
							ErrorSourceID
						)			  
					SELECT	ERROR_NUMBER(),
							ERROR_MESSAGE(),
							ERROR_PROCEDURE(),
							@BatchID


		--We still have our staged records in the @TempSource table
			SELECT TOP 1
				@RowID				= RowID,
				@AddressLine1		= AddressLine1,
				@AddressLine2		= AddressLine2,
				@City				= City,
				@StateProvinceId	= StateProvinceID,
				@PostalCode			= PostalCode
			FROM   @TempSource

		SET @Counter = 1
		-- LOOP through each record in the batch. We previously got the total count.
		WHILE @Counter <= @TotalInserts
		  BEGIN

			BEGIN TRY
				PRINT 'Processing record '+ CAST(@RowID AS NVARCHAR(4)) +' in one-at-a-time loop...'
			BEGIN TRAN
			
						INSERT INTO dbo.TargetAddress
							(AddressLine1,
							 AddressLine2,
							 City, 
							 StateProvinceID, 
							 PostalCode)
						SELECT 
							@AddressLine1,
							@AddressLine2,
							@City, 
							@StateProvinceID, 
							@PostalCode

				UPDATE dbo.SourceAddress
					SET		LoadTime = @CurrentTime,
							BatchID = @BatchID
					WHERE	SourceRowIdentifier = @RowID

					--Commit each record one-at-a-time, updating the Source table that it has been processed, catching the errors
					IF @@TRANCOUNT > 0
					COMMIT TRAN

				END TRY
				BEGIN CATCH

					--Roll back only the processing of the one record
					IF @@TRANCOUNT > 0
					ROLLBACK

					SELECT @XMLDoc =
						(SELECT RowID,
							AddressLine1,
							 AddressLine2,
							 City, 
							 StateProvinceID, 
							 PostalCode
						FROM @TempSource
						WHERE RowID = @RowID
						FOR XML PATH (''))

					  INSERT INTO	dbo.ETLErrorLog
								(	ErrorCode,
									ErrorText,
									ErrorProcedure,
									ErrorSourceID,
									ErrorSourceData
								)			  
							SELECT	ERROR_NUMBER(),
									ERROR_MESSAGE(),
									ERROR_PROCEDURE(),
									@RowID,
									@XMLDoc


					--You may wish to add code here to limit the number of times a failed record attempts to load in subsequent batches
					--Failed records can be moved to another table, flagged, or deleted, depending on business rules

				END CATCH --Nested catch block

					DELETE @TempSource
					WHERE @RowID = RowID
					
					--Continue getting data for WHILE loop
					SELECT @Counter = @Counter+1	
					SELECT @RowID = NULL, @AddressLine1 = NULL, @AddressLine2 = NULL, @City = NULL, @StateProvinceID = NULL, @PostalCode = NULL

					SELECT TOP 1
						@RowID				= RowID,
						@AddressLine1		= AddressLine1,
						@AddressLine2		= AddressLine2,
						@City				= City,
						@StateProvinceId	= StateProvinceID,
						@PostalCode			= PostalCode
					FROM   @TempSource


			END --While Loop for Row-by-row processing 

END CATCH --Initial catch block

END --If Total_Inserts > 0

SELECT * FROM dbo.ETLErrorLog