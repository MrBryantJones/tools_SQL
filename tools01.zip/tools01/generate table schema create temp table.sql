/***-------------------------------------------------------------------------

    Generate / capture output schema of a stored procedure

-------------------------------------------------------------------------***/


/***    This built-in system stored procedure will tell you the metadata of the 
            first result set of a stored procedure or query.
            
        sp_describe_first_result_set does not execute the procedure 

        If procedure uses a temp table or creates it dynamically, this will not work.
            
***/

    EXEC sp_describe_first_result_set 
        @tsql = N'EXEC [DataScience].[powerBI].[usp_SNF_Financial_details_tst]';

/***    Use sp_describe_first_result_set to dynamically build a CREATE TABLE statement ***/

    DECLARE @sql NVARCHAR(MAX) = '';
    DECLARE @proc NVARCHAR(MAX) = N'EXEC [DataScience].[powerBI].[usp_SNF_Financial_details_tst]';
    
    SELECT @sql = STRING_AGG(
        QUOTENAME(name) + ' ' + system_type_name +
        CASE WHEN is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END,
        ', ' + CHAR(13)
    )
    FROM sys.dm_exec_describe_first_result_set(@proc, NULL, 0);
    
    SET @sql = 'CREATE TABLE #YourTempTable (' + CHAR(13) + @sql + CHAR(13) + ');';
    
    PRINT @sql;
    -- Optional to create the temp table : EXEC(@sql) 

/***    Can try this for linked servers ***/

SELECT *
INTO #TempAutoCreated
FROM OPENQUERY([YourLinkedServer], 'EXEC [DataScience].[powerBI].[usp_SNF_Financial_details_tst]');

/***    Can try this but know that SET FMTONLY ON is deprecated 
            Still will not work if proc uses a temp table
***/

SET FMTONLY ON;
EXEC [DataScience].[powerBI].[usp_SNF_Financial_details_tst];
SET FMTONLY OFF;






/***    Could be an option     ***/

-- Enable if not already enabled (requires admin access)
-- EXEC sp_configure 'show advanced options', 1;
-- RECONFIGURE;
-- EXEC sp_configure 'Ad Hoc Distributed Queries', 1;
-- RECONFIGURE;

	drop table if exists #ProcedureOutput

-- Main step:
SELECT *
INTO #ProcedureOutput
FROM OPENROWSET(
    'SQLNCLI',
    'Server=localhost;Trusted_Connection=yes;',
    'EXEC [DataScience].[powerBI].[usp_SNF_Financial_details_tst]'
);


/***

Option : Use a one-time data collector session (manual but clean)

Run the stored procedure normally in SSMS:

EXEC dbo.YourStoredProcedure;


In the Results pane, right-click > Save Results As > CSV.

Use a tool (like Excel, or a T-SQL script) to infer data types and 
generate a CREATE TABLE statement.

This is a one-time manual step, useful if you're trying 
to reverse-engineer the structure.

***/


/***    Create a Dummy Wrapper to Expose Final Temp Table       ***/

-- Mimic the final SELECT (based on reverse engineering)
SELECT TOP 0 * 
INTO #ProcedureOutput
FROM #FinalResult -- If you can access it in the same session

