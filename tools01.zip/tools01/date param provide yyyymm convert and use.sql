

/***	Provide YYYY-MM		***/

declare @YYYYMM varchar(7) = '2025-08'; 

--SELECT 
--@YYYYMM as [passed_param], 
--cast(@YYYYMM + '-01' as date) as FirstDayOfMonth,
--eomonth(@YYYYMM + '-01') as LastDayOfMonth,
--FORMAT(cast(@YYYYMM + '-01' as date), 'M/d/yyyy') as [FirstDayOfMonth_M/d/yyyy],
--FORMAT(eomonth(@YYYYMM + '-01'), 'M/d/yyyy') as [LastDayOfMonth_M/d/yyyy],
--REPLACE(REPLACE(CONVERT(VARCHAR(10), eomonth(@YYYYMM + '-01'), 101), '/0', '/'), ' 0', ' ') as [LastDayOfMonth_M/d/yyyy],
--FORMAT(GETDATE(), 'M/d/yyyy') AS [FormattedDate_M/d/yyyy_Control],
--REPLACE(REPLACE(CONVERT(VARCHAR(10), GETDATE(), 101), '/0', '/'), ' 0', ' ') AS [FormattedDate_mm/dd/yyyy_Control]

declare @start_date date = FORMAT(cast(@YYYYMM + '-01' as date), 'M/d/yyyy') , 		@end_date	date	= FORMAT(eomonth(@YYYYMM + '-01'), 'M/d/yyyy')
select @start_date, @end_date

--declare @start_date date = '8/1/2025' , 		@end_date	date	= '8/31/2025'
						--'2025-08-01'								'2025-08-31'


go

/***	Set date range	***/

		/***	Specific time frame	
										declare @start_date date = '9/1/2021' , 		@end_date	date	= '9/30/2021'
		***/	

		/***	Handle like proc	***/

				declare @start_date date, @end_date date
				Set @start_date = null		Set @end_date = null

			/* Default values for optional parameters */

				if @start_date is null
					set @start_date = '1/1/2019'								--'2019-01-01'
				if @end_date is null
					set @end_date = cast(dateadd(day, -1, getdate()) as date)	--yesterday like	'2025-09-04'

/***	get the first day of the month from yyyy-mm		SELECT CAST('2025-08' + '-01' AS DATE);		***/
/***	get the last day of the month from yyyy-mm		DECLARE @YYYYMM VARCHAR(7) = '2025-08'; SELECT EOMONTH(@YYYYMM + '-01') AS LastDayOfMonth;		***/
/***	SELECT CAST('2025-08' + '-01' AS DATE) as FirstDayOfMonth, EOMONTH('2025-08' + '-01') AS LastDayOfMonth;	***/
/***
		CAST('2025-08' + '-01' AS DATE) as FirstDayOfMonth, 
		EOMONTH('2025-08' + '-01') AS LastDayOfMonth;
		IIF( CONVERT(DATE, a.discharge_datetime) IS NOT NULL, CAST(FORMAT(a.discharge_datetime, 'yyyy-MM') + '-01' AS DATE), CONVERT(DATE, a.discharge_datetime) ) as discharge_fdom,
		IIF( CONVERT(DATE, a.discharge_datetime) IS NOT NULL, EOMONTH(FORMAT(a.discharge_datetime, 'yyyy-MM') + '-01'), CONVERT(DATE, a.discharge_datetime) ) AS discharge_ldom,
		IIF( boolean_expression, true_value, false_value )
		FORMAT(GETDATE(), 'yyyy-MM') AS YYYYMM
***/