﻿whoami /groups


# Use Select-String to find lines that contain "sec_"
whoami /groups | Select-String -Pattern "sec_"




<# ________________________________________________________________ #>


# 1. Export to a Text File (Simplest) __________________________________________ 
whoami /groups | Out-File C:\Temp\MyGroupMembership.txt


# 2. Output to a GridView (Graphical Table) __________________________________________ 

# 1. Capture the raw text output
$Groups = whoami /groups

# 2. Display the raw text in a GridView
$Groups | Out-GridView -Title "My User Group Membership"

# 3. Export to an HTML File (Web-Viewable Report) __________________________________________ 

# 1. Capture and process the output into objects
$GroupObjects = whoami /groups | Select-Object -Skip 3 | ForEach-Object {
    $parts = $_ -split ' {2,}'
    # Create a custom object for each group line
    [PSCustomObject]@{
        GroupName = $parts[0].Trim()
        Type      = $parts[1].Trim()
        SID       = $parts[2].Trim()
    }
}

# 2. Convert the objects to HTML and save the file
$GroupObjects | ConvertTo-Html -Title "Group Membership Report" -Body "<H2>User: $env:USERNAME</H2>" | Out-File C:\Temp\MyGroupMembership.html


# 4. Export to a CSV File (Excel-Viewable) __________________________________________ 

# 1. Capture and process the output into objects
$GroupObjects = whoami /groups | Select-Object -Skip 3 | ForEach-Object {
    $parts = $_ -split ' {2,}'
    # Create a custom object for each group line
    [PSCustomObject]@{
        GroupName = $parts[0].Trim()
        Type      = $parts[1].Trim()
        SID       = $parts[2].Trim()
    }
}

# 2. Convert the objects to CSV and save the file
$GroupObjects | Export-Csv C:\Temp\MyGroupMembership.csv -NoTypeInformation


# 5 Combined Script for Multiple Modes __________________________________________ 

# Define the Output File path and User
$OutputPath = "C:\Temp"
$UserName = $env:USERNAME

# --- Main Processing Block ---
# Capture and process the output into objects once
$GroupObjects = whoami /groups | Select-Object -Skip 3 | ForEach-Object {
    # Splits the line by two or more spaces (the delimiter in whoami output)
    $parts = $_ -split ' {2,}' 
    # Creates a reusable object with clean properties
    [PSCustomObject]@{
        GroupName = $parts[0].Trim()
        Type      = $parts[1].Trim()
        SID       = $parts[2].Trim()
    }
}
# --- End of Processing Block ---

# 1. Text File Output
$GroupObjects | Out-File "$OutputPath\$UserName`_Groups.txt"
Write-Host "Text file created: $OutputPath\$UserName`_Groups.txt"

# 2. HTML File Output (for web browser viewing)
$GroupObjects | ConvertTo-Html -Title "Group Membership Report for $UserName" -Body "<H2>User: $UserName</H2>" | Out-File "$OutputPath\$UserName`_Groups.html"
Write-Host "HTML file created: $OutputPath\$UserName`_Groups.html"

# 3. CSV File Output (for Excel viewing)
$GroupObjects | Export-Csv "$OutputPath\$UserName`_Groups.csv" -NoTypeInformation
Write-Host "CSV file created: $OutputPath\$UserName`_Groups.csv"

# 4. GridView Output (interactive pop-up table)
$GroupObjects | Out-GridView -Title "Group Membership for $UserName"



<#

        SEARCH GROUP NAMES 

#>

# 1 1. Filtered Script Example __________________________________________ 

# 1. Capture and process the output into objects
# This block is identical to the previous answer, it creates the objects
$GroupObjects = whoami /groups | Select-Object -Skip 3 | ForEach-Object {
    $parts = $_ -split ' {2,}'
    [PSCustomObject]@{
        GroupName = $parts[0].Trim()
        Type      = $parts[1].Trim()
        SID       = $parts[2].Trim()
    }
}

# 2. Filter the resulting objects for the group name pattern
$SecurityGroups = $GroupObjects | Where-Object { $_.GroupName -like "*sec_*" }

# 3. Output the filtered results (e.g., to GridView or a file)
$SecurityGroups | Out-GridView -Title "Groups Matching *sec_*"

# Example: Export the filtered list to CSV
$SecurityGroups | Export-Csv C:\Temp\SecurityGroups.csv -NoTypeInformation


# 2. Alternative: Filtering Raw Text (Less Flexible) __________________________________________ 

# Use Select-String to find lines that contain "sec_"
whoami /groups | Select-String -Pattern "sec_" | Out-File C:\Temp\RawSecurityGroups.txt


 __________________________________________ 
 __________________________________________ 