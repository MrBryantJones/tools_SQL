/*
This isnt bad but 
Ok this is working but it is missing some due to only going against the master database as in "[LINKEDSERVER].master.sys.tables". 
So in the case of "FROM [LINKEDSERVER].[DATABASENAME].[SCHEMANAME].[TABLENAME]", it does not pick those up to search there. 
What needs to be changed? This is the current code that is being used:
*/
-- Declare variables for search
--DECLARE @SearchTableName NVARCHAR(MAX) = 'Discharge';
--DECLARE @SearchColumnName NVARCHAR(MAX) = 'Discharge';

-- test for linked server
--GOOD
--DECLARE @SearchTableName NVARCHAR(MAX) = 'AccountAddressGuarantor'; --LevelOfAssistance  FROM [MEDITECHDR].[BrooksInternal].[MTQuery].[LevelOfAssistance]
--DECLARE @SearchColumnName NVARCHAR(MAX) = 'Account Num'; --SELECT [ID], [IdentifierID], [SortOrder], [DisplayName], [Mnemonic], [QueryText], [IsActive]
DECLARE @SearchTableName NVARCHAR(MAX) = 'LevelOfAssistance'; --LevelOfAssistance  FROM [MEDITECHDR].[BrooksInternal].[MTQuery].[LevelOfAssistance]
DECLARE @SearchColumnName NVARCHAR(MAX) = 'DisplayName'; --SELECT [ID], [IdentifierID], [SortOrder], [DisplayName], [Mnemonic], [QueryText], [IsActive]

-- Declare variables for search
--DECLARE @SearchTableName NVARCHAR(MAX) = 'YourTableName';
--DECLARE @SearchColumnName NVARCHAR(MAX) = 'YourColumnName';

-- Temp table to store results
IF OBJECT_ID('tempdb..#SearchResults') IS NOT NULL DROP TABLE #SearchResults;

CREATE TABLE #SearchResults (
    DatabaseName NVARCHAR(MAX),
    SchemaName NVARCHAR(MAX),
    TableName NVARCHAR(MAX),
    ColumnName NVARCHAR(MAX) NULL,
    IsLinkedServer BIT NULL -- New column to mark if it's from a linked server
);

-- Cursor to loop through databases
DECLARE db_cursor CURSOR FOR
SELECT name 
FROM sys.databases 
WHERE state_desc = 'ONLINE'
  AND name NOT IN ('master','tempdb','model','msdb');  -- Skip system DBs

DECLARE @DBName NVARCHAR(MAX);
DECLARE @SQL NVARCHAR(MAX);

OPEN db_cursor;
FETCH NEXT FROM db_cursor INTO @DBName;

WHILE @@FETCH_STATUS = 0
BEGIN
    -- Build dynamic SQL to query tables/columns for local databases
    SET @SQL = '
    USE ' + QUOTENAME(@DBName) + ';
    BEGIN TRY
        -- Search for matching table names
        INSERT INTO #SearchResults (DatabaseName, SchemaName, TableName, ColumnName, IsLinkedServer)
        SELECT 
            DB_NAME(),
            s.name AS SchemaName,
            t.name AS TableName,
            NULL AS ColumnName,
            0 AS IsLinkedServer -- Local database
        FROM sys.tables t
        INNER JOIN sys.schemas s ON t.schema_id = s.schema_id
        WHERE t.name = @SearchTableName;

        -- Search for matching column names
        INSERT INTO #SearchResults (DatabaseName, SchemaName, TableName, ColumnName, IsLinkedServer)
        SELECT 
            DB_NAME(),
            s.name AS SchemaName,
            t.name AS TableName,
            c.name AS ColumnName,
            0 AS IsLinkedServer -- Local database
        FROM sys.columns c
        INNER JOIN sys.tables t ON c.object_id = t.object_id
        INNER JOIN sys.schemas s ON t.schema_id = s.schema_id
        WHERE c.name = @SearchColumnName;
    END TRY
    BEGIN CATCH
        PRINT ''Error in local database: ' + @DBName + ' - '' + ERROR_MESSAGE();
    END CATCH;
    ';

    -- CHECK
    -- PRINT @SQL 
    -- PRINT N'@SearchTableName NVARCHAR(MAX), @SearchColumnName NVARCHAR(MAX)' 
    -- PRINT @SearchTableName 
    -- PRINT @SearchColumnName

    -- Execute with parameters for local databases
    EXEC sp_executesql 
        @SQL, 
        N'@SearchTableName NVARCHAR(MAX), @SearchColumnName NVARCHAR(MAX)', 
        @SearchTableName = @SearchTableName, 
        @SearchColumnName = @SearchColumnName;

    FETCH NEXT FROM db_cursor INTO @DBName;
END

CLOSE db_cursor;
DEALLOCATE db_cursor;

-- Now loop through linked servers
DECLARE linked_cursor CURSOR FOR
SELECT name 
FROM sys.servers 
WHERE is_linked = 1;  -- Only linked servers

DECLARE @LinkedServer NVARCHAR(MAX);

OPEN linked_cursor;
FETCH NEXT FROM linked_cursor INTO @LinkedServer;

WHILE @@FETCH_STATUS = 0
BEGIN
    -- Build dynamic SQL for linked servers
    SET @SQL = '
    EXEC(''USE master;
    BEGIN TRY
        -- Search for matching table names on linked server
        INSERT INTO #SearchResults (DatabaseName, SchemaName, TableName, ColumnName, IsLinkedServer)
        SELECT 
            ''''' + @LinkedServer + ''''' AS DatabaseName,  -- Correctly escape single quotes
            s.name AS SchemaName,
            t.name AS TableName,
            NULL AS ColumnName,
            1 AS IsLinkedServer -- Linked server
        FROM ' + QUOTENAME(@LinkedServer) + '.master.sys.tables t
        INNER JOIN ' + QUOTENAME(@LinkedServer) + '.master.sys.schemas s ON t.schema_id = s.schema_id
        WHERE t.name = ''''' + @SearchTableName + ''''';

        -- Search for matching column names on linked server
        INSERT INTO #SearchResults (DatabaseName, SchemaName, TableName, ColumnName, IsLinkedServer)
        SELECT 
            ''''' + @LinkedServer + ''''' AS DatabaseName,  -- Correctly escape single quotes
            s.name AS SchemaName,
            t.name AS TableName,
            c.name AS ColumnName,
            1 AS IsLinkedServer -- Linked server
        FROM ' + QUOTENAME(@LinkedServer) + '.master.sys.columns c
        INNER JOIN ' + QUOTENAME(@LinkedServer) + '.master.sys.tables t ON c.object_id = t.object_id
        INNER JOIN ' + QUOTENAME(@LinkedServer) + '.master.sys.schemas s ON t.schema_id = s.schema_id
        WHERE c.name = ''''' + @SearchColumnName + ''''';
    END TRY
    BEGIN CATCH
        PRINT ''''Error on linked server: ' + @LinkedServer + ' - '''' + ERROR_MESSAGE();
    END CATCH;
    '')';

    -- CHECK: Debug output for the generated SQL for linked servers
    -- Print the SQL that is being executed
    PRINT @SQL;
    -- Uncomment the next two lines to see the parameter values too:
    -- PRINT N'@SearchTableName: ' + @SearchTableName;
    -- PRINT N'@SearchColumnName: ' + @SearchColumnName;

    -- Execute dynamic SQL for the linked server
    BEGIN TRY
        EXEC sp_executesql 
            @SQL, 
            N'@SearchTableName NVARCHAR(MAX), @SearchColumnName NVARCHAR(MAX)', 
            @SearchTableName = @SearchTableName, 
            @SearchColumnName = @SearchColumnName;
    END TRY
    BEGIN CATCH
        PRINT 'Error executing on linked server: ' + @LinkedServer + ' - ' + ERROR_MESSAGE();
    END CATCH;

    FETCH NEXT FROM linked_cursor INTO @LinkedServer;
END

CLOSE linked_cursor;
DEALLOCATE linked_cursor;

-- Output all results
SELECT *
    , CONCAT('SELECT TOP 5 [', ColumnName, '], ''##########'', * FROM ', DatabaseName, '.', SchemaName, '.', TableName, ' WHERE 1=1 --AND xxx') AS [research_queries]
FROM #SearchResults 
ORDER BY DatabaseName, SchemaName, TableName;

