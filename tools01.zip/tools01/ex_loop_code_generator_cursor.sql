/*
LOOPS
CODE GENERATOR
CURSORS
*/
------------------------------------------------------------------------------------------------------------------------------------------------------------------
--  [   Try Catch Block - Insert - Update - CONDITIONAL ROW BY ROW PROCESSING - LOOP ( also see file Conditional Set-Based ETL.sql) - CODE GENERATOR	]   --------------------------------


/*	PRE RUN STEP - WRITE TO BATCH TABLE ((Write: [Filename] (LeadSquaredExport_YYYYMMDD), [ProcessStart] (GetDate()), [Status] (Starting)))		*/

DECLARE @StartTime DATETIME = (SELECT GetDate())
DECLARE @YYYYmmddStamp DATE = (SELECT CONVERT(DATE, GETDATE()))
DECLARE @FileName nvarchar(30) = CONCAT('LeadSquaredExport_', REPLACE(@YYYYmmddStamp, '-', ''))
select @StartTime as [StartTime], @YYYYmmddStamp AS [FileDateStamp], @FileName AS [FullFilename]

BEGIN TRY
    BEGIN TRANSACTION;

    -- Your DML statements here
    INSERT INTO [LeadSquared].[PatientDataForExtract_Batches] ([Filename], [ProcessStart], [Status]) VALUES (@FileName, @StartTime, N'Starting');
    --UPDATE AnotherTable SET ColumnA = 'NewValue' WHERE ID = 1;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    -- Log error details to an error logging table
    INSERT INTO ErrorLogTable (
        ErrorNumber,
        ErrorMessage,
        ErrorSeverity,
        ErrorState,
        ErrorProcedure,
        ErrorLine,
        ErrorDateTime
    )
    VALUES (
        ERROR_NUMBER(),
        ERROR_MESSAGE(),
        ERROR_SEVERITY(),
        ERROR_STATE(),
        ERROR_PROCEDURE(),
        ERROR_LINE(),
        GETDATE()
    );

    -- Optionally, re-raise the error or handle it as needed
    -- THROW; 
END CATCH;



---	CONDITIONAL SET BASED PROCESSING REVERTS TO ROW BY ROW PROCESSING	-------

--Create an ID to update the source data (if required)
DECLARE @BatchID int
SELECT @BatchID = 100

DECLARE @CurrentTime datetime
DECLARE @TotalInserts int
DECLARE @Counter int

--Variables needed if conditional set-based processing reverts to row-by-row processing
DECLARE @RowID int,
		@AddressLine1 nvarchar(60),
		@AddressLine2 nvarchar(60),
		@City nvarchar(30),
		@StateProvinceId int,
		@PostalCode	nvarchar(15)
DECLARE @XMLDoc xml

--Declare temporary table to hold source data
DECLARE @TempSource TABLE
(RowID int PRIMARY KEY,
 AddressLine1 nvarchar(60),
 AddressLine2 nvarchar(60),
 City nvarchar(30),
 StateProvinceID int,
 PostalCode nvarchar(15)
)

INSERT INTO @TempSource
(RowID,AddressLine1,AddressLine2,
 City, StateProvinceID, PostalCode)
SELECT 
SourceRowIdentifier,
SourceAddressLine1, SourceAddressLine2,
 SourceCity, SourceStateProvinceID,
 SourcePostalCode
FROM dbo.SourceAddress
WHERE BatchID IS NULL

--BEGIN CODE SECTION FOR SET-BASED PROCESSING 
SET @TotalInserts = (SELECT COUNT(*) FROM @TempSource)
IF @TotalInserts > 0
BEGIN
			
BEGIN TRY
BEGIN TRAN

INSERT INTO dbo.TargetAddress
	(AddressLine1,
	 AddressLine2,
	 City, 
	 StateProvinceID, 
	 PostalCode)
SELECT 
	AddressLine1,
	AddressLine2,
	City, 
	StateProvinceID, 
	PostalCode
FROM @TempSource

SET @CurrentTime = getdate()

UPDATE dbo.SourceAddress
	SET		LoadTime = @CurrentTime,
			BatchID = @BatchID
	FROM dbo.SourceAddress S JOIN @TempSource T 
	ON	T.RowID = S.SourceRowIdentifier

	IF @@TRANCOUNT > 0			
	COMMIT TRAN

	--Don't delete from temp table until transaction is committed
	DELETE @TempSource 

	PRINT 'Source Records processed in set-based statements'

END TRY
BEGIN CATCH --Outer catch block

		--Rollback all data. This does not delete or remove the table variable and its data.
		IF @@TRANCOUNT > 0
		ROLLBACK

	    --Record a single error in the errors table. 
		--We may not know which record caused the batch to fail, but we record the failure.

			  INSERT INTO	dbo.ETLErrorLog
						(	ErrorCode,
							ErrorText,
							ErrorProcedure,
							ErrorSourceID
						)			  
					SELECT	ERROR_NUMBER(),
							ERROR_MESSAGE(),
							ERROR_PROCEDURE(),
							@BatchID


		--We still have our staged records in the @TempSource table
			SELECT TOP 1
				@RowID				= RowID,
				@AddressLine1		= AddressLine1,
				@AddressLine2		= AddressLine2,
				@City				= City,
				@StateProvinceId	= StateProvinceID,
				@PostalCode			= PostalCode
			FROM   @TempSource

		SET @Counter = 1
		-- LOOP through each record in the batch. We previously got the total count.
		WHILE @Counter <= @TotalInserts
		  BEGIN

			BEGIN TRY
				PRINT 'Processing record '+ CAST(@RowID AS NVARCHAR(4)) +' in one-at-a-time loop...'
			BEGIN TRAN
			
						INSERT INTO dbo.TargetAddress
							(AddressLine1,
							 AddressLine2,
							 City, 
							 StateProvinceID, 
							 PostalCode)
						SELECT 
							@AddressLine1,
							@AddressLine2,
							@City, 
							@StateProvinceID, 
							@PostalCode

				UPDATE dbo.SourceAddress
					SET		LoadTime = @CurrentTime,
							BatchID = @BatchID
					WHERE	SourceRowIdentifier = @RowID

					--Commit each record one-at-a-time, updating the Source table that it has been processed, catching the errors
					IF @@TRANCOUNT > 0
					COMMIT TRAN

				END TRY
				BEGIN CATCH

					--Roll back only the processing of the one record
					IF @@TRANCOUNT > 0
					ROLLBACK

					SELECT @XMLDoc =
						(SELECT RowID,
							AddressLine1,
							 AddressLine2,
							 City, 
							 StateProvinceID, 
							 PostalCode
						FROM @TempSource
						WHERE RowID = @RowID
						FOR XML PATH (''))

					  INSERT INTO	dbo.ETLErrorLog
								(	ErrorCode,
									ErrorText,
									ErrorProcedure,
									ErrorSourceID,
									ErrorSourceData
								)			  
							SELECT	ERROR_NUMBER(),
									ERROR_MESSAGE(),
									ERROR_PROCEDURE(),
									@RowID,
									@XMLDoc


					--You may wish to add code here to limit the number of times a failed record attempts to load in subsequent batches
					--Failed records can be moved to another table, flagged, or deleted, depending on business rules

				END CATCH --Nested catch block

					DELETE @TempSource
					WHERE @RowID = RowID
					
					--Continue getting data for WHILE loop
					SELECT @Counter = @Counter+1	
					SELECT @RowID = NULL, @AddressLine1 = NULL, @AddressLine2 = NULL, @City = NULL, @StateProvinceID = NULL, @PostalCode = NULL

					SELECT TOP 1
						@RowID				= RowID,
						@AddressLine1		= AddressLine1,
						@AddressLine2		= AddressLine2,
						@City				= City,
						@StateProvinceId	= StateProvinceID,
						@PostalCode			= PostalCode
					FROM   @TempSource


			END --While Loop for Row-by-row processing 

END CATCH --Initial catch block

END --If Total_Inserts > 0

SELECT * FROM dbo.ETLErrorLog

-- LOOP - CODE GENERATOR --

drop table if exists #dateFormats
DECLARE @counter INT = 0
--DECLARE @date DATETIME = '2006-12-30 00:38:54.840'
DECLARE @date DATETIME = (SELECT GETDATE()) --2025-08-27 11:56:24.230
CREATE TABLE #dateFormats (dateFormatOption int, dateOutput nvarchar(40))
WHILE (@counter <= 150 )
BEGIN
   BEGIN TRY
      INSERT INTO #dateFormats
      SELECT CONVERT(nvarchar, @counter), CONVERT(nvarchar,@date, @counter) 
      SET @counter = @counter + 1
   END TRY
   BEGIN CATCH;
      SET @counter = @counter + 1
      IF @counter >= 150
      BEGIN
         BREAK
      END
   END CATCH
END
--SELECT * FROM #dateFormats
SELECT dateFormatOption, dateOutput, CONCAT('select convert(varchar, getdate(), ', dateFormatOption, ')') AS [Query] FROM #dateFormats


------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------
--  [   CURSOR	]   --------------------------------


DECLARE complex_cursor CURSOR FOR  
    SELECT a.BusinessEntityID  
    FROM HumanResources.EmployeePayHistory AS a  
    WHERE RateChangeDate <>   
         (SELECT MAX(RateChangeDate)  
          FROM HumanResources.EmployeePayHistory AS b  
          WHERE a.BusinessEntityID = b.BusinessEntityID) ;  
OPEN complex_cursor;  
FETCH FROM complex_cursor;  
DELETE FROM HumanResources.EmployeePayHistory  
WHERE CURRENT OF complex_cursor;  
CLOSE complex_cursor;  
DEALLOCATE complex_cursor;  
GO

------------------------------------------------------------------------------------------------------------------------------------------------------------------
