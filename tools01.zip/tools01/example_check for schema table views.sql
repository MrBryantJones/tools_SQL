USE [Marketing]
GO

-------------------------------------------------------------------
-- Schema check
-------------------------------------------------------------------


    SELECT name, * FROM sys.schemas
    SELECT name, * FROM sys.schemas WHERE name IN ( 'bi', 'powerBI' )
    SELECT 1 FROM sys.schemas WHERE name = 'bi'
    SELECT 1 FROM sys.schemas WHERE name = 'powerBI'

    SELECT * FROM INFORMATION_SCHEMA.SCHEMATA
    SELECT * FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = 'powerBI'
    SELECT 1 FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = 'powerBI'
    SELECT 1 FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME LIKE '%powerBI%'

-- if any object (table) like this is there

    IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME LIKE '%powerBI%') --TABLE_NAME = 'TableName')
    BEGIN
        PRINT 'Schema does exist. There is a schema like it.'
    END
    ELSE
    BEGIN
        PRINT 'Schema does not exist. There is not a schame like this.'
    END

-- if object (table) is there

    IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = 'powerBI')
    BEGIN
        PRINT 'Schema does exist.'
    END
    ELSE
    BEGIN
        PRINT 'Schema does not exist.'
    END

-- if any object (table) is not like this is there

    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME LIKE '%powerBI%') --TABLE_NAME = 'TableName')
    BEGIN
        PRINT 'Schema does not exist. There is not a schame like this.'
    END
    ELSE
    BEGIN
        PRINT 'Schema does exist. There is a schema like it.'
    END

-- if object (table) is not there

    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = 'powerBI')
    BEGIN
        PRINT 'Schema does not exist.'
    END
    ELSE
    BEGIN
        PRINT 'Schema does exist.'
    END



-------------------------------------------------------------------
-- Schema & View Object check
-------------------------------------------------------------------
    

-- if objects (schema & view) are not there

    IF OBJECT_ID('bi.v_YextLocations','V') IS NOT NULL
    BEGIN
        PRINT 'Schema & View exists.'
    END
    ELSE
    BEGIN
        PRINT 'Schema or View does not exist.'
    END

    IF OBJECT_ID('powerBI.vw_YextListings','V') IS NOT NULL
    BEGIN
        PRINT 'Schema & View exists.'
    END
    ELSE
    BEGIN
        PRINT 'Schema or View does not exist.'
    END

-- if objects (schema & view) are there

    IF OBJECT_ID('bi.v_YextLocations','V') IS NULL
    BEGIN
        PRINT 'Schema or View does not exist.'
    END
    ELSE
    BEGIN
        PRINT 'Schema & View exists.'
    END

    IF OBJECT_ID('powerBI.vw_YextListings','V') IS NULL
    BEGIN
        PRINT 'Schema or View does not exist.'
    END
    ELSE
    BEGIN
        PRINT 'Schema & View exists.'
    END



-------------------------------------------------------------------
-- Schema & Table Object check
-------------------------------------------------------------------

-- if objects (schema & table) are not there

    IF OBJECT_ID('dbo.YextListings','U') IS NOT NULL
    BEGIN
        PRINT 'Schema or Table exists.'
    END
    ELSE
    BEGIN
        PRINT 'Schema or Table does not exist.'
    END

-- if objects (schema & table) are there

    IF OBJECT_ID('dbo.YextListings','U') IS NULL
    BEGIN
        PRINT 'Schema or Table does not exist.'
    END
    ELSE
    BEGIN
        PRINT 'Schema or Table exists.'
    END



-------------------------------------------------------------------
-- View check
-------------------------------------------------------------------


    -- Views
    SELECT TABLE_SCHEMA, * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'VIEW'
    SELECT TABLE_SCHEMA, * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'VIEW' AND TABLE_SCHEMA = 'powerBI'
    SELECT TABLE_SCHEMA, * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'VIEW' AND TABLE_SCHEMA = 'powerBI' AND TABLE_NAME LIKE '%Yext%'
    SELECT TABLE_SCHEMA, * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'VIEW' AND TABLE_SCHEMA = 'powerBI' AND TABLE_NAME = 'vw_YextListings'
    SELECT TABLE_SCHEMA, * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'VIEW' AND TABLE_NAME LIKE '%Yext%'
    SELECT TABLE_SCHEMA, * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'VIEW' AND TABLE_NAME = 'vw_YextListings'
    SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'VIEW' AND TABLE_NAME LIKE '%Yext%'
    SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'VIEW' AND TABLE_NAME = 'vw_YextListings'


-- if any object (view) like this is there

    IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'VIEW' AND TABLE_NAME LIKE '%Yext%') 
    BEGIN
        PRINT 'Views do exists. There are Views like it.'
    END
    ELSE
    BEGIN
        PRINT 'Views do not exist. There are not any Views like this.'
    END

-- if object (view) is there

    IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'VIEW' AND TABLE_NAME = 'vw_YextListings')
    BEGIN
        PRINT 'View does exist.'
    END
    ELSE
    BEGIN
        PRINT 'View does not exist.'
    END

-- if any object (view) is not like this is there

    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'VIEW' AND TABLE_NAME LIKE '%Yext%') 
    BEGIN
        PRINT 'Views do not exist. There are not any Views like this.'
    END
    ELSE
    BEGIN
        PRINT 'Views do exists. There are Views like it.'
    END

-- if object (view) is not there

    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'VIEW' AND TABLE_NAME = 'vw_YextListings')
    BEGIN
        PRINT 'View does not exist.'
    END
    ELSE
    BEGIN
        PRINT 'View does exist.'
    END




-------------------------------------------------------------------
-- Table check
-------------------------------------------------------------------

    -- Tables
    SELECT TABLE_NAME, * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'
    SELECT TABLE_NAME, * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_NAME LIKE '%Yext%'
    SELECT TABLE_NAME, * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'staging' AND TABLE_NAME LIKE '%Yext%'
    SELECT TABLE_NAME, * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME LIKE '%Yext%'
    SELECT TABLE_NAME, * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'YextListings'
    SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME LIKE '%Yext%'

-- if any object (table) like this is there

    IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME LIKE '%Yext%') --TABLE_NAME = 'TableName')
    BEGIN
        PRINT 'Tables do exists. There are tables like it.'
    END
    ELSE
    BEGIN
        PRINT 'Tables does not exist. There are not any Tables like this.'
    END

-- if object (table) is there

    IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'YextEntityLocations')
    BEGIN
        PRINT 'Table does exist.'
    END
    ELSE
    BEGIN
        PRINT 'Table does not exist.'
    END

-- if any object (table) is not like this is there

    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME LIKE '%Yext%') --TABLE_NAME = 'TableName')
    BEGIN
        PRINT 'Tables does not exist. There are not any Tables like this.'
    END
    ELSE
    BEGIN
        PRINT 'Tables do exists. There are tables like it.'
    END

-- if object (table) is not there

    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'YextEntityLocations')
    BEGIN
        PRINT 'Table does not exist.'
    END
    ELSE
    BEGIN
        PRINT 'Table does exist.'
    END


------------------------------------------------------------
-- 0) Create schema for BI
------------------------------------------------------------
--IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'bi')
--EXEC('CREATE SCHEMA bi');
--GO

------------------------------------------------------------
-- 1) Base �fact-like� views
--    Thin, readable, directly consumable in Power BI
------------------------------------------------------------

-- Locations (Entities) � curated
--IF OBJECT_ID('bi.v_YextLocations','V') IS NOT NULL
--    DROP VIEW bi.v_YextLocations;
--GO
--CREATE VIE