/*
---------------------------------------------------
| Dataset			| StagingCount	| TargetCount |
---------------------------------------------------
| EntityLocations	| 77			| 77		  |
| Reviews			| 2891			| 2891		  |
| Listings			| 4320			| 4320		  |
---------------------------------------------------
*/

SELECT	'EntityLocations'										AS Dataset, 
		(SELECT COUNT(*) FROM staging.YextEntityLocationsRaw)	AS StagingCount,
        (SELECT COUNT(*) FROM dbo.YextEntityLocations)			AS TargetCount
UNION ALL
SELECT	'Reviews'										AS Dataset, 
		(SELECT COUNT(*) FROM staging.YextReviewsRaw)   AS StagingCount,
		(SELECT COUNT(*) FROM dbo.YextReviews)          AS TargetCount
UNION ALL
SELECT	'Listings'										AS Dataset, 
		(SELECT COUNT(*) FROM staging.YextListingsRaw)  AS StagingCount,
		(SELECT COUNT(*) FROM dbo.YextListings)         AS TargetCount

/*
---------------------------------------------------
| Dataset			| StagingCount	| TargetCount |
---------------------------------------------------
| EntityLocations	| 77			| 77		  |
---------------------------------------------------
-------------------------------------------
| Dataset	| StagingCount	| TargetCount |
-------------------------------------------
| Reviews	| 2891			| 2891		  |
-------------------------------------------
-------------------------------------------
| Dataset	| StagingCount	| TargetCount |
-------------------------------------------
| Listings	| 4320			| 4320		  |
-------------------------------------------
*/

SELECT	'EntityLocations'										AS Dataset, 
		(SELECT COUNT(*) FROM staging.YextEntityLocationsRaw)	AS StagingCount,
        (SELECT COUNT(*) FROM dbo.YextEntityLocations)			AS TargetCount;

SELECT	'Reviews'										AS Dataset, 
		(SELECT COUNT(*) FROM staging.YextReviewsRaw)   AS StagingCount,
		(SELECT COUNT(*) FROM dbo.YextReviews)          AS TargetCount;

SELECT	'Listings'										AS Dataset, 
		(SELECT COUNT(*) FROM staging.YextListingsRaw)  AS StagingCount,
		(SELECT COUNT(*) FROM dbo.YextListings)         AS TargetCount;
