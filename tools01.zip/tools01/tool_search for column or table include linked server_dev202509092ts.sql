-- Declare variables for search
DECLARE @SearchTableName NVARCHAR(MAX) = 'Discharge';
DECLARE @SearchColumnName NVARCHAR(MAX) = 'Discharge';
DECLARE @LinkedServer NVARCHAR(MAX);
--SET @LinkedServer = 'TEST'
--PRINT 'Error executing on linked server: ' + @LinkedServer + ' - ' -- + ERROR_MESSAGE();

-- Temp table to store results
IF OBJECT_ID('tempdb..#SearchResults') IS NOT NULL DROP TABLE #SearchResults;

CREATE TABLE #SearchResults (
    DatabaseName NVARCHAR(MAX),
    SchemaName NVARCHAR(MAX),
    TableName NVARCHAR(MAX),
    ColumnName NVARCHAR(MAX) NULL,
    IsLinkedServer BIT NULL -- New column to mark if it's from a linked server
);

DECLARE @DBName NVARCHAR(MAX);
DECLARE @SQL NVARCHAR(MAX);

   --V1
   --EXEC('USE master;
   -- BEGIN TRY
   --     -- Search for matching table names on linked server
   --     INSERT INTO #SearchResults (DatabaseName, SchemaName, TableName, ColumnName, IsLinkedServer)
   --     SELECT 
   --         ''MEDITECHDR'' AS DatabaseName,  -- Correctly escape single quotes
   --         s.name AS SchemaName,
   --         t.name AS TableName,
   --         NULL AS ColumnName,
   --         1 AS IsLinkedServer -- Linked server
   --     FROM [MEDITECHDR].sys.tables t
   --     INNER JOIN [MEDITECHDR].sys.schemas s ON t.schema_id = s.schema_id
   --     WHERE t.name = ' + @SearchTableName + ';

   --     -- Search for matching column names on linked server
   --     INSERT INTO #SearchResults (DatabaseName, SchemaName, TableName, ColumnName, IsLinkedServer)
   --     SELECT 
   --         ''MEDITECHDR'' AS DatabaseName,  -- Correctly escape single quotes
   --         s.name AS SchemaName,
   --         t.name AS TableName,
   --         c.name AS ColumnName,
   --         1 AS IsLinkedServer -- Linked server
   --     FROM [MEDITECHDR].sys.columns c
   --     INNER JOIN [MEDITECHDR].sys.tables t ON c.object_id = t.object_id
   --     INNER JOIN [MEDITECHDR].sys.schemas s ON t.schema_id = s.schema_id
   --     WHERE c.name = ' + @SearchTableName + ';
   -- END TRY
   -- BEGIN CATCH
   --     PRINT ''Error on linked server: MEDITECHDR - '' + ERROR_MESSAGE();
   -- END CATCH;
   -- ')

   --V2
 EXEC('USE master;
    BEGIN TRY
        -- Search for matching table names on linked server
        INSERT INTO #SearchResults (DatabaseName, SchemaName, TableName, ColumnName, IsLinkedServer)
        SELECT 
            ''MEDITECHDR'' AS DatabaseName,  -- Correctly escape single quotes
            s.name AS SchemaName,
            t.name AS TableName,
            NULL AS ColumnName,
            1 AS IsLinkedServer -- Linked server
        FROM [MEDITECHDR].master.sys.tables t
        INNER JOIN [MEDITECHDR].master.sys.schemas s ON t.schema_id = s.schema_id
        WHERE t.name = ''Discharge'';

        -- Search for matching column names on linked server
        INSERT INTO #SearchResults (DatabaseName, SchemaName, TableName, ColumnName, IsLinkedServer)
        SELECT 
            ''MEDITECHDR'' AS DatabaseName,  -- Correctly escape single quotes
            s.name AS SchemaName,
            t.name AS TableName,
            c.name AS ColumnName,
            1 AS IsLinkedServer -- Linked server
        FROM [MEDITECHDR].master.sys.columns c
        INNER JOIN [MEDITECHDR].master.sys.tables t ON c.object_id = t.object_id
        INNER JOIN [MEDITECHDR].master.sys.schemas s ON t.schema_id = s.schema_id
        WHERE c.name = ''Discharge'';
    END TRY
    BEGIN CATCH
        PRINT ''Error on linked server: MEDITECHDR - '' + ERROR_MESSAGE();
    END CATCH;
    ')

    -- CHECK
     PRINT @SQL 
     PRINT N'@SearchTableName NVARCHAR(MAX), @SearchColumnName NVARCHAR(MAX)' 
     PRINT @SearchTableName 
     PRINT @SearchColumnName

    -- Execute dynamic SQL for the linked server
    EXEC sp_executesql 
        @SQL, 
        N'@SearchTableName NVARCHAR(MAX), @SearchColumnName NVARCHAR(MAX)', 
        @SearchTableName = @SearchTableName, 
        @SearchColumnName = @SearchColumnName;

select * from #SearchResults

/*
--
select top 5 * from [MEDITECHDR].[BrooksInternal].[dbo].[AccountAddressGuarantor]

select top 5 * from [MEDITECHDR].master.sys.tables 
select top 5 * from [MEDITECHDR].master.sys.schemas 

--1
        SELECT 
            'MEDITECHDR' AS DatabaseName,  -- Correctly escape single quotes
            s.name AS SchemaName,
            t.name AS TableName,
            NULL AS ColumnName,
            1 AS IsLinkedServer -- Linked server
        FROM [MEDITECHDR].master.sys.tables t
        INNER JOIN [MEDITECHDR].master.sys.schemas s ON t.schema_id = s.schema_id
        WHERE t.name = 'Discharge';

--2

        SELECT 
            'MEDITECHDR' AS DatabaseName,  -- Correctly escape single quotes
            s.name AS SchemaName,
            t.name AS TableName,
            c.name AS ColumnName,
            1 AS IsLinkedServer -- Linked server
        FROM [MEDITECHDR].master.sys.columns c
        INNER JOIN [MEDITECHDR].master.sys.tables t ON c.object_id = t.object_id
        INNER JOIN [MEDITECHDR].master.sys.schemas s ON t.schema_id = s.schema_id
        WHERE c.name = 'Discharge';



--Legit
--Error executing on linked server: NETSMART - The OLE DB provider "MSDASQL" for linked server "NETSMART" does not contain the table ""master"."sys"."tables"". 
--The table either does not exist or the current user does not have permissions on that table.

--Legit
--OLE DB provider "MSOLEDBSQL" for linked server "CXPVWSQL21" returned message "Login timeout expired".
--OLE DB provider "MSOLEDBSQL" for linked server "CXPVWSQL21" returned message "A network-related or instance-specific error has occurred while establishing a connection to SQL Server. 
--Server is not found or not accessible. Check if instance name is correct and if SQL Server is configured to allow remote connections. For more information see SQL Server Books Online.".
--Error executing on linked server: CXPVWSQL21 - Named Pipes Provider: Could not open a connection to SQL Server [53]. 

--Legit
--Error executing on linked server: BROOKSAD - Invalid use of schema or catalog for OLE DB provider "ADsDSOObject" for linked server "BROOKSAD". 
--A four-part name was supplied, but the provider does not expose the necessary interfaces to use a catalog or schema.

--Legit
--OLE DB provider "MSOLEDBSQL" for linked server "ADPVWSQL24" returned message "Login timeout expired".
--OLE DB provider "MSOLEDBSQL" for linked server "ADPVWSQL24" returned message "A network-related or instance-specific error has occurred while establishing a connection to SQL Server. 
--Server is not found or not accessible. Check if instance name is correct and if SQL Server is configured to allow remote connections. For more information see SQL Server Books Online.".
--Error executing on linked server: ADPVWSQL24 - Named Pipes Provider: Could not open a connection to SQL Server [53]. 


--1
        SELECT 
            'MEDITECHDR' AS DatabaseName,  -- Correctly escape single quotes
            s.name AS SchemaName,
            t.name AS TableName,
            NULL AS ColumnName,
            1 AS IsLinkedServer -- Linked server
        FROM ADPVWSQL24.master.sys.tables t
        INNER JOIN ADPVWSQL24.master.sys.schemas s ON t.schema_id = s.schema_id
        WHERE t.name = 'Discharge';

--2

        SELECT 
            'MEDITECHDR' AS DatabaseName,  -- Correctly escape single quotes
            s.name AS SchemaName,
            t.name AS TableName,
            c.name AS ColumnName,
            1 AS IsLinkedServer -- Linked server
        FROM ADPVWSQL24.master.sys.columns c
        INNER JOIN ADPVWSQL24.master.sys.tables t ON c.object_id = t.object_id
        INNER JOIN ADPVWSQL24.master.sys.schemas s ON t.schema_id = s.schema_id
        WHERE c.name = 'Discharge';

*/

SELECT TOP 5 [Account Num], '##########', * FROM DataScience.dbo.TEMP_MTDISCHARGEDISPO WHERE 1=1 --AND xxx
