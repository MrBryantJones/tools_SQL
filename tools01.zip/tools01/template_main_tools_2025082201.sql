/*

1 DROP CREATE table (batch) with pk
2 Create table (batch) with pk
3 DROP CREATE table (history) with pk and fk to child table (batch)
4 Changes to tables - CREATE TABLES - ErrorLog - CHANGES TO TABLES - PRIMARY KEY - FOREIGN KEY - UPDATE - TRUNCATE - BACKUP - DEAL WITH FK - UNION SELECT
5 Try Catch Block - Insert - Update - CONDITIONAL ROW BY ROW PROCESSING - LOOP ( also see file Conditional Set-Based ETL.sql)
6 TEMP TABLES - OPENQUERY - CTE - VARIABLE TABLE
x

*/
------------------------------------------------------------------------------------------------------------------------------------------------------------------
	--  [   1 DROP CREATE table (batch) with pk    ]   --------------------------------
	
USE [DataScience]
GO

/*

# Create Batch table has: [ID], [Filename], [ProcessStart], [ProcessEnd], [RecordCount], [Status] (Starting, Started, Loaded, NotLoaded, Failed, Incomplete, Rolledback, Successful, Completed)
# fk on child table : CONSTRAINT FK_ChildTable_ParentID FOREIGN KEY (BatchID) REFERENCES ParentTable (BatchID)

*/

/****** Object:  Table [LeadSquared].[PatientDataForExtract_Batches]    Script Date: 8/14/2025 2:30:35 PM ******/


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[LeadSquared].[PatientDataForExtract_Batches]') AND type in (N'U'))
DROP TABLE [LeadSquared].[PatientDataForExtract_Batches]
GO

/****** Object:  Table [LeadSquared].[PatientDataForExtract_Batches]    Script Date: 8/18/2025 3:32:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [LeadSquared].[PatientDataForExtract_Batches](
	--[ID]							[BIGINT] IDENTITY(1,1) NOT NULL ,
	[BatchID]						[INT] IDENTITY(1,1) NOT NULL , --<NEW> [BIGINT] [INT]  <fk>?
	[Filename]						[NVARCHAR](30) NOT NULL , --(LeadSquaredExport_YYYYMMDD)
	[ProcessStart]					[DATETIME] DEFAULT GETDATE() , 
	[ProcessEnd]					[DATETIME] , 
	[RecordCount]					[INT] NOT NULL DEFAULT 0 , 
	[Status]						[NVARCHAR](1000) NULL , --(Starting, Started, Loaded, NotLoaded, Failed, Incomplete, Rolledback, Successful, Completed)
PRIMARY KEY CLUSTERED 
(
	[BatchID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

	--  [   2 Create table (batch) with pk    ]   -------------------------------------

USE [DataScience]
GO

ALTER TABLE [LeadSquared].[PatientDataForExtract_Batches] DROP CONSTRAINT [DF__PatientDa__Recor__70FE8AC0]
GO

ALTER TABLE [LeadSquared].[PatientDataForExtract_Batches] DROP CONSTRAINT [DF__PatientDa__Proce__700A6687]
GO

/****** Object:  Table [LeadSquared].[PatientDataForExtract_Batches]    Script Date: 8/21/2025 5:14:29 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[LeadSquared].[PatientDataForExtract_Batches]') AND type in (N'U'))
DROP TABLE [LeadSquared].[PatientDataForExtract_Batches]
GO

/****** Object:  Table [LeadSquared].[PatientDataForExtract_Batches]    Script Date: 8/21/2025 5:14:29 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [LeadSquared].[PatientDataForExtract_Batches](
	[BatchID] [int] IDENTITY(1,1) NOT NULL,
	[Filename] [nvarchar](30) NOT NULL,
	[ProcessStart] [datetime] NULL,
	[ProcessEnd] [datetime] NULL,
	[RecordCount] [int] NOT NULL,
	[Status] [nvarchar](1000) NULL,
PRIMARY KEY CLUSTERED 
(
	[BatchID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [LeadSquared].[PatientDataForExtract_Batches] ADD  DEFAULT (getdate()) FOR [ProcessStart]
GO

ALTER TABLE [LeadSquared].[PatientDataForExtract_Batches] ADD  DEFAULT ((0)) FOR [RecordCount]
GO




------------------------------------------------------------------------------------------------------------------------------------------------------------------
--  [   3 DROP CREATE table (history) with pk and fk to child table (batch)    ]   --------------------------------


/*		SELECT * FROM [DataScience].[LeadSquared].[PatientDataForExtract_History]	*/

USE [DataScience]
GO

/****** Object:  Table [LeadSquared].[PatientDataForExtract_History]    Script Date: 8/14/2025 2:30:35 PM ******/


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[LeadSquared].[PatientDataForExtract_History]') AND type in (N'U'))
DROP TABLE [LeadSquared].[PatientDataForExtract_History]
GO

/****** Object:  Table [LeadSquared].[PatientDataForExtract_History]    Script Date: 8/18/2025 3:32:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [LeadSquared].[PatientDataForExtract_History](
	[ID]							[BIGINT] IDENTITY(1,1) NOT NULL ,
	[BatchID]						[INT] NOT NULL , --<NEW> [BIGINT] [INT]  <fk>? CONSTRAINT FK_BatchID FOREIGN KEY (BatchID) REFERENCES [LeadSquared].[PatientDataForExtract_Batches] (BatchID)
	[PatientFirstName]				[VARCHAR](200) NULL ,
	[PatientLastName]				[VARCHAR](200) NULL ,
	[PatientDateOfBirth]			[VARCHAR](100) NULL ,
	[PatientAddressStreet]			[NVARCHAR](100) NULL ,
	[PatientAddressCity]			[NVARCHAR](50) NULL , 
	[PatientAddressState]			[NVARCHAR](50) NULL , 
	[PatientAddressZip]				[NVARCHAR](50) NULL ,	  
	[PatientEmail]					[VARCHAR](255) NULL ,		  
	[PatientPhone]					[NVARCHAR](50) NULL ,	
	[Division]						[VARCHAR](25) NULL ,
	[ReferringFacility]				[VARCHAR](200) NULL , 
	[AdmissionFacility]				[VARCHAR](200) NULL , 
	[AdmissionDate]					[DATETIME] NULL ,
	[DischargeDate]					[DATETIME] NULL ,
	[DischargeFacility]				[VARCHAR](200) NULL , 
	[EmergencyContactFirstName]		[VARCHAR](150) NULL ,
	[EmergencyContactlastName]		[VARCHAR](150) NULL ,
	[EmergencyContactRelationship]	[VARCHAR](2) NULL ,
	[EmergencyContactEmail]			[VARCHAR](200) NULL ,
	[EmergencyContactPhone]			[VARCHAR](30) NULL ,
	[RankSequence]					[INT] NULL , --<new> need to add into load
	[EmergencyContactDescription]	[VARCHAR](100) NULL , --<new>
	[RIC]							[NVARCHAR](250) NULL , 
	[RIC_DESC]						[NVARCHAR](250) NULL ,  --<new>
	[ServiceProgram]				[NVARCHAR](250) NULL ,
	[ImpairmentCode]				[VARCHAR](10) NULL ,
	[PatientEMPI]					[INT] NOT NULL ,
	[DoctorAttending]				[VARCHAR](150) NULL ,
	[PhysicianNPI]					[VARCHAR](25) NULL ,
	[ReferringPhysicianNPI]			[NVARCHAR](10) NULL ,
	[FinancialClass]				[VARCHAR](50) NULL , 
	[NewRecord]						[BIT] NULL DEFAULT 0 , --<new>
	[Sent]							[BIT] NULL DEFAULT 0 , --<new>
	[LoadDate]						[DATETIME] DEFAULT GETDATE(),

    CONSTRAINT PK_PatientDataForExtract_History PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_PatientDataForExtract_History_Batches FOREIGN KEY (BatchID) REFERENCES [DataScience].[LeadSquared].[PatientDataForExtract_Batches](BatchID)
)
GO


    --CONSTRAINT PK_PatientDataForExtract_History PRIMARY KEY CLUSTERED (ID),
    --CONSTRAINT FK_PatientDataForExtract_History_Batches FOREIGN KEY (BatchID) REFERENCES LeadSquared.PatientDataForExtract_Batches(BatchID)
	--ON DELETE CASCADE
	--ON UPDATE CASCADE
	--ON DELETE SET NULL
	--ON UPDATE SET DEFAULT
	--ON DELETE NO ACTION
	--ON UPDATE NO ACTION


/*
--ID INT IDENTITY(1, 1) PRIMARY KEY,  
--IDENTITY (seed , increment) --[Seed]: This is the starting value for the identity column. The first row inserted into the table will receive this value. [Increment]: This is the value that is added to the previous identity value to generate the next value for subsequent rows.
--IDENTITY(1, 1) specifies that the ID column will start with the value 1 (seed) and increment by 1 (increment) for each new record. If no seed and increment values are provided, both default to 1. For example, IDENTITY is equivalent to IDENTITY(1, 1).
--ID BIGINT IDENTITY(seed, increment) NOT NULL PRIMARY KEY
--ID BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY
    --CONSTRAINT PK_PatientDataForExtract_History PRIMARY KEY CLUSTERED (ID),
    --CONSTRAINT FK_PatientDataForExtract_History_Batches FOREIGN KEY (BatchID) REFERENCES [DataScience].[LeadSquared].[PatientDataForExtract_Batches](BatchID)
    --CONSTRAINT PK_PatientDataForExtract_History PRIMARY KEY CLUSTERED (ID),
    --CONSTRAINT FK_PatientDataForExtract_History_Batches FOREIGN KEY (BatchID) REFERENCES LeadSquared.PatientDataForExtract_Batches(BatchID)
	--ON DELETE CASCADE
	--ON UPDATE CASCADE
	--ON DELETE SET NULL
	--ON UPDATE SET DEFAULT
	--ON DELETE NO ACTION
	--ON UPDATE NO ACTION
*/






------------------------------------------------------------------------------------------------------------------------------------------------------------------
--  [   4 Changes to tables - CREATE TABLES - ErrorLog - CHANGES TO TABLES - PRIMARY KEY - FOREIGN KEY - UPDATE - TRUNCATE - BACKUP - DEAL WITH FK - UNION SELECT    ]   ------------------------------


--/*----------------------------------------------------------------------------------

--- IF TABLE EXISTS DROP IT THEN CREATE IT	------------

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupStateProvince]') AND type in (N'U'))
DROP TABLE [dbo].[LookupStateProvince]
GO
CREATE TABLE dbo.[LookupStateProvince]
(
StateProvinceID int IDENTITY(1,1) NOT NULL,
StateProvinceCode nchar(3) NOT NULL,
 CONSTRAINT [PK_LookupStateProvince_StateProvinceID] PRIMARY KEY CLUSTERED 
(	[StateProvinceID] ASC )
) ON [PRIMARY]

--- COLUMNS WITH DEFAULT VALUES IN TABLE	------------

CREATE TABLE YourTableName (
    ID INT PRIMARY KEY IDENTITY(1,1),
    YourDataColumn VARCHAR(255),
	[Sent]							[BIT] NULL DEFAULT 0 ,
    DateCreated DATETIME DEFAULT GETDATE()
);

--- ERROR LOG	------------

--Create an errors table to hold ETL errors
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ETLErrorLog]') AND type in (N'U'))
DROP TABLE [dbo].[ETLErrorLog]
GO
CREATE TABLE dbo.[ETLErrorLog](
	[ErrorLogID] [int] IDENTITY(1,1) NOT NULL,
	[ErrorCode] [int] NULL,
	[ErrorText] [nvarchar](4000) NULL,
	[ErrorProcedure] [nvarchar](126) NULL,
	[ErrorSourceID] int NULL,
	[ErrorSourceData] xml NULL,
	[ErrorTime] [datetime] NOT NULL CONSTRAINT [DF_ETLErrorLog_ErrorTime]  DEFAULT (getdate()),
 CONSTRAINT [PK_ETLErrorLog] PRIMARY KEY CLUSTERED 
(	[ErrorLogID] ASC )
) ON [PRIMARY]

--- MAKE CHANGES TO COLUMNS IN TABLE	------------

ALTER TABLE [DataScience].[LeadSquared].[PatientDataForExtract_History]
ADD [NewRecordFlag] [BIT] NULL;

ALTER TABLE [DataScience].[LeadSquared].[PatientDataForExtract_History]
DROP COLUMN IF EXISTS NewRecordFlag;

ALTER TABLE [DataScience].[LeadSquared].[PatientDataForExtract_History]
ADD [NewRecordFlag] [BIT] NULL DEFAULT 0;

ALTER TABLE YourTableName
ADD DateCreated DATETIME DEFAULT GETDATE();

ALTER TABLE YourTableName
ADD DateCreated DATETIME NOT NULL DEFAULT GETDATE();

ALTER TABLE table_name
DROP COLUMN column_name;

ALTER TABLE table_name
DROP COLUMN column_name1, column_name2, column_name3;

    ALTER TABLE table_name
    DROP COLUMN IF EXISTS column_name;

--- PRIMARY KEY IN TABLE	------------

    ID INT PRIMARY KEY IDENTITY(1,1)
	CONSTRAINT PK_PatientDataForExtract_History PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_PatientDataForExtract_History_Batches FOREIGN KEY (BatchID) REFERENCES [DataScience].[LeadSquared].[PatientDataForExtract_Batches](BatchID)
    CONSTRAINT PK_PatientDataForExtract_History PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_PatientDataForExtract_History_Batches FOREIGN KEY (BatchID) REFERENCES LeadSquared.PatientDataForExtract_Batches(BatchID)
	ON DELETE CASCADE
	ON UPDATE CASCADE
	ON DELETE SET NULL
	ON UPDATE SET DEFAULT
	ON DELETE NO ACTION
	ON UPDATE NO ACTION

--- FOREIGN KEY IN TABLE	------------

Foreign Key :

CREATE TABLE ParentTable (
    ParentID INT PRIMARY KEY,
    ParentName VARCHAR(50)
);

CREATE TABLE ChildTable (
    ChildID INT PRIMARY KEY,
    ChildName VARCHAR(50),
    ParentID INT,
    CONSTRAINT FK_ChildTable_ParentID FOREIGN KEY (ParentID) REFERENCES ParentTable (ParentID)
);

- ParentTable is created with ParentID as its primary key.
- ChildTable is created with a ParentID column.
- CONSTRAINT FK_ChildTable_ParentID FOREIGN KEY (ParentID) REFERENCES ParentTable (ParentID) defines the foreign key:
    - FK_ChildTable_ParentID is the name of the foreign key constraint.
    - FOREIGN KEY (ParentID) specifies that ParentID in ChildTable is the foreign key.
    - REFERENCES ParentTable (ParentID) indicates that this foreign key references the ParentID column in ParentTable.

Add Foreign Key : 

ALTER TABLE ChildTable
ADD CONSTRAINT FK_ChildTable_ParentID FOREIGN KEY (ParentID) REFERENCES ParentTable (ParentID);

Add foreign key constraint to the ChildTable on the ParentID column, referencing the ParentID in ParentTable.

Key Considerations:

Referenced Table and Column:
The table and column referenced by the foreign key must already exist and the referenced column must be a primary key or a unique key in the referenced table.

Data Types:
The data types of the foreign key column(s) in the referencing table and the referenced column(s) in the referenced table must match.

ON DELETE/ON UPDATE Actions:
You can specify actions to take when a referenced row in the parent table is deleted or updated 
(e.g., ON DELETE CASCADE, ON UPDATE CASCADE, ON DELETE SET NULL, ON UPDATE SET DEFAULT, ON DELETE NO ACTION, ON UPDATE NO ACTION).

--- UPDATE TABLE	------------

SELECT * FROM [LeadSquared].[PatientDataForExtract_History] WHERE NewRecordFlag IS NULL

UPDATE [DataScience].[LeadSquared].[PatientDataForExtract_History]
WHERE NewRecordFlag IS NULL;

SELECT * FROM [LeadSquared].[PatientDataForExtract_History] WHERE NewRecordFlag IS NULL

--- DELETE FROM TABLE	------------

SELECT * FROM [LeadSquared].[PatientDataForExtract_History] WHERE NewRecordFlag IS NULL

DELETE [DataScience].[LeadSquared].[PatientDataForExtract_History]
SET NewRecordFlag = 1
WHERE NewRecordFlag IS NULL;

SELECT * FROM [LeadSquared].[PatientDataForExtract_History] WHERE NewRecordFlag IS NULL

--- TRUNCATE TABLE	------------

		SELECT * FROM [DataScience].[LeadSquared].[PatientDataForExtract_History]
		
		TRUNCATE TABLE [DataScience].[LeadSquared].[PatientDataForExtract_History]

		SELECT * FROM [DataScience].[LeadSquared].[PatientDataForExtract_History]

--- BACK UP TABLE	------------

SELECT * INTO [DataScience].[LeadSquared].[PatientDataForExtract_Work] FROM [DataScience].[LeadSquared].[PatientDataForExtract_History]

SELECT * FROM [DataScience].[LeadSquared].[PatientDataForExtract_Work]

---

--- DEAL WITH FOREIGN KEY IN TABLE	------------

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TargetAddress_LookupStateProvince_StateProvinceID]') AND parent_object_id = OBJECT_ID(N'[dbo].[TargetAddress]'))
ALTER TABLE [dbo].[TargetAddress] DROP CONSTRAINT [FK_TargetAddress_LookupStateProvince_StateProvinceID]
GO

--- UNION SELECT	------------

SELECT 'PO BOX 1','RTE 1', 'MILLVILLE', 4, '11011'
UNION SELECT 'PO BOX 2','RTE 2', 'PLEASANTVILLE',3,'10101'
UNION SELECT 'PO BOX 3','RTE 3', 'HUDSON',2,'10202'
UNION SELECT 'PO BOX 4', 'RTE 4','STANTON',3,'87654-1011'
UNION SELECT 'PO BOX 5',NULL,'LAS VEGAS',1,'90056'





--*/----------------------------------------------------------------------------------


------------------------------------------------------------------------------------------------------------------------------------------------------------------
--  [   5 Try Catch Block - Insert - Update - CONDITIONAL ROW BY ROW PROCESSING - LOOP ( also see file Conditional Set-Based ETL.sql)	]   --------------------------------


/*	PRE RUN STEP - WRITE TO BATCH TABLE ((Write: [Filename] (LeadSquaredExport_YYYYMMDD), [ProcessStart] (GetDate()), [Status] (Starting)))		*/

DECLARE @StartTime DATETIME = (SELECT GetDate())
DECLARE @YYYYmmddStamp DATE = (SELECT CONVERT(DATE, GETDATE()))
DECLARE @FileName nvarchar(30) = CONCAT('LeadSquaredExport_', REPLACE(@YYYYmmddStamp, '-', ''))
select @StartTime as [StartTime], @YYYYmmddStamp AS [FileDateStamp], @FileName AS [FullFilename]

BEGIN TRY
    BEGIN TRANSACTION;

    -- Your DML statements here
    INSERT INTO [LeadSquared].[PatientDataForExtract_Batches] ([Filename], [ProcessStart], [Status]) VALUES (@FileName, @StartTime, N'Starting');
    --UPDATE AnotherTable SET ColumnA = 'NewValue' WHERE ID = 1;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    -- Log error details to an error logging table
    INSERT INTO ErrorLogTable (
        ErrorNumber,
        ErrorMessage,
        ErrorSeverity,
        ErrorState,
        ErrorProcedure,
        ErrorLine,
        ErrorDateTime
    )
    VALUES (
        ERROR_NUMBER(),
        ERROR_MESSAGE(),
        ERROR_SEVERITY(),
        ERROR_STATE(),
        ERROR_PROCEDURE(),
        ERROR_LINE(),
        GETDATE()
    );

    -- Optionally, re-raise the error or handle it as needed
    -- THROW; 
END CATCH;



---	CONDITIONAL SET BASED PROCESSING REVERTS TO ROW BY ROW PROCESSING	-------

--Create an ID to update the source data (if required)
DECLARE @BatchID int
SELECT @BatchID = 100

DECLARE @CurrentTime datetime
DECLARE @TotalInserts int
DECLARE @Counter int

--Variables needed if conditional set-based processing reverts to row-by-row processing
DECLARE @RowID int,
		@AddressLine1 nvarchar(60),
		@AddressLine2 nvarchar(60),
		@City nvarchar(30),
		@StateProvinceId int,
		@PostalCode	nvarchar(15)
DECLARE @XMLDoc xml

--Declare temporary table to hold source data
DECLARE @TempSource TABLE
(RowID int PRIMARY KEY,
 AddressLine1 nvarchar(60),
 AddressLine2 nvarchar(60),
 City nvarchar(30),
 StateProvinceID int,
 PostalCode nvarchar(15)
)

INSERT INTO @TempSource
(RowID,AddressLine1,AddressLine2,
 City, StateProvinceID, PostalCode)
SELECT 
SourceRowIdentifier,
SourceAddressLine1, SourceAddressLine2,
 SourceCity, SourceStateProvinceID,
 SourcePostalCode
FROM dbo.SourceAddress
WHERE BatchID IS NULL

--BEGIN CODE SECTION FOR SET-BASED PROCESSING 
SET @TotalInserts = (SELECT COUNT(*) FROM @TempSource)
IF @TotalInserts > 0
BEGIN
			
BEGIN TRY
BEGIN TRAN

INSERT INTO dbo.TargetAddress
	(AddressLine1,
	 AddressLine2,
	 City, 
	 StateProvinceID, 
	 PostalCode)
SELECT 
	AddressLine1,
	AddressLine2,
	City, 
	StateProvinceID, 
	PostalCode
FROM @TempSource

SET @CurrentTime = getdate()

UPDATE dbo.SourceAddress
	SET		LoadTime = @CurrentTime,
			BatchID = @BatchID
	FROM dbo.SourceAddress S JOIN @TempSource T 
	ON	T.RowID = S.SourceRowIdentifier

	IF @@TRANCOUNT > 0			
	COMMIT TRAN

	--Don't delete from temp table until transaction is committed
	DELETE @TempSource 

	PRINT 'Source Records processed in set-based statements'

END TRY
BEGIN CATCH --Outer catch block

		--Rollback all data. This does not delete or remove the table variable and its data.
		IF @@TRANCOUNT > 0
		ROLLBACK

	    --Record a single error in the errors table. 
		--We may not know which record caused the batch to fail, but we record the failure.

			  INSERT INTO	dbo.ETLErrorLog
						(	ErrorCode,
							ErrorText,
							ErrorProcedure,
							ErrorSourceID
						)			  
					SELECT	ERROR_NUMBER(),
							ERROR_MESSAGE(),
							ERROR_PROCEDURE(),
							@BatchID


		--We still have our staged records in the @TempSource table
			SELECT TOP 1
				@RowID				= RowID,
				@AddressLine1		= AddressLine1,
				@AddressLine2		= AddressLine2,
				@City				= City,
				@StateProvinceId	= StateProvinceID,
				@PostalCode			= PostalCode
			FROM   @TempSource

		SET @Counter = 1
		-- LOOP through each record in the batch. We previously got the total count.
		WHILE @Counter <= @TotalInserts
		  BEGIN

			BEGIN TRY
				PRINT 'Processing record '+ CAST(@RowID AS NVARCHAR(4)) +' in one-at-a-time loop...'
			BEGIN TRAN
			
						INSERT INTO dbo.TargetAddress
							(AddressLine1,
							 AddressLine2,
							 City, 
							 StateProvinceID, 
							 PostalCode)
						SELECT 
							@AddressLine1,
							@AddressLine2,
							@City, 
							@StateProvinceID, 
							@PostalCode

				UPDATE dbo.SourceAddress
					SET		LoadTime = @CurrentTime,
							BatchID = @BatchID
					WHERE	SourceRowIdentifier = @RowID

					--Commit each record one-at-a-time, updating the Source table that it has been processed, catching the errors
					IF @@TRANCOUNT > 0
					COMMIT TRAN

				END TRY
				BEGIN CATCH

					--Roll back only the processing of the one record
					IF @@TRANCOUNT > 0
					ROLLBACK

					SELECT @XMLDoc =
						(SELECT RowID,
							AddressLine1,
							 AddressLine2,
							 City, 
							 StateProvinceID, 
							 PostalCode
						FROM @TempSource
						WHERE RowID = @RowID
						FOR XML PATH (''))

					  INSERT INTO	dbo.ETLErrorLog
								(	ErrorCode,
									ErrorText,
									ErrorProcedure,
									ErrorSourceID,
									ErrorSourceData
								)			  
							SELECT	ERROR_NUMBER(),
									ERROR_MESSAGE(),
									ERROR_PROCEDURE(),
									@RowID,
									@XMLDoc


					--You may wish to add code here to limit the number of times a failed record attempts to load in subsequent batches
					--Failed records can be moved to another table, flagged, or deleted, depending on business rules

				END CATCH --Nested catch block

					DELETE @TempSource
					WHERE @RowID = RowID
					
					--Continue getting data for WHILE loop
					SELECT @Counter = @Counter+1	
					SELECT @RowID = NULL, @AddressLine1 = NULL, @AddressLine2 = NULL, @City = NULL, @StateProvinceID = NULL, @PostalCode = NULL

					SELECT TOP 1
						@RowID				= RowID,
						@AddressLine1		= AddressLine1,
						@AddressLine2		= AddressLine2,
						@City				= City,
						@StateProvinceId	= StateProvinceID,
						@PostalCode			= PostalCode
					FROM   @TempSource


			END --While Loop for Row-by-row processing 

END CATCH --Initial catch block

END --If Total_Inserts > 0

SELECT * FROM dbo.ETLErrorLog


------------------------------------------------------------------------------------------------------------------------------------------------------------------
--  [   6 TEMP TABLES - OPENQUERY - CTE - VARIABLE TABLE]   --------------------------------

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'tempdb..#YourTempTableName') IS NOT NULL
BEGIN
    DROP TABLE #YourTempTableName;
END;

CREATE TABLE #YourTempTableName (
    Column1 INT,
    Column2 VARCHAR(50)
    -- Add more columns as needed
);

DROP TABLE IF EXISTS #YourTempTableName;

CREATE TABLE #YourTempTableName (
    Column1 INT,
    Column2 VARCHAR(50)
    -- Add more columns as needed
);

		DROP TABLE IF EXISTS #OPVisit,#OPReferringProvider,#Final ;

		Select PAV.PatientAdmissionKey,EvalCount,CASE TreatmentType WHEN 'PTA' THEN 'PT' WHEN 'COTA' THEN 'OT' ELSE TreatmentType END as TreatmentType 
		INTO #OPVisit 
		FROM ClinicalDataRepository.dbo.PatientAdmissionVisit PAV WITH (NOLOCK) WHERE TreatmentType IS NOT NULL AND PAV.UpdateDate > DATEADD(day,-30,GetDate());

		Select CASE_ID,NPI,EMAILADDRESS 
		INTO #OPReferringProvider 
		FROM OPENQUERY(OP_EMR,'Select CAST(PC.CASE_ID as varchar(20)) as CASE_ID,P.NPI,P.EMAILADDRESS FROM TheraOffice.dbo.PTCASE PC INNER JOIN TheraOffice.dbo.PHYSICIANS P ON P.PHYS_ID = PC.REF_PHYSICIAN WHERE PC.CREATED_ON > DATEADD(day,-30,GetDate())');

		WITH cteService as (
			Select PatientAdmissionKey,[PT],[OT],[SLP],[PSY] FROM (Select PatientAdmissionKey,EvalCount,TreatmentType FROM #OPVisit) Main PIVOT (MAX(EvalCount) FOR TreatmentType IN ([PT],[OT],[SLP],[PSY])) as PVT	
		)

---	DECLARE VARIABLE TABLE TO HOLD SOURCE DATA		-------

DECLARE @TempSource TABLE
(RowID int PRIMARY KEY,
 AddressLine1 nvarchar(60),
 AddressLine2 nvarchar(60),
 City nvarchar(30),
 StateProvinceID int,
 PostalCode nvarchar(15)
)

INSERT INTO @TempSource
(RowID,AddressLine1,AddressLine2,
 City, StateProvinceID, PostalCode)
SELECT 
SourceRowIdentifier,
SourceAddressLine1, SourceAddressLine2,
 SourceCity, SourceStateProvinceID,
 SourcePostalCode
FROM dbo.SourceAddress
WHERE BatchID IS NULL