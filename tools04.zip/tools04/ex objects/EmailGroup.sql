USE [DataScience]
GO

/****** Object:  Table [dbo].[EmailGroup]    Script Date: 8/18/2025 3:32:48 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EmailGroup]') AND type in (N'U'))
DROP TABLE [dbo].[EmailGroup]
GO

/****** Object:  Table [dbo].[EmailGroup]    Script Date: 8/18/2025 3:32:48 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[EmailGroup](
	[EmailGroupID] [int] IDENTITY(1,1) NOT NULL,
	[EmailGroupName] [varchar](40) NULL,
	[GroupDescription] [varchar](400) NULL,
	[IsActive] [bit] NULL,
	[IsADGroup] [bit] NULL,
	[CreateDate] [datetime] NULL,
	[LastUpdate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[EmailGroupID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


