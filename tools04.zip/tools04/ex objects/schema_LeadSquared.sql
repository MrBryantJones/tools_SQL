USE [DataScience]
GO

/****** Object:  Schema [LeadSquared]    Script Date: 8/18/2025 3:30:20 PM ******/
CREATE SCHEMA [LeadSquared]
GO


