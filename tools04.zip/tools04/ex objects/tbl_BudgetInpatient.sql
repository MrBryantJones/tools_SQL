USE [DataScience]
GO

/****** Object:  Table [staging].[BudgetInpatient]    Script Date: 8/18/2025 3:32:13 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[staging].[BudgetInpatient]') AND type in (N'U'))
DROP TABLE [staging].[BudgetInpatient]
GO

/****** Object:  Table [staging].[BudgetInpatient]    Script Date: 8/18/2025 3:32:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [staging].[BudgetInpatient](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Facility] [varchar](10) NULL,
	[SubUnit] [varchar](255) NULL,
	[FinancialClass] [varchar](155) NULL,
	[BudgetYear] [int] NULL,
	[BudgetMonth] [int] NULL,
	[GoalCategory] [varchar](100) NULL,
	[BudgetValue] [money] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


