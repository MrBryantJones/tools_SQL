﻿$source = "\\Brooks-Files\Brooks_IT$\Icons"
$destination = "C:\brooks_it\Icons"

if (!(Test-Path -Path $destination)) {
    New-Item -Path $destination -ItemType Directory
}

Get-ChildItem -Path $source -File | ForEach-Object {
    $destFile = Join-Path -Path $destination -ChildPath $_.Name
    if (!(Test-Path -Path $destFile)) {
        Copy-Item -Path $_.FullName -Destination $destFile
    }
}
