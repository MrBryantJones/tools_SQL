﻿# Parameters

$server = 'localhost\sql2022'
$database = 'ETL'
$delimeter = ','
$filepath = 'c:\temp\export.csv'
$query="select * from [dbo].[HF]"



# Functions

Function Export-BrooksDataCSV {

    param (
        $ServerInstance,
        $Database,
        $Delimeter,
        $FilePath,
        $Query
    )

    try {

        $result=invoke-sqlcmd -Serverinstance $ServerInstance -Database $Database -Query $Query -TrustServerCertificate -ErrorAction Stop 
        
        $result | Export-csv -Path $FilePath -Delimiter $Delimeter -NoTypeInformation -Force

    }
    catch {
        Write-Host $error -ForegroundColor Red
    }

}


# Code

Export-BrooksDataCSV -ServerInstance $server -Database $database -Delimeter $delimeter -FilePath $filepath -Query $query