﻿# Parameters
import-module -Name SQLSERVER -Force -Prefix SQL #Use Prefix to avoid collision with SQLPS which Agent uses as default
$server = 'ADDVWSQL22'
$typeKey = 'ERehabPtRep' #as defined in SQL table DataScience.dbo.PowerShellCommonFileImport to lookup configured values for this file import
$errorFilePath = 'E:\DataExtracts\IP_CMICMS\errorOutput.txt'
# Functions

Function Import-BrooksDataCSV {

    param (
        $ServerInstance,
        $importTypeKey
    )
#NewERehab*.csv
    try {
        #local variables initialized from values in SQL table
        $filePathSource = ""
        $filePathArchive = ""
        $destinationTable = ""
        $destinationDB = ""
        $fileNameFilter = ""
        $fileDelimiter = ""
        $tableSchema = ""
        $databaseName = "DataScience"

        $conString = "Server=$serverName;Database=$databaseName;Integrated Security=True;"
        $sqlConSource = New-Object System.Data.SqlClient.SqlConnection
        $sqlConSource.ConnectionString = $conString
        $sqlConSource.Open()

        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = "Select FileSourcePath,FileArchivePath,FileNameFilter,DestinationDatabaseName,DestinationTableName,FileDelimiter,TableSchema FROM $databaseName.dbo.PowerShellCommonFileImport WHERE FileImportKey = '$importTypeKey'"
        $sqlCommand.Connection = $sqlConSource
        $sqlReader = $sqlCommand.ExecuteReader()
        #Read through the results to initialize necessary variables
        while ($sqlReader.Read()) {
            $filePathSource = $sqlReader[0]
            $filePathArchive = $sqlReader[1]
            $fileNameFilter = $sqlReader[2]
            $destinationDB = $sqlReader[3]
            $destinationTable = $sqlReader[4]       
            $fileDelimiter = $sqlReader[5]
            $tableSchema = $sqlReader[6]
        }       
        $sqlReader.Close()
        $sqlCommand.Dispose()
                
        invoke-SQLsqlcmd -Serverinstance $ServerInstance -Database $destinationDB -Query "DROP TABLE IF EXISTS $destinationDB.$tableSchema.$destinationTable" -TrustServerCertificate -ErrorAction Stop 

        foreach ($file in get-childitem -Path $filePathSource -Filter $fileNameFilter) {
        
            $result = Import-Csv -Path $file.FullName -Delimiter $fileDelimiter  -ErrorAction Stop
        
            $result | Write-SQLSqlTableData -Serverinstance $ServerInstance -DatabaseName $destinationDB -SchemaName $tableSchema -TableName $destinationTable -TrustServerCertificate -Force -ErrorAction Stop 

            Move-Item $file.FullName -Destination $filePathArchive -Force

            Write-Host $file -ForegroundColor Green
        }

    }
    catch {
        #Write-Host $file $error -ForegroundColor Red
        Out-File -FilePath $errorFilePath -Append -InputObject $error
    }

}


# Code

Import-BrooksDataCSV -ServerInstance $server  -importTypeKey $typeKey
#-Database $database -Schema $schema -Table $table -Delimeter $delimeter -Path $path -ArchivePath $archive