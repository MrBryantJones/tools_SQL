$source = "\\Brooks-Files\Brooks_IT$"
$destination = "C:\Brooks_IT"
$options = "/MIR /Z /R:3 /W:30 /MT"

Start-Process robocopy.exe -ArgumentList "$source $destination $options" -Wait
