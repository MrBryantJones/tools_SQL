﻿# Parameters

$server = 'localhost\sql2022'
$database = 'ETL'
$schema = 'staging'
$table = 'HF_PS'
$delimeter = '|'
$path = 'c:\temp'
$archive = 'C:\temp\Archive'


# Functions

Function Import-BrooksDataCSV {

    param (
        $ServerInstance,
        $Database,
        $Schema,
        $Table,
        $Delimeter,
        $Path,
        $ArchivePath
    )

    try {

        invoke-sqlcmd -Serverinstance $ServerInstance -Database $Database -Query "DROP TABLE IF EXISTS $Shema.$Table"  -TrustServerCertificate -ErrorAction Stop 

        foreach ($file in get-childitem -Path $Path *.txt) {

            $result = Import-Csv -Path $file.FullName -Delimiter $Delimeter  -ErrorAction Stop
        
            $result | Write-SqlTableData -Serverinstance $ServerInstance -DatabaseName $Database -SchemaName $Schema -TableName $Table -Force -TrustServerCertificate -ErrorAction Stop 

            Move-Item $file.FullName -Destination $ArchivePath -Force

            Write-Host $file -ForegroundColor Green
        }

    }
    catch {
        Write-Host $file $error -ForegroundColor Red
    }

}


# Code

Import-BrooksDataCSV -ServerInstance $server -Database $database -Schema $schema -Table $table -Delimeter $delimeter -Path $path -ArchivePath $archive