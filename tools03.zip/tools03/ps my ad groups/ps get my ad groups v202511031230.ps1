﻿whoami /groups


# Use Select-String to find lines that contain "sec_"
whoami /groups | Select-String -Pattern "sec_"




<# ________________________________________________________________ #>


# 1. Export to a Text File (Simplest) __________________________________________ 
whoami /groups | Out-File C:\Temp\MyGroupMembership.txt


# 2. Output to a GridView (Graphical Table) __________________________________________ 

# 1. Capture the raw text output
$Groups = whoami /groups

# 2. Display the raw text in a GridView
$Groups | Out-GridView -Title "My User Group Membership"

# 3. Export to an HTML File (Web-Viewable Report) __________________________________________ 

# 1. Capture and process the output into objects
$GroupObjects = whoami /groups | Select-Object -Skip 3 | ForEach-Object {
    $parts = $_ -split ' {2,}'
    # Create a custom object for each group line
    [PSCustomObject]@{
        GroupName = $parts[0].Trim()
        Type      = $parts[1].Trim()
        SID       = $parts[2].Trim()
    }
}

# 2. Convert the objects to HTML and save the file
$GroupObjects | ConvertTo-Html -Title "Group Membership Report" -Body "<H2>User: $env:USERNAME</H2>" | Out-File C:\Temp\MyGroupMembership.html


# 4. Export to a CSV File (Excel-Viewable) __________________________________________ 

# 1. Capture and process the output into objects
$GroupObjects = whoami /groups | Select-Object -Skip 3 | ForEach-Object {
    $parts = $_ -split ' {2,}'
    # Create a custom object for each group line
    [PSCustomObject]@{
        GroupName = $parts[0].Trim()
        Type      = $parts[1].Trim()
        SID       = $parts[2].Trim()
    }
}

# 2. Convert the objects to CSV and save the file
$GroupObjects | Export-Csv C:\Temp\MyGroupMembership.csv -NoTypeInformation


# 5 Combined Script for Multiple Modes __________________________________________ 

# Define the Output File path and User
$OutputPath = "C:\Temp"
$UserName = $env:USERNAME

# --- Main Processing Block ---
# Capture and process the output into objects once
$GroupObjects = whoami /groups | Select-Object -Skip 3 | ForEach-Object {
    # Splits the line by two or more spaces (the delimiter in whoami output)
    $parts = $_ -split ' {2,}' 
    # Creates a reusable object with clean properties
    [PSCustomObject]@{
        GroupName = $parts[0].Trim()
        Type      = $parts[1].Trim()
        SID       = $parts[2].Trim()
    }
}
# --- End of Processing Block ---

# 1. Text File Output
$GroupObjects | Out-File "$OutputPath\$UserName`_Groups.txt"
Write-Host "Text file created: $OutputPath\$UserName`_Groups.txt"

# 2. HTML File Output (for web browser viewing)
$GroupObjects | ConvertTo-Html -Title "Group Membership Report for $UserName" -Body "<H2>User: $UserName</H2>" | Out-File "$OutputPath\$UserName`_Groups.html"
Write-Host "HTML file created: $OutputPath\$UserName`_Groups.html"

# 3. CSV File Output (for Excel viewing)
$GroupObjects | Export-Csv "$OutputPath\$UserName`_Groups.csv" -NoTypeInformation
Write-Host "CSV file created: $OutputPath\$UserName`_Groups.csv"

# 4. GridView Output (interactive pop-up table)
$GroupObjects | Out-GridView -Title "Group Membership for $UserName"



<#

        SEARCH GROUP NAMES 

#>

# 1 1. Filtered Script Example __________________________________________ 

# 1. Capture and process the output into objects
# This block is identical to the previous answer, it creates the objects
$GroupObjects = whoami /groups | Select-Object -Skip 3 | ForEach-Object {
    $parts = $_ -split ' {2,}'
    [PSCustomObject]@{
        GroupName = $parts[0].Trim()
        Type      = $parts[1].Trim()
        SID       = $parts[2].Trim()
    }
}

# 2. Filter the resulting objects for the group name pattern
$SecurityGroups = $GroupObjects | Where-Object { $_.GroupName -like "*sec_*" }

# 3. Output the filtered results (e.g., to GridView or a file)
$SecurityGroups | Out-GridView -Title "Groups Matching *sec_*"

# Example: Export the filtered list to CSV
$SecurityGroups | Export-Csv C:\Temp\SecurityGroups.csv -NoTypeInformation


# 2. Alternative: Filtering Raw Text (Less Flexible) __________________________________________ 

# Use Select-String to find lines that contain "sec_"
whoami /groups | Select-String -Pattern "sec_" | Out-File C:\Temp\RawSecurityGroups.txt





<#
 __________________________________________ 
 __________________________________________ 


 Good day to you. :) What would be the easiest way to find out if my profile is part of the administrators group of a windows server?

The easiest way to find out if your profile is part of the local Administrators group on a Windows Server is using the command line with the whoami command.

💻 Command Line Method
Open Command Prompt or PowerShell: Press the Windows Key + R, type cmd (or powershell), and press Enter.

Run the Group Membership Command: Type the following command and press Enter:

whoami /groups
Check the Output: This command will list all security groups your user account belongs to (both local and domain). Look for an entry that contains:

BUILTIN\Administrators (for the local Administrators group)

Domain Admins (if you are checking for domain-level administrative rights)

If you see an entry for BUILTIN\Administrators, your account is a member of the local administrators group.

⚙️ Alternative: Local Users and Groups (GUI)
If you have access to the graphical interface, you can also check through the Computer Management console:

Open Computer Management:

Press the Windows Key + R, type lusrmgr.msc, and press Enter (this shortcut often works directly on Windows Server editions). OR

Right-click the Start button and select Computer Management, then navigate to Local Users and Groups (under System Tools).

Check Group Membership:

Click on Groups.

Double-click the Administrators group.

The list under Members will show all users and groups that are members of the local Administrators group.

This video demonstrates how to check if a Windows user account has administrator rights using the command line, which is an effective method on a Windows server.

How To Check if Your Windows User Account Has Administrator Rights [ Quick Guide ]

How To Check if Your Windows User Account Has Administrator Rights [ Quick Guide ]
DO IT / mostafa ahmed · 251 views


How can I pipe that powershell (whoami /groups) export to a text file, a grid, an html file, and or an excel file? Basically have each output to be a mode that can run individually or all together based on the modes.

That's a great question! Pipelining the output of whoami /groups is slightly tricky because it's a legacy command-line executable, not a native PowerShell cmdlet that outputs objects.

The easiest way to work with the output is to use the native PowerShell cmdlet Get-ADPrincipalGroupMembership if you are on a domain-joined server and have the Active Directory Module installed, as it outputs true PowerShell objects.

However, since you specifically asked how to pipe the output of whoami /groups, you'll first need to capture its text output and then convert or process it.

Here are the four different output modes you requested, based on processing the raw text output.

1. Export to a Text File (Simplest) 📝
The easiest way to pipe the output to a text file is using the > (redirection) operator or the Out-File cmdlet.

PowerShell
whoami /groups | Out-File C:\Temp\MyGroupMembership.txt
Alternative: Use the basic redirection operator: whoami /groups > C:\Temp\MyGroupMembership.txt

2. Output to a GridView (Graphical Table) 🖼️
To display the output in a sortable, filterable graphical table (a GridView), you need to capture the text, put it into a variable, and use Out-GridView.

PowerShell
# 1. Capture the raw text output
$Groups = whoami /groups

# 2. Display the raw text in a GridView
$Groups | Out-GridView -Title "My User Group Membership"
Note: The output will be a single column of raw text, so filtering will be based on the string content.

3. Export to an HTML File (Web-Viewable Report) 🌐
To create a clean HTML report, you need to first structure the output into a custom object so that the ConvertTo-Html cmdlet can create proper table columns.

PowerShell
# 1. Capture and process the output into objects
$GroupObjects = whoami /groups | Select-Object -Skip 3 | ForEach-Object {
    $parts = $_ -split ' {2,}'
    # Create a custom object for each group line
    [PSCustomObject]@{
        GroupName = $parts[0].Trim()
        Type      = $parts[1].Trim()
        SID       = $parts[2].Trim()
    }
}

# 2. Convert the objects to HTML and save the file
$GroupObjects | ConvertTo-Html -Title "Group Membership Report" -Body "<H2>User: $env:USERNAME</H2>" | Out-File C:\Temp\MyGroupMembership.html
4. Export to a CSV File (Excel-Viewable) 📊
A CSV (Comma Separated Values) file is the standard format for importing data into Excel. This requires the same object creation as the HTML step.

PowerShell
# 1. Capture and process the output into objects
$GroupObjects = whoami /groups | Select-Object -Skip 3 | ForEach-Object {
    $parts = $_ -split ' {2,}'
    # Create a custom object for each group line
    [PSCustomObject]@{
        GroupName = $parts[0].Trim()
        Type      = $parts[1].Trim()
        SID       = $parts[2].Trim()
    }
}

# 2. Convert the objects to CSV and save the file
$GroupObjects | Export-Csv C:\Temp\MyGroupMembership.csv -NoTypeInformation
Note: You can open the .csv file directly in Excel.

Combined Script for Multiple Modes
To run all modes individually or together based on a simple input, you can wrap the logic in a PowerShell function. The following script will create all three file formats and display the GridView.

PowerShell
# Define the Output File path and User
$OutputPath = "C:\Temp"
$UserName = $env:USERNAME

# --- Main Processing Block ---
# Capture and process the output into objects once
$GroupObjects = whoami /groups | Select-Object -Skip 3 | ForEach-Object {
    # Splits the line by two or more spaces (the delimiter in whoami output)
    $parts = $_ -split ' {2,}' 
    # Creates a reusable object with clean properties
    [PSCustomObject]@{
        GroupName = $parts[0].Trim()
        Type      = $parts[1].Trim()
        SID       = $parts[2].Trim()
    }
}
# --- End of Processing Block ---

# 1. Text File Output
$GroupObjects | Out-File "$OutputPath\$UserName`_Groups.txt"
Write-Host "Text file created: $OutputPath\$UserName`_Groups.txt"

# 2. HTML File Output (for web browser viewing)
$GroupObjects | ConvertTo-Html -Title "Group Membership Report for $UserName" -Body "<H2>User: $UserName</H2>" | Out-File "$OutputPath\$UserName`_Groups.html"
Write-Host "HTML file created: $OutputPath\$UserName`_Groups.html"

# 3. CSV File Output (for Excel viewing)
$GroupObjects | Export-Csv "$OutputPath\$UserName`_Groups.csv" -NoTypeInformation
Write-Host "CSV file created: $OutputPath\$UserName`_Groups.csv"

# 4. GridView Output (interactive pop-up table)
$GroupObjects | Out-GridView -Title "Group Membership for $UserName"
Would you like me to explain the Select-Object -Skip 3 or the [PSCustomObject] part of the script in more detail?

If I needed to search the group names for names like "sec_", how would I do that?

To search for group names containing a specific string like "sec_" in the whoami /groups output, you need to use PowerShell's Where-Object (or its alias, where) cmdlet to filter the structured objects after you've parsed the raw text.

The key is that you must first perform the text processing step to create an object with a GroupName property, and then filter that property.

1. Filtered Script Example
Here is a modified version of the CSV/HTML processing block that adds a filter for groups where the name is like "sec_*".

PowerShell
# 1. Capture and process the output into objects
# This block is identical to the previous answer, it creates the objects
$GroupObjects = whoami /groups | Select-Object -Skip 3 | ForEach-Object {
    $parts = $_ -split ' {2,}'
    [PSCustomObject]@{
        GroupName = $parts[0].Trim()
        Type      = $parts[1].Trim()
        SID       = $parts[2].Trim()
    }
}

# 2. Filter the resulting objects for the group name pattern
$SecurityGroups = $GroupObjects | Where-Object { $_.GroupName -like "*sec_*" }

# 3. Output the filtered results (e.g., to GridView or a file)
$SecurityGroups | Out-GridView -Title "Groups Matching *sec_*"

# Example: Export the filtered list to CSV
$SecurityGroups | Export-Csv C:\Temp\SecurityGroups.csv -NoTypeInformation
Key Components Explained:
$GroupObjects | Where-Object { ... }: This is the standard PowerShell way to filter a collection of objects. It processes each object in the pipeline, evaluating the expression inside the curly braces.

$_.GroupName: The $_ variable represents the current object being processed (one line/group). .GroupName accesses the property we created during the initial text parsing.

-like "*sec_*": This is the filtering expression using the -like comparison operator.

The * is a wildcard and means "zero or more characters."

*sec_* tells PowerShell to find any group where the name contains "sec_".

If you only wanted groups that start with "sec_", you'd use "sec_*".

If you only wanted groups that end with "sec_", you'd use "*sec_"

Alternative: Filtering Raw Text (Less Flexible)
If you only wanted a text file output and didn't need the structured properties (like the SID or Type), you could filter the raw text output of whoami /groups directly using Select-String.

PowerShell
# Use Select-String to find lines that contain "sec_"
whoami /groups | Select-String -Pattern "sec_" | Out-File C:\Temp\RawSecurityGroups.txt
Pro: Very quick and simple for text files.

Con: The output is still raw text lines, making it unusable for GridView, CSV, or HTML formatting unless you do more parsing afterward. The first method is highly recommended because it creates usable objects first, allowing you to filter and export to any format easily.

 __________________________________________ 
 __________________________________________ 

 #>